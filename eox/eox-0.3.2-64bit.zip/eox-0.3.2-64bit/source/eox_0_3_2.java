import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class eox_0_3_2 extends PApplet {

float block_yoff;
float block_x;
float roughness = 10;
float size = 2;
Block[][] blocks;
ArrayList<Particle> particles = new ArrayList<Particle>();
Player player;
float block_update_counter, max_block_update_counter;
PImage background;

public void setup() {
  
  noStroke();
  textAlign(RIGHT);
  textFont(createFont("Arial",15,true),15);
  rectMode(CENTER);
  background = loadImage("background.png");
  int land_width = 200;
  int land_height = 100;
  blocks = new Block[land_width][land_height];
  block_x = -land_width/2;
  block_yoff = 0;
  for (int i = 0; i < land_width; i++) {
    block_yoff += 0.05f;
    float n = round(noise(block_yoff) * height / 20) * 20;
    float n1 = ((round(noise(block_yoff*2) * height / 20)+10) * 20);
    float n2 = ((round(noise(block_yoff*1.5f) * height / 20)+30) * 20);
    for (float j = n; j < max(n+20, n1); j += 20) {
      blocks[round(i)][round(j/20)] = new DirtBlock(block_x, j, round(i), round(j/20));
    }
    for (float j = max(n+20, n1); j < max(max(n+20, n1)+20, n2); j += 20) {
      blocks[round(i)][round(j/20)] = new StoneyBlock(block_x, j, round(i), round(j/20));
    }
    for (float j = max(max(n+20, n1)+20, n2); j < max(max(n+20, n1)+20, n2)+600; j += 20) {
      blocks[round(i)][round(j/20)] = new StoneBlock(block_x, j, round(i), round(j/20));
    }
    block_x += 20;
    println(i*100/land_width);
  }
  //copper ore
  block_x = -land_width/2;
  for (int i = 0; i < land_width; i++) {
    for (int j = 0; j < land_height; j++) {
      if (blocks[i][j] != null && blocks[i][j].type.equals("stoney") && random(0, 1) <= 0.005f) {
        blocks[i][j] = new CopperOre(block_x, j*20, i, j);
        float x_offset = 0;
        float y_offset = 0;
        for (int k = 0; k < random(4, 12); k++) {
          //x_offset += round(random(0, 2)-0.5)*2-1;
          //y_offset += round(random(0, 2)-0.5)*2-1;
          x_offset += round(random(-1, 1));
          y_offset += round(random(-1, 1));
          if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stoney")) {
            blocks[i+round(x_offset)][j+round(y_offset)] = new CopperOre(block_x+round(x_offset)*20, (j+round(y_offset))*20, i+round(x_offset), j+round(y_offset));
          }
        }
      }
    }
    block_x += 20;
  }
  //tin ore
  block_x = -land_width/2;
  for (int i = 0; i < land_width; i++) {
    for (int j = 0; j < land_height; j++) {
      if (blocks[i][j] != null && blocks[i][j].type.equals("stoney") && random(0, 1) <= 0.005f) {
        blocks[i][j] = new CopperOre(block_x, j*20, i, j);
        float x_offset = 0;
        float y_offset = 0;
        for (int k = 0; k < random(4, 12); k++) {
          //x_offset += round(random(0, 2)-0.5)*2-1;
          //y_offset += round(random(0, 2)-0.5)*2-1;
          x_offset += round(random(-1, 1));
          y_offset += round(random(-1, 1));
          if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stoney")) {
            blocks[i+round(x_offset)][j+round(y_offset)] = new TinOre(block_x+round(x_offset)*20, (j+round(y_offset))*20, i+round(x_offset), j+round(y_offset));
          }
        }
      }
    }
    block_x += 20;
  }
  //iron ore
  block_x = -land_width/2;
  for (int i = 0; i < land_width; i++) {
    for (int j = 0; j < land_height; j++) {
      if (blocks[i][j] != null && blocks[i][j].type.equals("stone") && random(0, 1) <= 0.003f) {
        blocks[i][j] = new IronOre(block_x, j*20, i, j);
        float x_offset = 0;
        float y_offset = 0;
        for (int k = 0; k < random(4, 12); k++) {
          //x_offset += round(random(0, 2)-0.5)*2-1;
          //y_offset += round(random(0, 2)-0.5)*2-1;
          x_offset += round(random(-1, 1));
          y_offset += round(random(-1, 1));
          if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stone")) {
            blocks[i+round(x_offset)][j+round(y_offset)] = new IronOre(block_x+round(x_offset)*20, (j+round(y_offset))*20, i+round(x_offset), j+round(y_offset));
          }
        }
      }
    }
    block_x += 20;
  }
  //coal
  block_x = -land_width/2;
  for (int i = 0; i < land_width; i++) {
    for (int j = 0; j < land_height; j++) {
      if (blocks[i][j] != null && blocks[i][j].type.equals("stone") && random(0, 1) <= 0.003f) {
        blocks[i][j] = new IronOre(block_x, j*20, i, j);
        float x_offset = 0;
        float y_offset = 0;
        for (int k = 0; k < random(4, 12); k++) {
          //x_offset += round(random(0, 2)-0.5)*2-1;
          //y_offset += round(random(0, 2)-0.5)*2-1;
          x_offset += round(random(-1, 1));
          y_offset += round(random(-1, 1));
          if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stone")) {
            blocks[i+round(x_offset)][j+round(y_offset)] = new CoalOre(block_x+round(x_offset)*20, (j+round(y_offset))*20, i+round(x_offset), j+round(y_offset));
          }
        }
      }
    }
    block_x += 20;
  }
  //boulder
  block_x = -land_width/2;
  for (int i = 0; i < land_width; i++) {
    for (int j = 0; j < land_height; j++) {
      if (blocks[i][j] != null && blocks[i][j].type.equals("dirt") && random(0, 1) <= 0.005f) {
        blocks[i][j] = new StoneBlock(block_x, j*20, i, j);
        float x_offset = 0;
        float y_offset = 0;
        for (int k = 0; k < random(8, 20); k++) {
          //x_offset += round(random(0, 2)-0.5)*2-1;
          //y_offset += round(random(0, 2)-0.5)*2-1;
          x_offset = round(random(-2, 1));
          y_offset = round(random(-2, 1));
          if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("dirt")) {
            blocks[i+round(x_offset)][j+round(y_offset)] = new StoneBlock(block_x+round(x_offset)*20, (j+round(y_offset))*20, i+round(x_offset), j+round(y_offset));
          }
        }
      }
    }
    block_x += 20;
  }
  //trees
  block_x = -land_width/2;
  for (int i = 0; i < land_width; i++) {
    for (int j = 12; j < land_height-12; j++) {
      if (blocks[i][j] == null && blocks[i][j+1] != null && blocks[i][j+1].type.equals("dirt") && random(0, 1) <= 0.1f) {
        int leaf_counter = 0;
        int tree_height = round(random(4, 12));
        for (int k = 0; k < tree_height; k++) {
          if (i+1 < land_width && i-1 > 0 && j-k > 0) {
            blocks[i][j-k] = new WoodBlock(block_x, (j-k)*20, i, j-k);
            if (k > tree_height/2) {
              blocks[i+1][j-k] = new LeafBlock(block_x+20, (j-k)*20, i+1, j-k);
              blocks[i-1][j-k] = new LeafBlock(block_x-20, (j-k)*20, i-1, j-k);
            }
            leaf_counter++;
          }
        }
        blocks[i][j-leaf_counter] = new LeafBlock(block_x, (j-leaf_counter)*20, i, j-leaf_counter);
      }
    }
    block_x += 20;
  }
  
  player = new Player(land_width*10, -height/2, blocks);
  //light = new Light(player.x, player.y, 10, color(255, 255, 255));
  max_block_update_counter = 20;
  block_update_counter = max_block_update_counter;
}

public void draw() {
  background(25, 120, 250);
  pushMatrix();
  image(background, width/2, height/2);
  translate(width/2-player.x, height/2-player.y);
  ArrayList<Light> lights = new ArrayList<Light>();
  for (Particle particle : particles) {
    if (particle.light_level > 0 && particle.fuse > 0) {
      lights.add(new Light(particle.x, particle.y, particle.light_level, particle.theColor));
    }
  }
  lights.add(new Light(player.x, -height*3, 30000, color(255, 255, 255)));
  for (Block[] block_row : blocks) {
    for (Block block : block_row) {
      if (block != null && block_update_counter == 0 && (block.x > player.x && block.y > player.y) && dist(block.x, block.y, player.x, player.y) < dist(0, 0, width*0.75f, height*0.75f)) {
        block.update(lights);
      }
      if (block != null && block_update_counter == round(max_block_update_counter*0.25f) && (block.x > player.x && block.y <= player.y) && dist(block.x, block.y, player.x, player.y) < dist(0, 0, width*0.75f, height*0.75f)) {
        block.update(lights);
      }
      if (block != null && block_update_counter == min(round(max_block_update_counter*0.5f), max_block_update_counter-1) && (block.x <= player.x && block.y > player.y) && dist(block.x, block.y, player.x, player.y) < dist(0, 0, width*0.75f, height*0.75f)) {
        block.update(lights);
      }
      if (block != null && block_update_counter == min(round(max_block_update_counter*0.75f), max_block_update_counter-1) && (block.x <= player.x && block.y <= player.y) && dist(block.x, block.y, player.x, player.y) < dist(0, 0, width*0.75f, height*0.75f)) {
        block.update(lights);
      }
      if (block != null) {
        block.display();
      }
    }
  }
  if (block_update_counter == 0) {
    block_update_counter = max_block_update_counter;
  }
  block_update_counter--;
    //for (Block[] block_row : blocks) {
    //  for (Block block : block_row) {
    //    if (block != null && dist(block.x, block.y, player.x, player.y) < dist(0, 0, width*0.75, height*0.75)) {
    //      block.display();
    //    }
    //  }
    //}
  player.update();
  for (Particle particle : particles) {
    particle.update();
  }
  
  text(str(round(frameRate)), width, 10);
}

public void keyPressed() {
  player.keyPressed();
}

public void keyReleased() {
  player.keyReleased();
}

public void mousePressed() {
  player.mousePressed();
}

public void mouseClicked() {
  player.mouseClicked();
}
class AlloySmelter extends Block {
  PImage img;
  String type;
  
  AlloySmelter(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "alloy_smelter.png", "alloy smelter", 1);
    img = loadImage("alloy_smelter.png");
    item = new Item(loadImage("alloy_smelter.png"), "block", "alloy smelter", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class Block {
  float x, y;
  PImage original_img, img;
  float[] brightness;
  float blockBrightness;
  int x_list_pos, y_list_pos;
  String type;
  Item item;
  float block_health, max_block_health;
  int mining_level;
  PImage[] block_breaking_imgs = new PImage[4];
  
  Block(float _x, float _y, int _x_list_pos, int _y_list_pos, String img_name, String _type, int _mining_level) {
    x = _x;
    y = _y;
    original_img = loadImage(img_name);
    img = original_img.get();
    x_list_pos = _x_list_pos;
    y_list_pos = _y_list_pos;
    type = _type;
    max_block_health = 100;
    block_health = max_block_health;
    mining_level = _mining_level;
    for (int i = 0; i < block_breaking_imgs.length; i++) {
      block_breaking_imgs[i] = loadImage("block_breaking_" + str(i+1) + ".png");
    }
  }
  
  public void update(ArrayList<Light> lights) {
    smoothLighting(lights);
    display();
  }
  
  public void smoothLighting(ArrayList<Light> lights) {
    brightness = new float[img.width*img.height];
    for (int i = 0; i < brightness.length; i++) {
      brightness[i] = 0;
    }
    img.loadPixels();
    for (Light light : lights) {
        for (int i = 0; i < img.width*img.height; i++) {
          float dist_to_pixel = dist(x-img.width/2+(i % img.width), y-img.height/2+((i - (i % img.width)) / img.width), light.x, light.y);
          float current_light_intensity = constrain(light.intensity/pow(dist_to_pixel/50, 2), 0, light.intensity);
          int r = round(red(img.pixels[i]));
          int g = round(green(img.pixels[i]));
          int b = round(blue(img.pixels[i]));
          if (light.lightColor != color(255)) {
            if (current_light_intensity <= 1) {
              r = round((red(img.pixels[i]) + red(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
              g = round((green(img.pixels[i]) + green(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
              b = round((blue(img.pixels[i]) + blue(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
            } else {
              r = round((red(img.pixels[i]) + red(light.lightColor))/2);
              g = round((green(img.pixels[i]) + green(light.lightColor))/2);
              b = round((blue(img.pixels[i]) + blue(light.lightColor))/2);
            }
          }
          //img.pixels[i] = color(round(r*current_light_intensity/10), round(g*current_light_intensity/10), round(b*current_light_intensity/10));
          img.pixels[i] = color(round(r), round(g), round(b));
          float tempBrightness = current_light_intensity/10;
          brightness[i] = max(brightness[i], tempBrightness);
        }
    }
    for (int i = 0; i < img.width*img.height; i++) {
      img.pixels[i] = color(red(img.pixels[i])*brightness[i], green(img.pixels[i])*brightness[i], blue(img.pixels[i])*brightness[i]);
    }
    img.updatePixels();
  }
  
  public void roughLighting(ArrayList<Light> lights) {
    blockBrightness = 0;
    img.loadPixels();
    for (Light light : lights) {
      float dist_to_light = dist(x, y, light.x, light.y);
      float current_light_intensity = constrain(light.intensity/pow(dist_to_light/50, 2), 0, light.intensity);
      for (int i = 0; i < img.width*img.height; i++) {
        int r = round(red(img.pixels[i]));
        int g = round(green(img.pixels[i]));
        int b = round(blue(img.pixels[i]));
        if (light.lightColor != color(255)) {
          if (current_light_intensity <= 1) {
            r = round((red(img.pixels[i]) + red(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
            g = round((green(img.pixels[i]) + green(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
            b = round((blue(img.pixels[i]) + blue(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
          } else {
            r = round((red(img.pixels[i]) + red(light.lightColor))/2);
            g = round((green(img.pixels[i]) + green(light.lightColor))/2);
            b = round((blue(img.pixels[i]) + blue(light.lightColor))/2);
          }
          }
        img.pixels[i] = color(round(r), round(g), round(b));
      }
      float tempBrightness = current_light_intensity/10;
      blockBrightness = max(blockBrightness, tempBrightness);
    }
    for (int i = 0; i < img.width*img.height; i++) {
      img.pixels[i] = color(red(img.pixels[i])*blockBrightness, green(img.pixels[i])*blockBrightness, blue(img.pixels[i])*blockBrightness);
    }
    img.updatePixels();
  }
  
  public void display() {
    imageMode(CENTER);
    image(img, x, y);
    if (block_health > 0 && block_health <= max_block_health*0.2f) {
      image(block_breaking_imgs[3], x, y);
    } else if (block_health > max_block_health*0.2f && block_health <= max_block_health*0.4f) {
      image(block_breaking_imgs[2], x, y);
    } else if (block_health > max_block_health*0.4f && block_health <= max_block_health*0.6f) {
      image(block_breaking_imgs[1], x, y);
    } else if (block_health > max_block_health*0.6f && block_health <= max_block_health*0.8f) {
      image(block_breaking_imgs[0], x, y);
    }
  }
}
class Campfire extends Block {
  PImage img;
  String type;
  
  Campfire(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "campfire.png", "campfire", 1);
    img = loadImage("campfire.png");
    item = new Item(loadImage("campfire.png"), "block", "campfire", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class CoalOre extends Block {
  PImage img;
  String type;
  
  CoalOre(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "coal_ore.png", "coal ore", 2);
    img = loadImage("coal_ore.png");
    item = new Item(loadImage("coal.png"), "item", "coal", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class CopperOre extends Block {
  PImage img;
  String type;
  
  CopperOre(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "copper_ore.png", "copper ore", 3);
    img = loadImage("copper_ore.png");
    item = new Item(loadImage("copper_ore.png"), "block", "copper ore", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class CraftingBench extends Block {
  PImage img;
  String type;
  
  CraftingBench(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "crafting_bench.png", "crafting bench", 1);
    img = loadImage("crafting_bench.png");
    item = new Item(loadImage("crafting_bench.png"), "block", "crafting bench", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class CraftingController {
  ItemStack[] inventory;
  
  CraftingController(ItemStack[] _inventory) {
    inventory = _inventory;
  }
  
  public void addToStack(ItemStack[] inventory, Item item) {
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (inventory[i].items.get(0).name.equals(item.name)) {
          inventory[i].items.add(item);
          return;
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] == null) {
        inventory[i] = new ItemStack(item, 1);
        return;
      }
    }
  }
  
  public ArrayList<RecipePointer> returnRecipes() {
    ArrayList<RecipePointer> return_pointers = new ArrayList<RecipePointer>();
    if (woodBlock_To_Wood(false) != null) {
      return_pointers.add(new RecipePointer(woodBlock_To_Wood(false), "wood block to wood"));
    }
    if (wood_To_CraftingBench(false) != null) {
      return_pointers.add(new RecipePointer(wood_To_CraftingBench(false), "wood to crafting bench"));
    }
    if (wood_To_WoodenPicaxe(false) != null) {
      return_pointers.add(new RecipePointer(wood_To_WoodenPicaxe(false), "wood to wooden picaxe"));
    }
    if (woodAndStone_To_StonePicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndStone_To_StonePicaxe(false), "wood and stone to stone picaxe"));
    }
    if (woodAndCoal_To_Torch(false) != null) {
      return_pointers.add(new RecipePointer(woodAndCoal_To_Torch(false), "wood and coal to torch"));
    }
    if (torch_To_Campfire(false) != null) {
      return_pointers.add(new RecipePointer(torch_To_Campfire(false), "torch to campfire"));
    }
    if (stoneAndWoodAndCampfire_To_Furnace(false) != null) {
      return_pointers.add(new RecipePointer(stoneAndWoodAndCampfire_To_Furnace(false), "stone and wood and campfire to furnace"));
    }
    if (copperOre_To_CopperIngot(false) != null) {
      return_pointers.add(new RecipePointer(copperOre_To_CopperIngot(false), "copper ore to copper ingot"));
    }
    if (woodAndCopper_To_CopperPicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndCopper_To_CopperPicaxe(false), "wood and copper to copper picaxe"));
    }
    if (tinOre_To_TinIngot(false) != null) {
      return_pointers.add(new RecipePointer(tinOre_To_TinIngot(false), "tin ore to tin ingot"));
    }
    if (copperIngotAndTinIngotAndCampfire_To_AlloySmelter(false) != null) {
      return_pointers.add(new RecipePointer(copperIngotAndTinIngotAndCampfire_To_AlloySmelter(false), "copper ingot and tin ingot and campfire to alloy smelter"));
    }
    if (copperIngotAndTinIngot_To_BronzeIngot(false) != null) {
      return_pointers.add(new RecipePointer(copperIngotAndTinIngot_To_BronzeIngot(false), "copper ingot and tin ingot to bronze ingot"));
    }
    if (woodAndBroze_To_BronzePicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndBroze_To_BronzePicaxe(false), "wood and bronze to bronze picaxe"));
    }
    if (ironOre_To_IronIngot(false) != null) {
      return_pointers.add(new RecipePointer(ironOre_To_IronIngot(false), "iron ore to iron ingot"));
    }
    return return_pointers;
  }
  
  public void executeRecipe(RecipePointer recipe_pointer) {
    if (recipe_pointer.name.equals("wood block to wood")) {
      woodBlock_To_Wood(true);
    }
    if (recipe_pointer.name.equals("wood to crafting bench")) {
      wood_To_CraftingBench(true);
    }
    if (recipe_pointer.name.equals("wood to wooden picaxe")) {
      wood_To_WoodenPicaxe(true);
    }
    if (recipe_pointer.name.equals("wood and stone to stone picaxe")) {
      woodAndStone_To_StonePicaxe(true);
    }
    if (recipe_pointer.name.equals("wood and coal to torch")) {
      woodAndCoal_To_Torch(true);
    }
    if (recipe_pointer.name.equals("torch to campfire")) {
      torch_To_Campfire(true);
    }
    if (recipe_pointer.name.equals("stone and wood and campfire to furnace")) {
      stoneAndWoodAndCampfire_To_Furnace(true);
    }
    if (recipe_pointer.name.equals("copper ore to copper ingot")) {
      copperOre_To_CopperIngot(true);
    }
    if (recipe_pointer.name.equals("wood and copper to copper picaxe")) {
      woodAndCopper_To_CopperPicaxe(true);
    }
    if (recipe_pointer.name.equals("tin ore to tin ingot")) {
      tinOre_To_TinIngot(true);
    }
    if (recipe_pointer.name.equals("copper ingot and tin ingot and campfire to alloy smelter")) {
      copperIngotAndTinIngotAndCampfire_To_AlloySmelter(true);
    }
    if (recipe_pointer.name.equals("copper ingot and tin ingot to bronze ingot")) {
      copperIngotAndTinIngot_To_BronzeIngot(true);
    }
    if (recipe_pointer.name.equals("wood and bronze to bronze picaxe")) {
      woodAndBroze_To_BronzePicaxe(true);
    }
    if (recipe_pointer.name.equals("iron ore to iron ingot")) {
      ironOre_To_IronIngot(true);
    }
  }
  
  //block of wood to 2 wood
  public PImage woodBlock_To_Wood (boolean real) {
    PImage return_image = loadImage("wood.png");
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (inventory[i].items.get(0).name.equals("wood block")) {
          if (!real) {
            return return_image;
          } else {
            inventory[i].items.remove(0);
            if (inventory[i].items.size() <= 0) {
              inventory[i] = null;
            }
            addToStack(inventory, new Item(return_image, "block", "wood", 1, 40));
            addToStack(inventory, new Item(return_image, "block", "wood", 1, 40));
            return null;
          }
        }
      }
    }
    return null;
  }
  
  //4 wood to crafting bench
  public PImage wood_To_CraftingBench (boolean real) {
    PImage return_image = loadImage("crafting_bench.png");
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (inventory[i].items.get(0).name.equals("wood") && inventory[i].items.size() >= 4) {
          if (!real) {
            return return_image;
          } else {
            for (int j = 0; j < 4; j++) {
              inventory[i].items.remove(0);
            }
            if (inventory[i].items.size() <= 0) {
              inventory[i] = null;
            }
            addToStack(inventory, new Item(loadImage("crafting_bench.png"), "block", "crafting bench", 1, 40));
            return null;
          }
        }
      }
    }
    return null;
  }
  
  //8 wood to wooden picaxe
  public PImage wood_To_WoodenPicaxe (boolean real) {
    PImage return_image = loadImage("wooden_picaxe.png");
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        boolean onCraftingBench = false;
        for (Block[] block_row : blocks) {
          for (Block block : block_row) {
            if (block != null) {
              if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("crafting bench")) {
                onCraftingBench = true;
              }
            }
          }
        }
        if (onCraftingBench && inventory[i].items.get(0).name.equals("wood") && inventory[i].items.size() >= 8) {
          if (!real) {
            return return_image;
          } else {
            for (int j = 0; j < 8; j++) {
              inventory[i].items.remove(0);
            }
            if (inventory[i].items.size() <= 0) {
              inventory[i] = null;
            }
            addToStack(inventory, new Item(loadImage("wooden_picaxe.png"), "picaxe", "wooden picaxe", 2, 60));
            return null;
          }
        }
      }
    }
    return null;
  }
  
  public PImage woodAndStone_To_StonePicaxe (boolean real) {
    PImage return_image = loadImage("stone_picaxe.png");
    boolean onCraftingBench = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("crafting bench")) {
            onCraftingBench = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      for (int j = 0; j < inventory.length; j++) {
        if (inventory[i] != null && inventory[j] != null) {
          if (onCraftingBench && inventory[i].items.get(0).name.equals("wood") && inventory[i].items.size() >= 8 && inventory[j].items.get(0).name.equals("stone block") && inventory[j].items.size() >= 12) {
            if (!real) {
              return return_image;
            } else {
              for (int k = 0; k < 8; k++) {
                inventory[i].items.remove(0);
              }
              for (int k = 0; k < 12; k++) {
                inventory[j].items.remove(0);
              }
              if (inventory[i].items.size() <= 0) {
                inventory[i] = null;
              }
              if (inventory[j].items.size() <= 0) {
                inventory[j] = null;
              }
              addToStack(inventory, new Item(loadImage("stone_picaxe.png"), "picaxe", "stone picaxe", 3, 60));
              return null;
            }
          }
        }
      }
    }
    return null;
  }
  
  public PImage woodAndCoal_To_Torch (boolean real) {
    PImage return_image = loadImage("torch.png");
    for (int i = 0; i < inventory.length; i++) {
      for (int j = 0; j < inventory.length; j++) {
        if (inventory[i] != null && inventory[j] != null) {
          if (inventory[i].items.get(0).name.equals("wood") && inventory[i].items.size() >= 4 && inventory[j].items.get(0).name.equals("coal") && inventory[j].items.size() >= 1) {
            if (!real) {
              return return_image;
            } else {
              for (int k = 0; k < 4; k++) {
                inventory[i].items.remove(0);
              }
              for (int k = 0; k < 1; k++) {
                inventory[j].items.remove(0);
              }
              if (inventory[i].items.size() <= 0) {
                inventory[i] = null;
              }
              if (inventory[j].items.size() <= 0) {
                inventory[j] = null;
              }
              for (int k = 0; k < 10; k++) {
                addToStack(inventory, new Item(loadImage("torch.png"), "block", "torch", 1, 40));
              }
              return null;
            }
          }
        }
      }
    }
    return null;
  }
  
  public PImage torch_To_Campfire (boolean real) {
    PImage return_image = loadImage("campfire.png");
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (inventory[i].items.get(0).name.equals("torch") && inventory[i].items.size() >= 25) {
          if (!real) {
            return return_image;
          } else {
            for (int j = 0; j < 25; j++) {
              inventory[i].items.remove(0);
            }
            if (inventory[i].items.size() <= 0) {
              inventory[i] = null;
            }
            addToStack(inventory, new Item(loadImage("campfire.png"), "block", "campfire", 1, 40));
            return null;
          }
        }
      }
    }
    return null;
  }
  
  public PImage stoneAndWoodAndCampfire_To_Furnace (boolean real) {
    PImage return_image = loadImage("furnace.png");
    boolean onCraftingBench = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("crafting bench")) {
            onCraftingBench = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      for (int j = 0; j < inventory.length; j++) {
        for (int k = 0; k < inventory.length; k++) {
          if (inventory[i] != null && inventory[j] != null && inventory[k] != null) {
            if (onCraftingBench && inventory[i].items.get(0).name.equals("stone block") && inventory[i].items.size() >= 25 && inventory[j].items.get(0).name.equals("wood") && inventory[j].items.size() >= 10 && inventory[k].items.get(0).name.equals("campfire") && inventory[k].items.size() >= 2) {
              if (!real) {
                return return_image;
              } else {
                for (int l = 0; l < 25; l++) {
                  inventory[i].items.remove(0);
                }
                for (int l = 0; l < 10; l++) {
                  inventory[j].items.remove(0);
                }
                for (int l = 0; l < 2; l++) {
                  inventory[k].items.remove(0);
                }
                if (inventory[i].items.size() <= 0) {
                  inventory[i] = null;
                }
                if (inventory[j].items.size() <= 0) {
                  inventory[j] = null;
                }
                if (inventory[k].items.size() <= 0) {
                  inventory[k] = null;
                }
                addToStack(inventory, new Item(loadImage("furnace.png"), "block", "furnace", 1, 40));
                return null;
              }
            }
          }
        }
      }
    }
    return null;
  }
  
  public PImage copperOre_To_CopperIngot (boolean real) {
    PImage return_image = loadImage("copper_ingot.png");
    boolean onFurnace = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("furnace")) {
            onFurnace = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (onFurnace && inventory[i].items.get(0).name.equals("copper ore") && inventory[i].items.size() >= 3) {
          if (!real) {
            return return_image;
          } else {
            for (int j = 0; j < 3; j++) {
              inventory[i].items.remove(0);
            }
            if (inventory[i].items.size() <= 0) {
              inventory[i] = null;
            }
            addToStack(inventory, new Item(loadImage("copper_ingot.png"), "item", "copper ingot", 1, 40));
            return null;
          }
        }
      }
    }
    return null;
  }
  
  public PImage woodAndCopper_To_CopperPicaxe (boolean real) {
    PImage return_image = loadImage("copper_picaxe.png");
    boolean onCraftingBench = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("crafting bench")) {
            onCraftingBench = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      for (int j = 0; j < inventory.length; j++) {
        if (inventory[i] != null && inventory[j] != null) {
          if (onCraftingBench && inventory[i].items.get(0).name.equals("wood") && inventory[i].items.size() >= 10 && inventory[j].items.get(0).name.equals("copper ingot") && inventory[j].items.size() >= 5) {
            if (!real) {
              return return_image;
            } else {
              for (int k = 0; k < 10; k++) {
                inventory[i].items.remove(0);
              }
              for (int k = 0; k < 5; k++) {
                inventory[j].items.remove(0);
              }
              if (inventory[i].items.size() <= 0) {
                inventory[i] = null;
              }
              if (inventory[j].items.size() <= 0) {
                inventory[j] = null;
              }
              addToStack(inventory, new Item(loadImage("copper_picaxe.png"), "picaxe", "copper picaxe", 4, 80));
              return null;
            }
          }
        }
      }
    }
    return null;
  }
  
  public PImage tinOre_To_TinIngot (boolean real) {
    PImage return_image = loadImage("tin_ingot.png");
    boolean onFurnace = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("furnace")) {
            onFurnace = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (onFurnace && inventory[i].items.get(0).name.equals("tin ore") && inventory[i].items.size() >= 4) {
          if (!real) {
            return return_image;
          } else {
            for (int j = 0; j < 4; j++) {
              inventory[i].items.remove(0);
            }
            if (inventory[i].items.size() <= 0) {
              inventory[i] = null;
            }
            addToStack(inventory, new Item(loadImage("tin_ingot.png"), "item", "tin ingot", 1, 40));
            return null;
          }
        }
      }
    }
    return null;
  }
  
  public PImage copperIngotAndTinIngotAndCampfire_To_AlloySmelter (boolean real) {
    PImage return_image = loadImage("alloy_smelter.png");
    boolean onCraftingBench = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("crafting bench")) {
            onCraftingBench = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      for (int j = 0; j < inventory.length; j++) {
        for (int k = 0; k < inventory.length; k++) {
          if (inventory[i] != null && inventory[j] != null && inventory[k] != null) {
            if (onCraftingBench && inventory[i].items.get(0).name.equals("copper ingot") && inventory[i].items.size() >= 10 && inventory[j].items.get(0).name.equals("tin ingot") && inventory[j].items.size() >= 5 && inventory[k].items.get(0).name.equals("campfire") && inventory[k].items.size() >= 3) {
              if (!real) {
                return return_image;
              } else {
                for (int l = 0; l < 10; l++) {
                  inventory[i].items.remove(0);
                }
                for (int l = 0; l < 5; l++) {
                  inventory[j].items.remove(0);
                }
                for (int l = 0; l < 3; l++) {
                  inventory[k].items.remove(0);
                }
                if (inventory[i].items.size() <= 0) {
                  inventory[i] = null;
                }
                if (inventory[j].items.size() <= 0) {
                  inventory[j] = null;
                }
                if (inventory[k].items.size() <= 0) {
                  inventory[k] = null;
                }
                addToStack(inventory, new Item(loadImage("alloy_smelter.png"), "block", "alloy_smelter", 1, 40));
                return null;
              }
            }
          }
        }
      }
    }
    return null;
  }
  
  public PImage copperIngotAndTinIngot_To_BronzeIngot (boolean real) {
    PImage return_image = loadImage("bronze_ingot.png");
    boolean onAlloySmelter = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("alloy smelter")) {
            onAlloySmelter = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      for (int j = 0; j < inventory.length; j++) {
        if (inventory[i] != null && inventory[j] != null) {
          if (onAlloySmelter && inventory[i].items.get(0).name.equals("copper ingot") && inventory[i].items.size() >= 3 && inventory[j].items.get(0).name.equals("tin ingot") && inventory[j].items.size() >= 1) {
            if (!real) {
              return return_image;
            } else {
              for (int k = 0; k < 3; k++) {
                inventory[i].items.remove(0);
              }
              for (int k = 0; k < 1; k++) {
                inventory[j].items.remove(0);
              }
              if (inventory[i].items.size() <= 0) {
                inventory[i] = null;
              }
              if (inventory[j].items.size() <= 0) {
                inventory[j] = null;
              }
              addToStack(inventory, new Item(loadImage("bronze_ingot.png"), "item", "bronze_ingot", 1, 40));
              return null;
            }
          }
        }
      }
    }
    return null;
  }
  
  public PImage woodAndBroze_To_BronzePicaxe (boolean real) {
    PImage return_image = loadImage("bronze_picaxe.png");
    boolean onCraftingBench = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("crafting bench")) {
            onCraftingBench = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      for (int j = 0; j < inventory.length; j++) {
        if (inventory[i] != null && inventory[j] != null) {
          if (onCraftingBench && inventory[i].items.get(0).name.equals("wood") && inventory[i].items.size() >= 20 && inventory[j].items.get(0).name.equals("bronze ingot") && inventory[j].items.size() >= 7) {
            if (!real) {
              return return_image;
            } else {
              for (int k = 0; k < 20; k++) {
                inventory[i].items.remove(0);
              }
              for (int k = 0; k < 7; k++) {
                inventory[j].items.remove(0);
              }
              if (inventory[i].items.size() <= 0) {
                inventory[i] = null;
              }
              if (inventory[j].items.size() <= 0) {
                inventory[j] = null;
              }
              addToStack(inventory, new Item(loadImage("bronze_picaxe.png"), "picaxe", "bronze picaxe", 5, 100));
              return null;
            }
          }
        }
      }
    }
    return null;
  }
  
  public PImage ironOre_To_IronIngot (boolean real) {
    PImage return_image = loadImage("iron_ingot.png");
    boolean onFurnace = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals("furnace")) {
            onFurnace = true;
          }
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (onFurnace && inventory[i].items.get(0).name.equals("iron ore") && inventory[i].items.size() >= 5) {
          if (!real) {
            return return_image;
          } else {
            for (int j = 0; j < 5; j++) {
              inventory[i].items.remove(0);
            }
            if (inventory[i].items.size() <= 0) {
              inventory[i] = null;
            }
            addToStack(inventory, new Item(loadImage("iron_ingot.png"), "item", "iron ingot", 1, 40));
            return null;
          }
        }
      }
    }
    return null;
  }
}
class DirtBlock extends Block {
  PImage img1, img2;
  String type;
  DirtBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "dirt_block.png", "dirt", 1);
    img1 = loadImage("dirt_block.png");
    img2 = loadImage("dirt_block_top.png");
    item = new Item(loadImage("dirt_block.png"), "block", "dirt block", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    if (blocks[x_list_pos][y_list_pos-1] == null) {
      for (int i = 0; i < img1.width*img1.height; i++) {
        super.img.pixels[i] = img1.pixels[i];
      }
    } else {
      for (int i = 0; i < img2.width*img2.height; i++) {
        super.img.pixels[i] = img2.pixels[i];
      }
    }
    super.update(lights);
  }
}
class Furnace extends Block {
  PImage img;
  String type;
  
  Furnace(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "furnace.png", "furnace", 5);
    img = loadImage("furnace.png");
    item = new Item(loadImage("furnace.png"), "block", "furnace", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class IronOre extends Block {
  PImage img;
  String type;
  
  IronOre(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "iron_ore.png", "iron ore", 5);
    img = loadImage("iron_ore.png");
    item = new Item(loadImage("iron_ore.png"), "block", "iron ore", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class Item {
  PImage inventory_img;
  String name, type;
  int mining_level, mining_speed;
  
  Item(PImage _inventory_img, String _type, String _name, int _mining_level, int _mining_speed) {
    inventory_img = _inventory_img;
    type = _type;
    name = _name;
    mining_level = _mining_level;
    mining_speed = _mining_speed;
  }
  
  public boolean use(Player player) {
    if (type.equals("block")) {
      boolean notOnBlock = true;
      if (blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] != null) {
        notOnBlock = false;
      }
      if (notOnBlock) {
        if (name.equals("alloy smelter")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new AlloySmelter(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("campfire")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new Campfire(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("copper ore")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new CopperOre(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("crafting bench")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new CraftingBench(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("iron ore")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new IronOre(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("dirt block")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new DirtBlock(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("furnace")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new Furnace(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("stone block")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new StoneBlock(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("stoney block")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new StoneyBlock(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("tin ore")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new TinOre(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("torch")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new Torch(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("wood")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new Wood(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
        if (name.equals("wood block")) {
          blocks[(round((player.x+mouseX-width/2)/20)*20-10)/20+6][round((player.y+mouseY-height/2)/20)] = new WoodBlock(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, (round((player.x+mouseX-width/2)/20)*20-10)/20+6, round((player.y+mouseY-height/2)/20));
          return true;
        }
      }
    }
    return false;
  }
}
class ItemStack {
  ArrayList<Item> items = new ArrayList<Item>();
  ItemStack(Item item, int amount) {
    for (int i = 0; i < amount; i++) {
      items.add(item);
    }
  }
}
class LeafBlock extends Block {
  PImage img;
  String type;
  
  LeafBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "leaf_block.png", "leaf", 1);
    img = loadImage("leaf_block.png");
    super.item = null;
    super.max_block_health = 1;
    super.block_health = 1;
  }
  
  public void update(ArrayList<Light> lights) {
    if ((x_list_pos < blocks.length && y_list_pos < blocks[0].length && (blocks[x_list_pos][y_list_pos-1] == null || (blocks[x_list_pos][y_list_pos-1] != null && !blocks[x_list_pos][y_list_pos-1].type.equals("wood block")))) &&
        (x_list_pos < blocks.length && y_list_pos < blocks[0].length && (blocks[x_list_pos][y_list_pos+1] == null || (blocks[x_list_pos][y_list_pos+1] != null && !blocks[x_list_pos][y_list_pos+1].type.equals("wood block")))) &&
        (x_list_pos < blocks.length && y_list_pos < blocks[0].length && (blocks[x_list_pos+1][y_list_pos] == null || (blocks[x_list_pos+1][y_list_pos] != null && !blocks[x_list_pos+1][y_list_pos].type.equals("wood block")))) &&
        (x_list_pos < blocks.length && y_list_pos < blocks[0].length && (blocks[x_list_pos-1][y_list_pos] == null || (blocks[x_list_pos-1][y_list_pos] != null && !blocks[x_list_pos-1][y_list_pos].type.equals("wood block"))))) {
      blocks[x_list_pos][y_list_pos] = null;
      return;
    }
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class Light {
  float x, y, intensity;
  int lightColor;
  
  Light(float _x, float _y, float _intensity, int _lightColor) {
    x = _x;
    y = _y;
    intensity = _intensity;
    lightColor = _lightColor;
  }
}
class Particle {
  float x, y, x_speed, y_speed, light_level, fuse, size;
  int theColor;
  boolean xy;
  PImage img;
  
  Particle(float _x, float _y, float _x_speed, float _y_speed, float _fuse, int _color, float _size, float _light_level) {
    x = _x;
    y = _y;
    x_speed = _x_speed;
    y_speed = _y_speed;
    light_level = _light_level;
    fuse = _fuse;
    theColor = _color;
    size = _size;
  }
  
  public void update() {
    if (fuse > 0) {
      x += x_speed;
      y += y_speed;
      fuse--;
      drawSprite();
    }
  }
  
  public void drawSprite() {
    rectMode(CENTER);
    fill(theColor);
    rect(x, y, size, size);
  }
}
class Player {
  float x, y, speed;
  PImage img_right, img_left;
  Block[][] blocks;
  
  float g_const, y_speed;
  boolean touching_ground;
  boolean facing_right;
  
  boolean w_pressed, a_pressed, d_pressed;
  PImage hotbar_frame, hotbar_frame_selected, recipe_frame;
  int hotbar_frame_selected_index;
  ItemStack[] inventory;
  boolean show_inventory;
  CraftingController crafting_controller;
  int block_breaking_cooldown;
  
  Player(float _x, float _y, Block[][] _blocks) {
    x = _x;
    y = _y;
    speed = 5;
    img_right = loadImage("player_right.png");
    img_left = loadImage("player_left.png");
    facing_right = true;
    blocks = _blocks;
    
    y_speed = 0;
    g_const = 1;
    touching_ground = false;
    
    hotbar_frame = loadImage("hotbar.png");
    hotbar_frame_selected = loadImage("hotbar_selected.png");
    recipe_frame = loadImage("recipe_frame.png");
    hotbar_frame_selected_index = 0;
    show_inventory = false;
    
    inventory = new ItemStack[210];
    crafting_controller = new CraftingController(inventory);
    
    block_breaking_cooldown = 0;
  }
  
  public void update() {
    move();
    applyGravity();
    display();
    popMatrix();
    checkBlockBreaking();
    drawHotbar();
    drawInventory();
  }
  
  public void keyPressed() {
    if (key == 'a') {
      a_pressed = true;
      facing_right = false;
    }
    if (key == 'd') {
      d_pressed = true;
      facing_right = true;
    }
    if (key == 'w') {
      w_pressed = true;
    }
    
    if (key == '1' || key == '2' || key == '3' || key == '4' || key == '5' || key == '6' || key == '7' || key == '8' || key == '9' || key == '0') {
      hotbar_frame_selected_index = PApplet.parseInt(str(key))-1;
      if (hotbar_frame_selected_index == -1) {
        hotbar_frame_selected_index = 9;
      }
    }
    
    if (key == 'e') {
      show_inventory = !show_inventory;
    }
  }
  
  public void keyReleased() {
    if (key == 'a') {
      a_pressed = false;
    }
    if (key == 'd') {
      d_pressed = false;
    }
    if (key == 'w') {
      w_pressed = false;
    }
  }
  
  public void mousePressed() {
    //rect(player.x+mouseX-width/2, player.y+mouseY-height/2, 20, 20);
    if (mouseButton == RIGHT) {
      println(1);
      if (inventory.length > hotbar_frame_selected_index) {
        if (inventory[hotbar_frame_selected_index] != null) {
          if (inventory[hotbar_frame_selected_index].items.get(0).use(player)) {
            inventory[hotbar_frame_selected_index].items.remove(0);
            if (inventory[hotbar_frame_selected_index].items.size() <= 0) {
              inventory[hotbar_frame_selected_index] = null;
            }
          }
        }
      }
    }
  }
  
  public void mouseClicked() {
    if (show_inventory) {
      for (int i = 0; i < crafting_controller.returnRecipes().size(); i++) {
        if (mouseX < 30+i*40 + recipe_frame.width &&
            mouseX > 30+i*40 - recipe_frame.width &&
            mouseY < 550 + recipe_frame.height &&
            mouseY > 550 - recipe_frame.height) {
            crafting_controller.executeRecipe(crafting_controller.returnRecipes().get(i));
            return;
        }
      }
    }
  }
  
  public void addToStack(ItemStack[] inventory, Item item) {
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (inventory[i].items.get(0).name.equals(item.name)) {
          inventory[i].items.add(item);
          return;
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] == null) {
        inventory[i] = new ItemStack(item, 1);
        return;
      }
    }
  }
  
  public void move() {
    if (a_pressed) {
      x -= speed;
      boolean noCollision = true;
      for (Block[] block_row : blocks) {
        for (Block block : block_row) {
          if (block != null && detectCollision(block)) {
            noCollision = false;
          }
        }
      }
      if (!noCollision) {
        x += speed;
        if (touching_ground) {
          y_speed = -7;
        }
      }
    }
    if (d_pressed) {
      x += speed;
      boolean noCollision = true;
      for (Block[] block_row : blocks) {
        for (Block block : block_row) {
          if (block != null && detectCollision(block)) {
            noCollision = false;
          }
        }
      }
      if (!noCollision) {
        x -= speed;
        if (touching_ground) {
          y_speed = -7;
        }
      }
    }
    if (w_pressed && touching_ground) {
      y_speed = -15;
    }
  }
  
  public void display() {
    if (facing_right) {
      image(img_right, x, y);
      if (inventory[hotbar_frame_selected_index] != null) {
        PImage holding_item_image = inventory[hotbar_frame_selected_index].items.get(0).inventory_img.get();
        pushMatrix();
        if (inventory[hotbar_frame_selected_index].items.get(0).type.equals("block")) {
          holding_item_image.resize(10, 10);
          translate(x+10, y+10);
          rotate(radians(80));
        } else {
          holding_item_image.resize(25, 25);
          translate(x+7.5f, y+7.5f);
          rotate(radians((30-block_breaking_cooldown)*4));
          translate(12.5f, -12.5f);
        }
        image(holding_item_image, 0, 0);
        popMatrix();
      }
    } else {
      image(img_left, x, y);
      if (inventory[hotbar_frame_selected_index] != null) {
        PImage holding_item_image = inventory[hotbar_frame_selected_index].items.get(0).inventory_img.get();
        pushMatrix();
        if (inventory[hotbar_frame_selected_index].items.get(0).type.equals("block")) {
          holding_item_image.resize(10, 10);
          translate(x-10, y+10);
          rotate(radians(-80));
        } else {
          holding_item_image.resize(25, 25);
          translate(x-7.5f, y+7.5f);
          rotate(radians((30-block_breaking_cooldown)*-4));
          translate(-12.5f, -12.5f);
          rotate(radians(-90));
        }
        image(holding_item_image, 0, 0);
        popMatrix();
      }
    }
  }
  
  public void applyGravity() {
    y_speed += g_const;
    y += y_speed;
    boolean noCollision = true;
    touching_ground = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null && detectCollision(block)) {
          noCollision = false;
        }
      }
    }
    if (!noCollision) {
      y -= y_speed;
      y_speed = 0;
      touching_ground = true;
    }
  }
  
  public boolean detectCollision (Block block) {
    if  ((x + img_right.width/2 >= block.x - block.img.width/2) &&
         (x - img_right.width/2 <= block.x + block.img.width/2) &&
         (y + img_right.height/2 >= block.y - block.img.height/2) &&
         (y - img_right.height/2 <= block.y + block.img.height/2))
    {
          return true;
    }
    return false;
  }
  
  public void checkBlockBreaking() {
    if (mousePressed && mouseButton == LEFT) {
      if (block_breaking_cooldown == 0) {
        block_breaking_cooldown = 30;
        if (!show_inventory) {
          for (int i = 0; i < blocks.length; i++) {
            for (int j = 0; j < blocks[i].length; j++) {
              if  (blocks[i][j] != null &&
                   (player.x+mouseX-width/2 >= blocks[i][j].x - blocks[i][j].img.width/2) &&
                   (player.x+mouseX-width/2 <= blocks[i][j].x + blocks[i][j].img.width/2) &&
                   (player.y+mouseY-height/2 >= blocks[i][j].y - blocks[i][j].img.height/2) &&
                   (player.y+mouseY-height/2 <= blocks[i][j].y + blocks[i][j].img.height/2))
              {
                int player_mining_level, player_mining_speed;
                if (inventory[hotbar_frame_selected_index] == null) {
                  player_mining_level = 1;
                  player_mining_speed = 40;
                } else {
                  player_mining_level = inventory[hotbar_frame_selected_index].items.get(0).mining_level;
                  player_mining_speed = inventory[hotbar_frame_selected_index].items.get(0).mining_speed;
                }
                if (blocks[i][j].mining_level <= player_mining_level) {
                  blocks[i][j].block_health -= player_mining_speed;
                  if (blocks[i][j].block_health <= 0) {
                    if (blocks[i][j].item != null) {
                      addToStack(inventory, blocks[i][j].item);
                    }
                    blocks[i][j] = null;
                  }
                }
              }
            }
          }
        }
      } else {
        block_breaking_cooldown--;
      }
    } else {
      block_breaking_cooldown = 30;
    }
  }
  
  public void drawHotbar() {
    for (int i = 0; i < 10; i++) {
      if (i == hotbar_frame_selected_index) {
        image(hotbar_frame_selected, 30+i*50, 30);
      } else {
        image(hotbar_frame, 30+i*50, 30);
      }
      if (inventory.length > i) {
        if (inventory[i] != null) {
          image(inventory[i].items.get(0).inventory_img, 30+i*50, 30);
          if (inventory[i].items.size() > 0) {
            fill(0);
            text("x"+str(inventory[i].items.size()), 30+hotbar_frame.width/2+i*50, 40);
          }
        }
      }
    }
  }
  
  public void drawInventory() {
    if (show_inventory) {
      int inventory_counter = 10;
      for (int j = 1; j < 11; j++) {
        for (int i = 0; i < 20; i++) {
          image(hotbar_frame, 30+i*40, 30+j*40);
          //if (inventory.length > j*20+i) {
            if (inventory[inventory_counter] != null) {
              image(inventory[inventory_counter].items.get(0).inventory_img, 30+i*40, 30+j*40);
              if (inventory[inventory_counter].items.size() >= 2) {
                fill(0);
                text("x"+str(inventory[inventory_counter].items.size()), 30+hotbar_frame.width/2+i*40, 40+j*40);
              }
            }
          //}
          inventory_counter++;
        }
      }
      for (int i = 0; i < crafting_controller.returnRecipes().size(); i++) {
        image(recipe_frame, 30+i*40, 550);
        image(crafting_controller.returnRecipes().get(i).img, 30+i*40, 550);
      }
    }
  }
}
class RecipePointer {
  PImage img;
  String name;
  RecipePointer(PImage _img, String _name) {
    img = _img;
    name = _name;
  }
}
class StoneBlock extends Block {
  PImage img;
  String type;
  
  StoneBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "stone_block.png", "stone", 2);
    img = loadImage("stone_block.png");
    item = new Item(loadImage("stone_block.png"), "block", "stone block", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class StoneyBlock extends Block {
  PImage img;
  String type;
  
  StoneyBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "stoney_block.png", "stoney", 2);
    img = loadImage("stoney_block.png");
    item = new Item(loadImage("stoney_block.png"), "block", "stoney block", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class TinOre extends Block {
  PImage img;
  String type;
  
  TinOre(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "tin_ore.png", "tin ore", 4);
    img = loadImage("tin_ore.png");
    item = new Item(loadImage("tin_ore.png"), "block", "tin ore", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class Torch extends Block {
  PImage img;
  String type;
  
  Torch(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "torch.png", "torch", 1);
    img = loadImage("torch.png");
    item = new Item(loadImage("torch.png"), "block", "torch", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class Wood extends Block {
  PImage img;
  String type;
  Item item;
  
  Wood(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "wood.png", "wood", 1);
    img = loadImage("wood.png");
    item = new Item(loadImage("wood.png"), "block", "wood", 1, 40);
    super.item = item;
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
class WoodBlock extends Block {
  PImage img;
  String type;
  Item item;
  
  WoodBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "wood_block.png", "wood block", 1);
    img = loadImage("wood_block.png");
    item = new Item(loadImage("wood_block.png"), "block", "wood block", 1, 40);
    super.item = item;
    //super.original_img = img.get();
    //super.img = img.get();
  }
  
  public void update(ArrayList<Light> lights) {
    for (int i = 0; i < img.width*img.height; i++) {
      super.img.pixels[i] = img.pixels[i];
    }
    super.update(lights);
  }
}
  public void settings() {  size(960, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "eox_0_3_2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
