import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class eox_0_10_22 extends PApplet {

/*
Vladimir Shevyakov
Computer Science 30
November 29, 2016

Array Lists Assignment
*/

Game game;
Block[][] blocks;
BackgroundWall[][] background_walls;
TextureManager texture_manager;
Player player;
int land_width, land_height, biome_width;
String biome_type;
float saved_alt;

public void setup() {
  
  //initiate some global variables
  land_width = 800;
  land_height = 800;
  biome_width = 200;
  biome_type = "forest";
  saved_alt = 0;
  //load the blocks and the player
  blocks = new Block[land_width][land_height];
  background_walls = new BackgroundWall[land_width][land_height];
  texture_manager = new TextureManager();
  player = new Player(400, -height/2, blocks);
  
  //instantiate a new game
  game = new Game();
}

public void draw() {
  //update the game
  game.update();
}

//take the input to the player class
public void keyPressed() {
  player.keyPressed();
}

public void keyReleased() {
  player.keyReleased();
}

public void mousePressed() {
  player.mousePressed();
}

public void mouseClicked() {
  player.mouseClicked();
}

public void updatePlayerInventory() {
  player.updateInventory();
}

public void save_world_file() {
  game.save_world();
}
class Altar extends Block {
  //a sub class of block. used instead of CustomBlock as it has an extra script.
  PImage img, img_lit;
  boolean lit;
  String type;
  
  Altar(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "altar.png", "altar", 1, null);
    img = texture_manager.get_texture("altar.png");
    img_lit = texture_manager.get_texture("altar_lit.png");
    item = new Item(texture_manager.get_texture("altar.png"), "block", "altar");
    lit = false;
  }
  
  public void update(ArrayList<Light> lights) {
    checkLit();
    if (lit) {
      super.img = img_lit.get();
      super.light = new Light(x, y, 200, color(255, 100, 100));
    } else {
      super.img = img.get();
      super.light = null;
    }
    super.update(lights);
  }

  public void checkLit() {
    lit = false;
    if (checkBlock(x_list_pos-3, y_list_pos-4, "enchanted wood") && //top
        checkBlock(x_list_pos-2, y_list_pos-5, "enchanted wood") &&
        checkBlock(x_list_pos-1, y_list_pos-6, "enchanted wood") &&
        checkBlock(x_list_pos, y_list_pos-7, "enchanted wood") &&
        checkBlock(x_list_pos+1, y_list_pos-6, "enchanted wood") &&
        checkBlock(x_list_pos+2, y_list_pos-5, "enchanted wood") &&
        checkBlock(x_list_pos+3, y_list_pos-4, "enchanted wood") &&
        
        checkBlock(x_list_pos-3, y_list_pos+1, "enchanted wood") && //foundation
        checkBlock(x_list_pos-2, y_list_pos+1, "enchanted wood") &&
        checkBlock(x_list_pos-1, y_list_pos+1, "enchanted wood") &&
        checkBlock(x_list_pos, y_list_pos+1, "enchanted wood") &&
        checkBlock(x_list_pos+1, y_list_pos+1, "enchanted wood") &&
        checkBlock(x_list_pos+2, y_list_pos+1, "enchanted wood") &&
        checkBlock(x_list_pos+3, y_list_pos+1, "enchanted wood")) {
      lit = true;
    }
  }
  
  public boolean checkBlock(int x_pos, int y_pos, String block_type) {
    return (x_list_pos > 0 && x_list_pos < blocks.length && y_list_pos > 0 && y_list_pos < blocks[0].length && (blocks[x_pos][y_pos] != null && blocks[x_pos][y_pos].type.equals(block_type)));
  }
}
class AngryCactus extends Enemy {
  float shooting_timer, max_shooting_timer;
  AngryCactus(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "angry cactus", "angry_cactus.png", 50, temp_blocks);
    attack = 5;
    health = 40;
    max_health = 40;
    speed = 3;
    attack_cooldown = 50;
    max_shooting_timer = 50;
  }
  
  public void update(Player player) {
    if (shooting_timer == 0) {
      game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, 500, "angry_cactus_bullet.png", 5, 0, true));
      shooting_timer = max_shooting_timer;
    } else {
      shooting_timer--;
    }
    super.update(player);
    if (super.is_dead) {
      float[] bullet_directions = new float[16];
      for (float i = 0; i < 360; i += 22.5f) {
        bullet_directions[PApplet.parseInt(i/22.5f)] = i;
      }
      for (float i : bullet_directions) {
        game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, i, 500, "angry_cactus_bullet.png", 5, 0, true));
      }
    }
  }
}
class BackgroundWall {
  //the parent class for all blocks
  
  //global variables
  float x, y;
  PImage original_img, img;
  int x_list_pos, y_list_pos;
  String type, img_name;
  float blockBrightness;
  int currentLightColor;
  
  BackgroundWall(float _x, float _y, int _x_list_pos, int _y_list_pos, String img_name, String _type) {
    //init global variables
    x = _x;
    y = _y;
    original_img = texture_manager.get_texture(img_name);
    img = original_img.get();
    x_list_pos = _x_list_pos;
    y_list_pos = _y_list_pos;
    type = _type;
  }
  
  public void update(ArrayList<Light> lights) {
    roughLighting(lights);
    display();
  }
  
  public void roughLighting(ArrayList<Light> lights) {
    //rough lightning function
    blockBrightness = 0;
    float temp_r = 0;
    float temp_g = 0;
    float temp_b = 0;
    int light_amount = 0;
    for (Light light : lights) {
      float dist_to_light = dist(x, y, light.x, light.y);
      float current_light_intensity = constrain(light.intensity/pow(dist_to_light/50, 2), 0, light.intensity);
      float tempBrightness = current_light_intensity/10;
      blockBrightness = max(blockBrightness, tempBrightness);
      if (dist_to_light < light.intensity) {
        temp_r += red(light.lightColor)*current_light_intensity;
        temp_g += green(light.lightColor)*current_light_intensity;
        temp_b += blue(light.lightColor)*current_light_intensity;
        light_amount += current_light_intensity;
      }
    }
    temp_r /= light_amount;
    temp_g /= light_amount;
    temp_b /= light_amount;
    currentLightColor = color(temp_r, temp_g, temp_b);
  }
  
  public void display() {
    imageMode(CENTER);
    tint(currentLightColor);
    image(img, x, y);
    noTint();
    rectMode(CENTER);
    fill(0, 0, 0, 255-blockBrightness*25);
    rect(x, y, 20, 20);
  }
}
class Block {
  //the parent class for all blocks
  
  //global variables
  float x, y;
  PImage img;
  int x_list_pos, y_list_pos;
  String type;
  Item item;
  float block_health, max_block_health;
  int mining_level;
  PImage[] block_breaking_imgs = new PImage[4];
  Light light;
  float blockBrightness;
  int currentLightColor;
  boolean collisionPossible;
  float level = -1; //lava and water blocks
  
  Block(float _x, float _y, int _x_list_pos, int _y_list_pos, String img_name, String _type, int _mining_level, Light _light) {
    //init global variables
    x = _x;
    y = _y;
    img = texture_manager.get_texture(img_name);
    x_list_pos = _x_list_pos;
    y_list_pos = _y_list_pos;
    type = _type;
    max_block_health = 100;
    block_health = max_block_health;
    mining_level = _mining_level;
    //the block-breaking images are a mostly transparent PNG with cracks of various length - it is
    //utilized to make a block-breaking animation without having to make 4 different images of the same
    //block in various states of deterioration.
    for (int i = 0; i < block_breaking_imgs.length; i++) {
      block_breaking_imgs[i] = texture_manager.get_texture("block_breaking_" + str(i+1) + ".png");
    }
    light = _light;
    collisionPossible = true;
  }
  
  public void update(ArrayList<Light> lights) {
    if (light == null) {
      roughLighting(lights);
    }
    //display(lights);
    if (!type.equals("lava") && level != -1) {
      exit();
    }
  }
  
  public void roughLighting(ArrayList<Light> lights) {
    //rough lightning function
    blockBrightness = 0;
    float temp_r = 0;
    float temp_g = 0;
    float temp_b = 0;
    int light_amount = 0;
    for (Light light : lights) {
      float dist_to_light = dist(x, y, light.x, light.y);
      float current_light_intensity = constrain(light.intensity/pow(dist_to_light/50, 2), 0, light.intensity);
      float tempBrightness = current_light_intensity/10;
      blockBrightness = max(blockBrightness, tempBrightness);
      if (dist_to_light < light.intensity) {
        temp_r += red(light.lightColor)*current_light_intensity;
        temp_g += green(light.lightColor)*current_light_intensity;
        temp_b += blue(light.lightColor)*current_light_intensity;
        light_amount += current_light_intensity;
      }
    }
    temp_r /= light_amount;
    temp_g /= light_amount;
    temp_b /= light_amount;
    currentLightColor = color(temp_r, temp_g, temp_b);
  }
  
  public void display(ArrayList<Light> lights) {
    //displays the image and checks if blitting a block-breaking animation is necessary
    imageMode(CENTER);
    if (!type.equals("lava") && light == null) {
      tint(currentLightColor);
    }
    image(img, x, y);
    noTint();
    if (block_health > 0 && block_health <= max_block_health*0.2f) {
      image(block_breaking_imgs[3], x, y);
    } else if (block_health > max_block_health*0.2f && block_health <= max_block_health*0.4f) {
      image(block_breaking_imgs[2], x, y);
    } else if (block_health > max_block_health*0.4f && block_health <= max_block_health*0.6f) {
      image(block_breaking_imgs[1], x, y);
    } else if (block_health > max_block_health*0.6f && block_health <= max_block_health*0.8f) {
      image(block_breaking_imgs[0], x, y);
    }
    if (!type.equals("lava") && light == null) {
      rectMode(CENTER);
      fill(0, 0, 0, 255-blockBrightness*25);
      rect(x, y, 20, 20);
    }
  }
  
  public void kill() {
    blocks[x_list_pos][y_list_pos] = null;
  }
}
class Button {
  PImage img, hovered_img;
  float x, y;
  boolean clicked;

  Button(float _x, float _y, String image_name) {
    x = _x;
    y = _y;
    img = texture_manager.get_texture(image_name);
    clicked = false;
  }
  
  Button(float _x, float _y, String image_name, String image_hovered_name) {
    x = _x;
    y = _y;
    img = texture_manager.get_texture(image_name);
    hovered_img = texture_manager.get_texture(image_hovered_name);
    clicked = false;
  }

  public void display() {
    if (mouseOn() && mousePressed) {
      clicked = true;
    }
    
    if ((hovered_img != null) && mouseOn()) {
      image(hovered_img, x, y);
    } else {
      image(img, x, y);
    }
  }

  public boolean mouseOn () {
    if ((mouseX > x - img.width/2) &&
        (mouseX < x + img.width/2) &&
        (mouseY > y - img.height/2) &&
        (mouseY < y + img.height/2)) {
      return true;
    } else {
      return false;
    }
  }
}
class CactusBlock extends Block {
  //a sub class of block. used instead of CustomBlock as it has an extra script.
  PImage img;
  String type;
  
  CactusBlock(float _x, float _y, int _x_list_pos, int _y_list_pos, String rotation) {
    super(_x, _y, _x_list_pos, _y_list_pos, "cactus_" + rotation + ".png", "cactus", 1, null);
    img = texture_manager.get_texture("cactus_" + rotation + ".png");
    item = new Item(texture_manager.get_texture("cactus_" + rotation + ".png"), "block", "cactus block");
    super.item = item;
  }
  
  //update the block
  public void update(ArrayList<Light> lights) {
    if (dist(player.x, player.y, x, y) < 20) {
      player.health--;
    }
    super.img = img.get();
    super.update(lights);
  }
}
class CraftingController {
  //the class that takes care of all the crafting. some of the most complicated
  //coding I have done so it is rather inefficient.
  
  //the one and only global variable
  ItemStack[] inventory, previous_inventory;
  ArrayList<String> recipe_image_names = new ArrayList<String>();
  ArrayList<PImage> recipe_images = new ArrayList<PImage>();
  
  CraftingController(ItemStack[] _inventory) {
    inventory = _inventory;
    previous_inventory = new ItemStack[inventory.length];
    for (int i = 0; i < inventory.length; i++) {
      previous_inventory[i] = inventory[i];
    }
    load_images();
  }
  
  public void load_images() {
    recipe_image_names.add("woodBlock_To_Wood");
    recipe_image_names.add("wood_To_CraftingBench");
    recipe_image_names.add("wood_To_WoodenPicaxe");
    recipe_image_names.add("wood_To_WoodenSword");
    recipe_image_names.add("woodAndStone_To_StonePicaxe");
    recipe_image_names.add("stone_To_StoneSword");
    recipe_image_names.add("woodAndCoal_To_Torch");
    recipe_image_names.add("torch_To_Campfire");
    recipe_image_names.add("stoneAndWoodAndCampfire_To_Furnace");
    recipe_image_names.add("copperOre_To_CopperIngot");
    recipe_image_names.add("woodAndCopper_To_CopperPicaxe");
    recipe_image_names.add("tinOre_To_TinIngot");
    recipe_image_names.add("copperIngotAndTinIngotAndCampfire_To_AlloySmelter");
    recipe_image_names.add("copperIngotAndTinIngot_To_BronzeIngot");
    recipe_image_names.add("woodAndBronze_To_BronzePicaxe");
    recipe_image_names.add("ironOre_To_IronIngot");
    recipe_image_names.add("ironIngotAndBronzeIngot_To_ToolStation");
    recipe_image_names.add("woodAndIron_To_IronPicaxe");
    recipe_image_names.add("wood_To_Coal");
    recipe_image_names.add("ironIngotAndBronzeIngotAndCoal_To_SteelIngot");
    recipe_image_names.add("woodAndSteel_To_SteelPicaxe");
    recipe_image_names.add("rubyAndSapphireAndTopazAndAmethyst_To_CelestialStone");
    recipe_image_names.add("copperIngot_To_CopperSword");
    recipe_image_names.add("bronzeIngot_To_BronzeSword");
    recipe_image_names.add("ironIngot_To_IronSword");
    recipe_image_names.add("steel_To_SteelSword");
    recipe_image_names.add("ironIngotAndBronzeIngotAndTorch_To_GoblinOfMisery");
    
    recipe_image_names.add("copper_To_CopperArmor");
    recipe_image_names.add("bronze_To_BronzeArmor");
    recipe_image_names.add("iron_To_IronArmor");
    recipe_image_names.add("steel_To_SteelArmor");
    
    recipe_images.add(texture_manager.get_texture("wood.png"));
    recipe_images.add(texture_manager.get_texture("crafting_bench.png"));
    recipe_images.add(texture_manager.get_texture("wooden_picaxe.png"));
    recipe_images.add(texture_manager.get_texture("wooden_sword.png"));
    recipe_images.add(texture_manager.get_texture("stone_picaxe.png"));
    recipe_images.add(texture_manager.get_texture("stone_sword.png"));
    recipe_images.add(texture_manager.get_texture("torch.png"));
    recipe_images.add(texture_manager.get_texture("campfire.png"));
    recipe_images.add(texture_manager.get_texture("furnace.png"));
    recipe_images.add(texture_manager.get_texture("copper_ingot.png"));
    recipe_images.add(texture_manager.get_texture("copper_picaxe.png"));
    recipe_images.add(texture_manager.get_texture("tin_ingot.png"));
    recipe_images.add(texture_manager.get_texture("alloy_smelter.png"));
    recipe_images.add(texture_manager.get_texture("bronze_ingot.png"));
    recipe_images.add(texture_manager.get_texture("bronze_picaxe.png"));
    recipe_images.add(texture_manager.get_texture("iron_ingot.png"));
    recipe_images.add(texture_manager.get_texture("tool_station.png"));
    recipe_images.add(texture_manager.get_texture("iron_picaxe.png"));
    recipe_images.add(texture_manager.get_texture("coal.png"));
    recipe_images.add(texture_manager.get_texture("steel_ingot.png"));
    recipe_images.add(texture_manager.get_texture("steel_picaxe.png"));
    recipe_images.add(texture_manager.get_texture("celestial_stone.png"));
    recipe_images.add(texture_manager.get_texture("copper_sword.png"));
    recipe_images.add(texture_manager.get_texture("bronze_sword.png"));
    recipe_images.add(texture_manager.get_texture("iron_sword.png"));
    recipe_images.add(texture_manager.get_texture("steel_sword.png"));
    recipe_images.add(texture_manager.get_texture("goblin.png"));
    
    recipe_images.add(texture_manager.get_texture("copper_armor.png"));
    recipe_images.add(texture_manager.get_texture("bronze_armor.png"));
    recipe_images.add(texture_manager.get_texture("iron_armor.png"));
    recipe_images.add(texture_manager.get_texture("steel_armor.png"));
  }
  
  public PImage return_crafting_image(String name) {
    for (int i = 0; i < recipe_image_names.size(); i++) {
      if (recipe_image_names.get(i).equals(name)) {
        return recipe_images.get(i);
      }
    }
    return null;
  }
  
  //adds an item to the inventory - first checks if a stack
  //of items of the same type already exists (in which case it
  //adds the item to the stack), or creates a new stack of items
  //of that type
  public void addToStack(ItemStack[] inventory, Item item) {
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (inventory[i].items.get(0).name.equals(item.name)) {
          inventory[i].items.add(item);
          return;
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] == null) {
        inventory[i] = new ItemStack(item, 1);
        return;
      }
    }
  }
  
  //returns a list of RecipePointers (see that class) to essentially tell
  //the player what recipies can be executed
  public ArrayList<RecipePointer> returnRecipes() {
    ArrayList<RecipePointer> return_pointers = new ArrayList<RecipePointer>();
    if (woodBlock_To_Wood(false) != null) {
      return_pointers.add(new RecipePointer(woodBlock_To_Wood(false), "wood block to wood"));
    }
    if (wood_To_CraftingBench(false) != null) {
      return_pointers.add(new RecipePointer(wood_To_CraftingBench(false), "wood to crafting bench"));
    }
    if (wood_To_WoodenPicaxe(false) != null) {
      return_pointers.add(new RecipePointer(wood_To_WoodenPicaxe(false), "wood to wooden picaxe"));
    }
    if (wood_To_WoodenSword(false) != null) {
      return_pointers.add(new RecipePointer(wood_To_WoodenSword(false), "wood to wooden sword"));
    }
    if (woodAndStone_To_StonePicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndStone_To_StonePicaxe(false), "wood and stone to stone picaxe"));
    }
    if (stone_To_StoneSword(false) != null) {
      return_pointers.add(new RecipePointer(stone_To_StoneSword(false), "stone to stone sword"));
    }
    if (woodAndCoal_To_Torch(false) != null) {
      return_pointers.add(new RecipePointer(woodAndCoal_To_Torch(false), "wood and coal to torch"));
    }
    if (torch_To_Campfire(false) != null) {
      return_pointers.add(new RecipePointer(torch_To_Campfire(false), "torch to campfire"));
    }
    if (stoneAndWoodAndCampfire_To_Furnace(false) != null) {
      return_pointers.add(new RecipePointer(stoneAndWoodAndCampfire_To_Furnace(false), "stone and wood and campfire to furnace"));
    }
    if (copperOre_To_CopperIngot(false) != null) {
      return_pointers.add(new RecipePointer(copperOre_To_CopperIngot(false), "copper ore to copper ingot"));
    }
    if (woodAndCopper_To_CopperPicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndCopper_To_CopperPicaxe(false), "wood and copper to copper picaxe"));
    }
    if (copperIngot_To_CopperSword(false) != null) {
      return_pointers.add(new RecipePointer(copperIngot_To_CopperSword(false), "copper ingot to copper sword"));
    }
    if (tinOre_To_TinIngot(false) != null) {
      return_pointers.add(new RecipePointer(tinOre_To_TinIngot(false), "tin ore to tin ingot"));
    }
    if (copperIngotAndTinIngotAndCampfire_To_AlloySmelter(false) != null) {
      return_pointers.add(new RecipePointer(copperIngotAndTinIngotAndCampfire_To_AlloySmelter(false), "copper ingot and tin ingot and campfire to alloy smelter"));
    }
    if (copperIngotAndTinIngot_To_BronzeIngot(false) != null) {
      return_pointers.add(new RecipePointer(copperIngotAndTinIngot_To_BronzeIngot(false), "copper ingot and tin ingot to bronze ingot"));
    }
    if (woodAndBronze_To_BronzePicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndBronze_To_BronzePicaxe(false), "wood and bronze to bronze picaxe"));
    }
    if (bronzeIngot_To_BronzeSword(false) != null) {
      return_pointers.add(new RecipePointer(bronzeIngot_To_BronzeSword(false), "bronze ingot to bronze sword"));
    }
    if (ironOre_To_IronIngot(false) != null) {
      return_pointers.add(new RecipePointer(ironOre_To_IronIngot(false), "iron ore to iron ingot"));
    }
    if (ironIngotAndBronzeIngot_To_ToolStation(false) != null) {
      return_pointers.add(new RecipePointer(ironIngotAndBronzeIngot_To_ToolStation(false), "iron and bronze to tool station"));
    }
    if (woodAndIron_To_IronPicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndIron_To_IronPicaxe(false), "wood and iron to iron picaxe"));
    }
    if (ironIngot_To_IronSword(false) != null) {
      return_pointers.add(new RecipePointer(ironIngot_To_IronSword(false), "iron ingot to iron sword"));
    }
    if (wood_To_Coal(false) != null) {
      return_pointers.add(new RecipePointer(wood_To_Coal(false), "wood to coal"));
    }
    if (ironIngotAndBronzeIngotAndCoal_To_SteelIngot(false) != null) {
      return_pointers.add(new RecipePointer(ironIngotAndBronzeIngotAndCoal_To_SteelIngot(false), "iron ingot and bronze and coal to steel ingot"));
    }
    if (woodAndSteel_To_SteelPicaxe(false) != null) {
      return_pointers.add(new RecipePointer(woodAndSteel_To_SteelPicaxe(false), "wood and steel to steel picaxe"));
    }
    if (steel_To_SteelSword(false) != null) {
      return_pointers.add(new RecipePointer(steel_To_SteelSword(false), "steel to steel sword"));
    }
    if (rubyAndSapphireAndTopazAndAmethyst_To_CelestialStone(false) != null) {
      return_pointers.add(new RecipePointer(rubyAndSapphireAndTopazAndAmethyst_To_CelestialStone(false), "ruby and sapphire and topaz and amethyst to celestial stone"));
    }
    if (ironIngotAndBronzeIngotAndTorch_To_GoblinOfMisery(false) != null) {
      return_pointers.add(new RecipePointer(ironIngotAndBronzeIngotAndTorch_To_GoblinOfMisery(false), "iron ingot and bronze ingot and torch to goblin of misery"));
    }
    if (copper_To_CopperArmor(false) != null) {
      return_pointers.add(new RecipePointer(copper_To_CopperArmor(false), "copper ingot to copper armor"));
    }
    if (bronze_To_BronzeArmor(false) != null) {
      return_pointers.add(new RecipePointer(bronze_To_BronzeArmor(false), "bronze ingot to bronze armor"));
    }
    if (iron_To_IronArmor(false) != null) {
      return_pointers.add(new RecipePointer(iron_To_IronArmor(false), "iron ingot to iron armor"));
    }
    if (steel_To_SteelArmor(false) != null) {
      return_pointers.add(new RecipePointer(steel_To_SteelArmor(false), "steel ingot to steel armor"));
    }
    return return_pointers;
  }
  
  //executes the recipe if the player clicks on it
  public void executeRecipe(RecipePointer recipe_pointer) {
    if (recipe_pointer.name.equals("wood block to wood")) {
      woodBlock_To_Wood(true);
    }
    else if (recipe_pointer.name.equals("wood to crafting bench")) {
      wood_To_CraftingBench(true);
    }
    else if (recipe_pointer.name.equals("wood to wooden picaxe")) {
      wood_To_WoodenPicaxe(true);
    }
    else if (recipe_pointer.name.equals("wood to wooden sword")) {
      wood_To_WoodenSword(true);
    }
    else if (recipe_pointer.name.equals("wood and stone to stone picaxe")) {
      woodAndStone_To_StonePicaxe(true);
    }
    else if (recipe_pointer.name.equals("stone to stone sword")) {
      stone_To_StoneSword(true);
    }
    else if (recipe_pointer.name.equals("wood and coal to torch")) {
      woodAndCoal_To_Torch(true);
    }
    else if (recipe_pointer.name.equals("torch to campfire")) {
      torch_To_Campfire(true);
    }
    else if (recipe_pointer.name.equals("stone and wood and campfire to furnace")) {
      stoneAndWoodAndCampfire_To_Furnace(true);
    }
    else if (recipe_pointer.name.equals("copper ore to copper ingot")) {
      copperOre_To_CopperIngot(true);
    }
    else if (recipe_pointer.name.equals("wood and copper to copper picaxe")) {
      woodAndCopper_To_CopperPicaxe(true);
    }
    else if (recipe_pointer.name.equals("copper ingot to copper sword")) {
      copperIngot_To_CopperSword(true);
    }
    else if (recipe_pointer.name.equals("tin ore to tin ingot")) {
      tinOre_To_TinIngot(true);
    }
    else if (recipe_pointer.name.equals("copper ingot and tin ingot and campfire to alloy smelter")) {
      copperIngotAndTinIngotAndCampfire_To_AlloySmelter(true);
    }
    else if (recipe_pointer.name.equals("copper ingot and tin ingot to bronze ingot")) {
      copperIngotAndTinIngot_To_BronzeIngot(true);
    }
    else if (recipe_pointer.name.equals("wood and bronze to bronze picaxe")) {
      woodAndBronze_To_BronzePicaxe(true);
    }
    else if (recipe_pointer.name.equals("bronze ingot to bronze sword")) {
      bronzeIngot_To_BronzeSword(true);
    }
    else if (recipe_pointer.name.equals("iron ore to iron ingot")) {
      ironOre_To_IronIngot(true);
    }
    else if (recipe_pointer.name.equals("iron and bronze to tool station")) {
      ironIngotAndBronzeIngot_To_ToolStation(true);
    }
    else if (recipe_pointer.name.equals("iron ingot to iron sword")) {
      ironIngot_To_IronSword(true);
    }
    else if (recipe_pointer.name.equals("wood and iron to iron picaxe")) {
      woodAndIron_To_IronPicaxe(true);
    }
    else if (recipe_pointer.name.equals("wood to coal")) {
      wood_To_Coal(true);
    }
    else if (recipe_pointer.name.equals("iron ingot and bronze and coal to steel ingot")) {
      ironIngotAndBronzeIngotAndCoal_To_SteelIngot(true);
    }
    else if (recipe_pointer.name.equals("wood and steel to steel picaxe")) {
      woodAndSteel_To_SteelPicaxe(true);
    }
    else if (recipe_pointer.name.equals("steel to steel sword")) {
      steel_To_SteelSword(true);
    }
    else if (recipe_pointer.name.equals("ruby and sapphire and topaz and amethyst to celestial stone")) {
      rubyAndSapphireAndTopazAndAmethyst_To_CelestialStone(true);
    }
    else if (recipe_pointer.name.equals("iron ingot and bronze ingot and torch to goblin of misery")) {
      ironIngotAndBronzeIngotAndTorch_To_GoblinOfMisery(true);
    }
    else if (recipe_pointer.name.equals("copper ingot to copper armor")) {
      copper_To_CopperArmor(true);
    }
    else if (recipe_pointer.name.equals("bronze ingot to bronze armor")) {
      bronze_To_BronzeArmor(true);
    }
    else if (recipe_pointer.name.equals("iron ingot to iron armor")) {
      iron_To_IronArmor(true);
    }
    else if (recipe_pointer.name.equals("steel ingot to steel armor")) {
      steel_To_SteelArmor(true);
    }
  }
  
  //checks if the player is standing on a certain block. used for some crafting recipies
  public boolean onBlock(String block_name) {
    boolean standingOnBlock = false;
    for (Block[] block_row : blocks) {
      for (Block block : block_row) {
        if (block != null) {
          if (block.x < player.x+20 && block.x > player.x-20 && block.y > player.y+player.img_right.height/2 && block.y < player.y+player.img_right.height/2+40 && block.type.equals(block_name)) {
            standingOnBlock = true;
            break;
          }
        }
      }
    }
    return standingOnBlock;
  }
  
  public PImage craft (boolean real, PImage return_image, String[] in_types, int[] in_amounts, Item[] out_items, int[] out_amounts, String crafting_station_name) {
    int[] item_positions = new int[in_amounts.length];
    for (int i = 0; i < item_positions.length; i++) {
      item_positions[i] = -1;
    }
    
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        for (int j = 0; j < in_types.length; j++) {
          if (inventory[i].items.get(0).name.equals(in_types[j])) {
            item_positions[j] = i;
          }
        }
      }
    }
    
    boolean possible = true;
    for (int i : item_positions) {
      if (i == -1) {
        possible = false;
      }
    }
    if (possible) {
      for (int i = 0; i < in_types.length; i++) {
        if (inventory[item_positions[i]].items.size() < in_amounts[i]) {
          possible = false;
        }
      }
    }
    
    if (possible && (crafting_station_name == null || onBlock(crafting_station_name))) {
      if (!real) {
        return return_image;
      } else {
        for (int i = 0; i < in_amounts.length; i++) {
          for (int j = 0; j < in_amounts[i]; j++) {
            inventory[item_positions[i]].items.remove(0);
          }
          if (inventory[item_positions[i]].items.size() <= 0) {
            inventory[item_positions[i]] = null;
          }
        }
        for (int m = 0; m < out_items.length; m++) {
          for (int n = 0; n < out_amounts[m]; n++) {
            addToStack(inventory, out_items[m]);
          }
        }
        return null;
      }
    }
        
    return null;
  }
  
  //all of the PImage functions below will either execute of say if they can return
  //a recipe. if boolean real is true, then the recipe is executed if the player has
  //the items needed. if it is false, then it returns a PImage with the icon of the
  //item the player is trying to craft.
  
  //block of wood to 2 wood
  public PImage woodBlock_To_Wood (boolean real) {
    PImage return_image = return_crafting_image("woodBlock_To_Wood");
    String[] in_types = {"wood block"};
    int[] in_amounts = {1};
    Item[] out_items = {new Item(return_image, "block", "wood")};
    int[] out_amounts = {2};
    //return oneIn(real, return_image, "wood block", 1, out_items, out_amounts, null);
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, null);
  }
  
  //4 wood to crafting bench
  public PImage wood_To_CraftingBench (boolean real) {
    PImage return_image = return_crafting_image("wood_To_CraftingBench");
    String[] in_types = {"wood"};
    int[] in_amounts = {4};
    Item[] out_items = {new Item(return_image, "block", "crafting bench")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, null);
  }
  
  //8 wood to wooden picaxe - requires crafting bench
  public PImage wood_To_WoodenPicaxe (boolean real) {
    PImage return_image = return_crafting_image("wood_To_WoodenPicaxe");
    String[] in_types = {"wood"};
    int[] in_amounts = {8};
    Item[] out_items = {new Item(return_image, "wood picaxe", 2, 60, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //10 wood to wooden sword - requires crafting bench
  public PImage wood_To_WoodenSword (boolean real) {
    PImage return_image = return_crafting_image("wood_To_WoodenSword");
    String[] in_types = {"wood"};
    int[] in_amounts = {10};
    Item[] out_items = {new Item(return_image, "wooden sword", 2, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //8 wood and 12 stone to stone picaxe - requires crafting bench
  public PImage woodAndStone_To_StonePicaxe (boolean real) {
    PImage return_image = return_crafting_image("woodAndStone_To_StonePicaxe");
    String[] in_types = {"wood", "stone block"};
    int[] in_amounts = {8, 12};
    Item[] out_items = {new Item(return_image, "stone picaxe", 3, 60, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //4 wood and 1 coal to 10 torches
  public PImage woodAndCoal_To_Torch (boolean real) {
    PImage return_image = return_crafting_image("woodAndCoal_To_Torch");
    String[] in_types = {"wood", "coal"};
    int[] in_amounts = {4, 1};
    Item[] out_items = {new Item(return_image, "block", "torch")};
    int[] out_amounts = {10};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, null);
  }
  
  //25 torches to 1 campfire
  public PImage torch_To_Campfire (boolean real) {
    PImage return_image = return_crafting_image("torch_To_Campfire");
    String[] in_types = {"torch"};
    int[] in_amounts = {25};
    Item[] out_items = {new Item(return_image, "block", "campfire")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, null);
  }
  
  //25 stone, 10 wood and 2 campfires to a furnace - requires crafting bench
  public PImage stoneAndWoodAndCampfire_To_Furnace (boolean real) {
    PImage return_image = return_crafting_image("stoneAndWoodAndCampfire_To_Furnace");
    String[] in_types = {"stone block", "wood", "campfire"};
    int[] in_amounts = {25, 10, 2};
    Item[] out_items = {new Item(return_image, "block", "furnace")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //3 copper or to copper ingot - requires furnace
  public PImage copperOre_To_CopperIngot (boolean real) {
    PImage return_image = return_crafting_image("copperOre_To_CopperIngot");
    String[] in_types = {"copper ore"};
    int[] in_amounts = {1};
    Item[] out_items = {new Item(return_image, "item", "copper ingot")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "furnace");
  }
  
  //10 wood and 5 copper ingots to copper picaxe - requires crafting bench
  public PImage woodAndCopper_To_CopperPicaxe (boolean real) {
    PImage return_image = return_crafting_image("woodAndCopper_To_CopperPicaxe");
    String[] in_types = {"wood", "copper ingot"};
    int[] in_amounts = {10, 5};
    Item[] out_items = {new Item(return_image, "copper picaxe", 4, 80, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //4 tin ore to tin ingot - requires furnace
  public PImage tinOre_To_TinIngot (boolean real) {
    PImage return_image = return_crafting_image("tinOre_To_TinIngot");
    String[] in_types = {"tin ore"};
    int[] in_amounts = {1};
    Item[] out_items = {new Item(return_image, "item", "tin ingot")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "furnace");
  }
  
  //10 copper ingots, 5 tin ingots and 3 campfires to alloy smelter - requires crafting bench
  public PImage copperIngotAndTinIngotAndCampfire_To_AlloySmelter (boolean real) {
    PImage return_image = return_crafting_image("copperIngotAndTinIngotAndCampfire_To_AlloySmelter");
    String[] in_types = {"copper ingot", "tin ingot", "campfire"};
    int[] in_amounts = {10, 5, 3};
    Item[] out_items = {new Item(return_image, "block", "alloy smelter")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //3 copper ingots and 1 tin ingot to 1 bronze ingot - requires alloy smelter
  public PImage copperIngotAndTinIngot_To_BronzeIngot (boolean real) {
    PImage return_image = return_crafting_image("copperIngotAndTinIngot_To_BronzeIngot");
    String[] in_types = {"copper ingot", "tin ingot"};
    int[] in_amounts = {3, 1};
    Item[] out_items = {new Item(return_image, "item", "bronze ingot")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "alloy smelter");
  }
  
  //20 wood and 7 bronze ingots to bronze picaxe - requires crafting bench
  public PImage woodAndBronze_To_BronzePicaxe (boolean real) {
    PImage return_image = return_crafting_image("woodAndBronze_To_BronzePicaxe");
    String[] in_types = {"wood", "bronze ingot"};
    int[] in_amounts = {20, 7};
    Item[] out_items = {new Item(return_image, "bronze picaxe", 5, 100, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //5 iron ore to iron ingot - requires furnace
  public PImage ironOre_To_IronIngot (boolean real) {
    PImage return_image = return_crafting_image("ironOre_To_IronIngot");
    String[] in_types = {"iron ore"};
    int[] in_amounts = {1};
    Item[] out_items = {new Item(return_image, "item", "iron ingot")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "furnace");
  }
  
  //5 iron ingots and 5 bronze ingots to tool station - requires crafting bench
  public PImage ironIngotAndBronzeIngot_To_ToolStation (boolean real) {
    PImage return_image = return_crafting_image("ironIngotAndBronzeIngot_To_ToolStation");
    String[] in_types = {"iron ingot", "bronze ingot"};
    int[] in_amounts = {5, 5};
    Item[] out_items = {new Item(return_image, "block", "tool station")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //25 wood and 10 iron ingots to iron picaxe - requires tool station
  public PImage woodAndIron_To_IronPicaxe (boolean real) {
    PImage return_image = return_crafting_image("woodAndIron_To_IronPicaxe");
    String[] in_types = {"wood", "iron ingot"};
    int[] in_amounts = {25, 10};
    Item[] out_items = {new Item(return_image, "iron picaxe", 6, 120, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  //5 wood to 1 coal - requires furnace
  public PImage wood_To_Coal (boolean real) {
    PImage return_image = return_crafting_image("wood_To_Coal");
    String[] in_types = {"wood"};
    int[] in_amounts = {5};
    Item[] out_items = {new Item(return_image, "item", "coal")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "furnace");
  }
  
  //3 iron ingots and 2 bronze ingot and 4 coal to 2 steel ingots - requires alloy smelter
  public PImage ironIngotAndBronzeIngotAndCoal_To_SteelIngot (boolean real) {
    PImage return_image = return_crafting_image("ironIngotAndBronzeIngotAndCoal_To_SteelIngot");
    String[] in_types = {"iron ingot", "bronze ingot", "coal"};
    int[] in_amounts = {3, 2, 4};
    Item[] out_items = {new Item(return_image, "item", "steel ingot")};
    int[] out_amounts = {2};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "alloy smelter");
  }
  
  //15 wood and 5 steel ingots to steel picaxe - requires tool station
  public PImage woodAndSteel_To_SteelPicaxe (boolean real) {
    PImage return_image = return_crafting_image("woodAndSteel_To_SteelPicaxe");
    String[] in_types = {"wood", "steel ingot"};
    int[] in_amounts = {15, 5};
    Item[] out_items = {new Item(return_image, "steel picaxe", 7, 140, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  //ruby, sapphire, topaz and amethyst to celestial stone
  public PImage rubyAndSapphireAndTopazAndAmethyst_To_CelestialStone (boolean real) {
    PImage return_image = return_crafting_image("rubyAndSapphireAndTopazAndAmethyst_To_CelestialStone");
    String[] in_types = {"ruby", "sapphire", "topaz", "amethyst"};
    int[] in_amounts = {1, 1, 1, 1};
    Item[] out_items = {new Item(return_image, "item", "celestial stone")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //15 stone to stone sword - requires crafting bench
  public PImage stone_To_StoneSword (boolean real) {
    PImage return_image = return_crafting_image("stone_To_StoneSword");
    String[] in_types = {"stone block"};
    int[] in_amounts = {15};
    Item[] out_items = {new Item(return_image, "stone sword", 4, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //7 copper to copper sword - requires crafting bench
  public PImage copperIngot_To_CopperSword (boolean real) {
    PImage return_image = return_crafting_image("copperIngot_To_CopperSword");
    String[] in_types = {"copper ingot"};
    int[] in_amounts = {7};
    Item[] out_items = {new Item(return_image, "copper sword", 6, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //10 bronze to  sword - requires crafting bench
  public PImage bronzeIngot_To_BronzeSword (boolean real) {
    PImage return_image = return_crafting_image("bronzeIngot_To_BronzeSword");
    String[] in_types = {"bronze ingot"};
    int[] in_amounts = {10};
    Item[] out_items = {new Item(return_image, "bronze sword", 8, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "crafting bench");
  }
  
  //12 iron to iron sword - requires tool station
  public PImage ironIngot_To_IronSword (boolean real) {
    PImage return_image = return_crafting_image("ironIngot_To_IronSword");
    String[] in_types = {"iron ingot"};
    int[] in_amounts = {12};
    Item[] out_items = {new Item(return_image, "iron sword", 10, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  //8 steel to steel sword - requires tool station
  public PImage steel_To_SteelSword (boolean real) {
    PImage return_image = return_crafting_image("steel_To_SteelSword");
    String[] in_types = {"steel ingot"};
    int[] in_amounts = {8};
    Item[] out_items = {new Item(return_image, "steel sword", 12, 30, 1.25f)};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  public PImage ironIngotAndBronzeIngotAndTorch_To_GoblinOfMisery (boolean real) {
    PImage return_image = return_crafting_image("ironIngotAndBronzeIngotAndTorch_To_GoblinOfMisery");
    String[] in_types = {"iron ingot", "bronze ingot", "torch"};
    int[] in_amounts = {20, 16, 1};
    Item[] out_items = {new Item(return_image, "summoning", "cyclops summoning")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  public PImage copper_To_CopperArmor (boolean real) {
    PImage return_image = return_crafting_image("copper_To_CopperArmor");
    String[] in_types = {"copper ingot"};
    int[] in_amounts = {5};
    Item[] out_items = {new Item(return_image, "armor", "copper armor")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  public PImage bronze_To_BronzeArmor (boolean real) {
    PImage return_image = return_crafting_image("bronze_To_BronzeArmor");
    String[] in_types = {"bronze ingot"};
    int[] in_amounts = {5};
    Item[] out_items = {new Item(return_image, "armor", "bronze armor")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  public PImage iron_To_IronArmor (boolean real) {
    PImage return_image = return_crafting_image("iron_To_IronArmor");
    String[] in_types = {"iron ingot"};
    int[] in_amounts = {5};
    Item[] out_items = {new Item(return_image, "armor", "iron armor")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
  
  public PImage steel_To_SteelArmor (boolean real) {
    PImage return_image = return_crafting_image("steel_To_SteelArmor");
    String[] in_types = {"steel ingot"};
    int[] in_amounts = {5};
    Item[] out_items = {new Item(return_image, "armor", "steel armor")};
    int[] out_amounts = {1};
    return craft(real, return_image, in_types, in_amounts, out_items, out_amounts, "tool station");
  }
}
class CustomBackgroundWall extends BackgroundWall {
  //a sub class of block used for most blocks. extremely customizable
  PImage img;
  String type;
  
  //constructor if the block drops itself
  CustomBackgroundWall(float _x, float _y, int _x_list_pos, int _y_list_pos, String _img_name, String block_name) {
    super(_x, _y, _x_list_pos, _y_list_pos, _img_name, block_name);
    img = texture_manager.get_texture(img_name);
    super.img_name = _img_name;
    //super.original_img = img.get();
  }
  
  //updates the block
  public void update(ArrayList<Light> lights) {
    super.update(lights);
  }
}
class CustomBlock extends Block {
  //a sub class of block used for most blocks. extremely customizable
  
  PImage img;
  String type;
  
  
  //constructor if the block drops an item (so an item type, image and name are needed)
  CustomBlock(float _x, float _y, int _x_list_pos, int _y_list_pos, String img_name, String block_name, int block_hardness, String item_type, String item_img_name, String item_name, Light light) {
    super(_x, _y, _x_list_pos, _y_list_pos, img_name, block_name, block_hardness, light);
    img = texture_manager.get_texture(img_name);
    item = new Item(texture_manager.get_texture(item_img_name), item_type, item_name);
    super.item = item;
  }
  
  //constructor if the block drops itself
  CustomBlock(float _x, float _y, int _x_list_pos, int _y_list_pos, String img_name, String block_name, int block_hardness, Light light) {
    super(_x, _y, _x_list_pos, _y_list_pos, img_name, block_name, block_hardness, light);
    img = texture_manager.get_texture(img_name);
    item = new Item(texture_manager.get_texture(img_name), "block", block_name);
    super.item = item;
  }
  
  CustomBlock(int _x_list_pos, int _y_list_pos, String block_name) {
    super(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos, "dirt_block.png", block_name, -1, null);
    if (block_name.equals("alloy smelter")) {
      super.img =  texture_manager.get_texture("alloy_smelter.png");
      super.item = new Item(super.img, "block", block_name);
    } else if (block_name.equals("amethyst ore")) {
      super.img =  texture_manager.get_texture("amethyst_ore.png");
      super.item = new Item(texture_manager.get_texture("amethyst.png"), "item", "amethyst");
      super.mining_level = 8;
    } else if (block_name.equals("basalt block")) {
      super.img =  texture_manager.get_texture("basalt_block.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 8;
    } else if (block_name.equals("campfire")) {
      super.img =  texture_manager.get_texture("campfire.png");
      super.item = new Item(super.img, "block", block_name);        //light!!
      super.light = new Light(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, 500, color(255));
    } else if (block_name.equals("coal ore")) {
      super.img =  texture_manager.get_texture("coal_ore.png");
      super.item = new Item(texture_manager.get_texture("coal.png"), "item", "coal");
      super.mining_level = 2;
    } else if (block_name.equals("copper ore")) {
      super.img =  texture_manager.get_texture("copper_ore.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 3;
    } else if (block_name.equals("crafting bench")) {
      super.img =  texture_manager.get_texture("crafting_bench.png");
      super.item = new Item(super.img, "block", block_name);
    } else if (block_name.equals("enchanted wood")) {
      super.img =  texture_manager.get_texture("enchanted_wood.png");
      super.item = new Item(super.img, "block", block_name);
    } else if (block_name.equals("furnace")) {
      super.img =  texture_manager.get_texture("furnace.png");
      super.item = new Item(super.img, "block", block_name);
    } else if (block_name.equals("granite block")) {
      super.img =  texture_manager.get_texture("granite_block.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 6;
    } else if (block_name.equals("iron ore")) {
      super.img =  texture_manager.get_texture("iron_ore.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 5;
    } else if (block_name.equals("potassium ore")) {
      super.img =  texture_manager.get_texture("potassium_ore.png");
      super.item = new Item(texture_manager.get_texture("potassium.png"), "item", "potassium");
      super.mining_level = 7;
    } else if (block_name.equals("quartz ore")) {
      super.img =  texture_manager.get_texture("quartz_ore.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 7;
    } else if (block_name.equals("ruby ore")) {
      super.img =  texture_manager.get_texture("ruby_ore.png");
      super.item = new Item(texture_manager.get_texture("quartz.png"), "item", "quartz");
      super.mining_level = 8;
    } else if (block_name.equals("sapphire ore")) {
      super.img =  texture_manager.get_texture("sapphire_ore.png");
      super.item = new Item(texture_manager.get_texture("ruby.png"), "item", "ruby");
      super.mining_level = 8;
    } else if (block_name.equals("stone block")) {
      super.img =  texture_manager.get_texture("stone_block.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 2;
    } else if (block_name.equals("stoney block")) {
      super.img =  texture_manager.get_texture("stoney_block.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 2;
    } else if (block_name.equals("stone brick")) {
      super.img =  texture_manager.get_texture("stone_brick.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 100000000;
    } else if (block_name.equals("tin ore")) {
      super.img =  texture_manager.get_texture("tin_ore.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 4;
    } else if (block_name.equals("tool station")) {
      super.img =  texture_manager.get_texture("tool_station.png");
      super.item = new Item(super.img, "block", block_name);
    } else if (block_name.equals("thorium ore")) {
      super.img =  texture_manager.get_texture("thorium_ore.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 7;
    } else if (block_name.equals("topaz ore")) {
      super.img =  texture_manager.get_texture("topaz_ore.png");
      super.item = new Item(texture_manager.get_texture("topaz.png"), "item", "topaz");
      super.mining_level = 8;
    } else if (block_name.equals("torch")) {
      super.img =  texture_manager.get_texture("torch.png");
      super.item = new Item(super.img, "block", block_name);
      super.mining_level = 1;
      super.light = new Light(round((player.x+mouseX-width/2)/20)*20, round((player.y+mouseY-height/2)/20)*20, 200, color(255));
      super.collisionPossible = false;
    } else if (block_name.equals("wood")) {
      super.img =  texture_manager.get_texture("wood.png");
      super.item = new Item(super.img, "block", block_name);
    } else if (block_name.equals("wood block")) {
      super.img =  texture_manager.get_texture("wood_block.png");
      super.item = new Item(super.img, "block", block_name);
    } else {
      println(block_name);
      exit();
    }
  }
  
  //updates the block
  public void update(ArrayList<Light> lights) {
    super.update(lights);
  }
}
class Cyclops extends Enemy {
  String state;
  int counter, max_counter, shoot_cooldown, max_shoot_cooldown, death_animation_counter;
  float original_x;
  PImage death_animation, original_death_animation;
  float player_x, player_y;
  Cyclops(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "cyclops", "cyclops.png", 50, temp_blocks);
    attack = 0;
    health = 80;
    max_health = 80;
    speed = 0;
    attack_cooldown = 50;
    state = "shoot";
    max_counter = 1000;
    counter = max_counter;
    max_shoot_cooldown = 60;
    shoot_cooldown = max_shoot_cooldown;
    original_x = temp_x;
    original_death_animation = texture_manager.get_texture("cyclops_death.png");
    death_animation = original_death_animation.get();
    death_animation_counter = 250;
    player_x = player.x;
    player_y = player.y;
    
    boolean collision = false;
    while (!collision) {
      collision = false;
      for (int i = 0; i < blocks.length; i++) {
        for (int j = 0; j < blocks[i].length; j++) {
          if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectBlockCollision(blocks[i][j])) {
            collision = true;
          }
        }
      }
      if (collision) {
        break;
      }
      location.y++;
    }
  }
  
  public void update(Player player) {
    if (state.equals("shoot")) {
      if (shoot_cooldown == 0) {
        for (int i = 0; i < 3; i++) {
          game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, 1000, "cyclops_bullet.png", 5, 0, true));
        }
        game.enemy_bullets.get(game.enemy_bullets.size()-1).rotation += 15;
        game.enemy_bullets.get(game.enemy_bullets.size()-1).velocity.x = game.enemy_bullets.get(game.enemy_bullets.size()-1).speed*cos(radians(game.enemy_bullets.get(game.enemy_bullets.size()-1).rotation));
        game.enemy_bullets.get(game.enemy_bullets.size()-1).velocity.y = game.enemy_bullets.get(game.enemy_bullets.size()-1).speed*sin(radians(game.enemy_bullets.get(game.enemy_bullets.size()-1).rotation));
        game.enemy_bullets.get(game.enemy_bullets.size()-2).rotation -= 15;
        game.enemy_bullets.get(game.enemy_bullets.size()-2).velocity.x = game.enemy_bullets.get(game.enemy_bullets.size()-2).speed*cos(radians(game.enemy_bullets.get(game.enemy_bullets.size()-2).rotation));
        game.enemy_bullets.get(game.enemy_bullets.size()-2).velocity.y = game.enemy_bullets.get(game.enemy_bullets.size()-2).speed*sin(radians(game.enemy_bullets.get(game.enemy_bullets.size()-2).rotation));
        shoot_cooldown = max_shoot_cooldown;
      } else {
        shoot_cooldown--;
      }
    } else if (state.equals("attack")) {
      if (!checkAttackPossible(player)) {
        if (player.x < location.x) {
          location.x = constrain(location.x-3, original_x-350, original_x+350);
        } else {
          location.x = constrain(location.x+3, original_x-350, original_x+350);
        }
      }
    } else if (state.equals("death animation")) {
      if (death_animation_counter > 0) {
        death_animation_counter--;
      } else {
        state = "dead";
        is_dead = true;
        player.x = player_x;
        player.y = player_y;
        for (int i = 0; i < blocks.length; i++) {
          for (int j = 0; j < blocks[i].length; j++) {
              blocks[i][j] = null;
          }
        }
        //player.x = 300;
        game.load_world("world", 0, 0);
      }
    }
    
    if (counter == 0) {
      if (state.equals("shoot")) {
        state = "attack";
        counter = max_counter/5;
      } else {
        state = "shoot";
        counter = max_counter;
      }
    } else {
      counter--;
    }
    if (health <= 0) {
      //is_dead = true;
      state = "death animation";
      for (int i = 0; i < game.enemies.size(); i++) {
        if (game.enemies.get(i).type.equals("cyclops tower")) {
          game.enemies.get(i).is_dead = true;
        }
      }
    }
    display();
  }
  
  public void display() {
    if (!state.equals("death animation")) {
      image(img, location.x, location.y);
    } else {
      pushMatrix();
      translate(location.x, location.y);
      death_animation = original_death_animation.get();
      death_animation.resize((250-death_animation_counter+1)*4, (250-death_animation_counter+1)*4);
      rotate(radians(death_animation_counter*3));
      image(death_animation, 0, 0);
      popMatrix();
    }
  }
  
  public boolean checkAttackPossible(Player _player) {
    if (attack_cooldown == 0) {
      attack_cooldown = max_attack_cooldown;
      if (location.x > _player.x - _player.img_right.width/2 - img.width/2 && location.x < _player.x + _player.img_right.width/2 + img.width/2 &&
          location.y > _player.y - _player.img_right.height/2 - img.height/2 && location.y < _player.y + _player.img_right.height/2 + img.height/2) {
            _player.damage(attack);
            return true;
      }
    } else {
      attack_cooldown--;
    }
    return false;
  }
}
class CyclopsTower extends Enemy {
  int shoot_cooldown, max_shoot_cooldown;
  CyclopsTower(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "cyclops tower", "cyclops_tower.png", 100, temp_blocks);
    attack = 3;
    health = 1;
    max_health = 1;
    speed = 0;
    attack_cooldown = 100;
    max_shoot_cooldown = 100;
    shoot_cooldown = max_shoot_cooldown;
  }
  
  public void update(Player player) {
    if (shoot_cooldown == 0) {
      for (int i = 0; i < 3; i++) {
        game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, 2000, "cyclops_tower_bullet.png", 3, 0.01f, false));
      }
      shoot_cooldown = max_shoot_cooldown;
    } else {
      shoot_cooldown--;
    }
    display();
  }
}
class DirtBlock extends Block {
  //a sub class of block. used instead of CustomBlock as it has an extra script.
  PImage img1, img2;
  String type;
  
  DirtBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "dirt_block.png", "dirt", 1, null);
    img1 = texture_manager.get_texture("dirt_block.png");
    img2 = texture_manager.get_texture("dirt_block_top.png");
    item = new Item(texture_manager.get_texture("dirt_block.png"), "block", "dirt");
    super.item = item;
  }
  
  //grow grass over itself if there is not blocks above it
  public void update(ArrayList<Light> lights) {
    if (blocks[x_list_pos][y_list_pos-1] == null) {
      super.img = img1.get();
    } else {
      super.img = img2.get();
    }
    super.update(lights);
  }
}
class DriedLavaBlock extends Block {
  //a sub class of block. used instead of CustomBlock as it has an extra script.
  PImage img;
  String type;
  int y_off;
  
  DriedLavaBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "dried_lava_block.png", "dried lava block", 1, null);
    img = texture_manager.get_texture("dried_lava_block.png");
    item = null;
    super.item = item;
    super.img = img.get();
    y_off = 0;
  }
  
  public void kill() {
    blocks[x_list_pos][y_list_pos] = new LavaBlock(x, y, x_list_pos, y_list_pos, 0.5f);
  }
}
class Enemy {
  //global variables
  PVector location, velocity, knockback;
  float speed;
  PImage img;
  String type;
  Block[][] blocks;
  
  float g_const;
  boolean knockback_on, touching_ground;
  boolean facing_right;
  boolean movingRight, movingLeft;
  boolean is_dead;
  int attack, health, max_health, attack_cooldown, max_attack_cooldown;
  float jump;
  
  int dis = 20;
  int enemy_offset = 15;
  
  Enemy(float _x, float _y, String _type, String img_name, int _attack_cooldown, Block[][] _blocks) {
    //global variables init
    location = new PVector(_x, _y);
    velocity = new PVector(0, 0);
    knockback = new PVector(0, 0);
    knockback_on = true;
    img = texture_manager.get_texture(img_name);
    facing_right = true;
    blocks = _blocks;
    type = _type;
    
    g_const = 1;
    touching_ground = false;
    
    //attack_cooldown = 0;
    attack_cooldown = _attack_cooldown;
    max_attack_cooldown = _attack_cooldown;
    is_dead = false;
    jump = 15;
  }
  
  public void update(Player _player) {
    health_check();
    checkAttack(_player);
    move();
    if (!knockback_on) {
      applyGravity();
    }
    display();
  }
  
  public void move() {
    if (player.x < location.x) {
      movingLeft = true;
      movingRight = false;
    } else {
      movingLeft = false;
      movingRight = true;
    }
    
    if (knockback_on) {
      boolean noCollision = true;
      for (int i = max(0, round(location.x/20)-dis+enemy_offset); i < min(round(location.x/20)+dis+enemy_offset, blocks.length); i++) {
        for (int j = max(0, round(location.y/20)-dis+enemy_offset); j < min(round(location.y/20)+dis+enemy_offset, blocks[i].length); j++) {
          if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectBlockCollision(blocks[i][j])) {
            noCollision = false;
          }
        }
      }
      if (!noCollision) {
        knockback_on = false;
        knockback = new PVector(0, 0);
        boolean collision = true;
        while (collision) {
          collision = false;
          for (int i = max(0, round(location.x/20)-dis+enemy_offset); i < min(round(location.x/20)+dis+enemy_offset, blocks.length); i++) {
            for (int j = max(0, round(location.y/20)-dis+enemy_offset); j < min(round(location.y/20)+dis+enemy_offset, blocks[i].length); j++) {
              if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectBlockCollision(blocks[i][j])) {
                collision = true;
              }
            }
          }
          location.y--;
        }
      } else {
        knockback.y += g_const;
        location.add(knockback);
      }
    } else if (movingLeft) {
      location.x -= speed;
      boolean noCollision = true;
      for (int i = max(0, round(location.x/20)-dis+enemy_offset); i < min(round(location.x/20)+dis+enemy_offset, blocks.length); i++) {
        for (int j = max(0, round(location.y/20)-dis+enemy_offset); j < min(round(location.y/20)+dis+enemy_offset, blocks[i].length); j++) {
          if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectCollision(blocks[i][j])) {
            noCollision = false;
          }
        }
      }
      if (!noCollision) {
        location.x += speed;
        if (touching_ground) {
          velocity.y = -7;
        }
      }
    } else if (movingRight) {
      location.x += speed;
      boolean noCollision = true;
      for (int i = max(0, round(location.x/20)-dis+enemy_offset); i < min(round(location.x/20)+dis+enemy_offset, blocks.length); i++) {
        for (int j = max(0, round(location.y/20)-dis+enemy_offset); j < min(round(location.y/20)+dis+enemy_offset, blocks[i].length); j++) {
          if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectCollision(blocks[i][j])) {
            noCollision = false;
          }
        }
      }
      if (!noCollision) {
        location.x -= speed;
        if (touching_ground) {
          velocity.y = -7;
        }
      }
    }
    if ((player.y + img.height*3 < location.y) && touching_ground) {
      velocity.y = -jump;
    }
  }
  
  public void display() {
    image(img, location.x, location.y);
  }
  
  public void applyGravity() {
    velocity.y += g_const;
    location.y += velocity.y;
    boolean noCollision = true;
    touching_ground = false;
    for (int i = max(0, round(location.x/20)-dis+enemy_offset); i < min(round(location.x/20)+dis+enemy_offset, blocks.length); i++) {
      for (int j = max(0, round(location.y/20)-dis+enemy_offset); j < min(round(location.y/20)+dis+enemy_offset, blocks[i].length); j++) {
        if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectBlockCollision(blocks[i][j])) {
          noCollision = false;
        }
      }
    }
    if (!noCollision) {
      location.y -= velocity.y;
      velocity.y = 0;
      touching_ground = true;
    }
  }
  
  public boolean detectBlockCollision (Block block) {
    if  ((location.x + img.width/2 >= block.x - block.img.width/2) &&
         (location.x - img.width/2 <= block.x + block.img.width/2) &&
         (location.y + img.height/2 >= block.y - block.img.height/2) &&
         (location.y - img.height/2 <= block.y + block.img.height/2))
    {
          return true;
    }
    return false;
  }
  
  public boolean detectCollision (Block block) {
    if  ((location.x + img.width/2 >= block.x - block.img.width/2) &&
         (location.x - img.width/2 <= block.x + block.img.width/2) &&
         (location.y + img.height/2 >= block.y - block.img.height/2) &&
         (location.y - img.height/2 <= block.y + block.img.height/2))
    {
          return true;
    }
    return false;
  }
  
  public void damage(float player_attack) {
    health -= player_attack;
  }
  
  public void health_check() {
    if (health <= 0) {
      is_dead = true;
    } else if (location.y > 10000) {
      is_dead = true;
    }
  }
  
  public void checkAttack(Player _player) {
    if (attack_cooldown == 0) {
      attack_cooldown = max_attack_cooldown;
      if (location.x > _player.x - _player.img_right.width/2 - img.width/2 && location.x < _player.x + _player.img_right.width/2 + img.width/2 &&
          location.y > _player.y - _player.img_right.height/2 - img.height/2 && location.y < _player.y + _player.img_right.height/2 + img.height/2) {
            _player.damage(attack);
      }
    } else {
      attack_cooldown--;
    }
  }
}
class EnemyBullet {
  PVector location, velocity;
  float fuse, speed, rotation, damage, tracking;
  boolean stopped_by_walls;
  PImage img;
  
  EnemyBullet(float x, float y, float _speed, float direction, float range, String img_name, float _damage, float _tracking, boolean _stopped_by_walls) {
    location = new PVector(x, y);
    velocity = new PVector(_speed*cos(radians(direction)), _speed*sin(radians(direction)));
    fuse = range/_speed;
    speed = _speed;
    rotation = direction;
    img = texture_manager.get_texture(img_name);
    damage = _damage;
    tracking = _tracking;
    stopped_by_walls = _stopped_by_walls;
  }
  
  EnemyBullet(float x, float y, float _speed, float range, String img_name, float _damage, float _tracking, boolean _stopped_by_walls) {
    float direction = degrees(atan2(player.y - y, player.x - x));
    location = new PVector(x, y);
    velocity = new PVector(_speed*cos(radians(direction)), _speed*sin(radians(direction)));
    fuse = range/_speed;
    speed = _speed;
    rotation = direction;
    img = texture_manager.get_texture(img_name);
    damage = _damage;
    tracking = _tracking;
    stopped_by_walls = _stopped_by_walls;
  }
  
  public void update() {
    track();
    move();
    checkPlayerCollision();
    display();
  }
  
  public void track() {
    if (tracking > 0) {
      PVector toTarget = new PVector(player.x - location.x, player.y - location.y);
      toTarget.normalize();
      toTarget.mult(speed);
      velocity.set(lerp(velocity.x, toTarget.x, tracking), lerp(velocity.y, toTarget.y, tracking));
    }
  }
  
  public void move() {
    location.add(velocity);
    fuse--;
    if (stopped_by_walls) {
      int dis = 20;
      int offset = 15;
      for (int i = max(0, round(location.x/20)-dis+offset); i < min(round(location.x/20)+dis+offset, blocks.length); i++) {
        for (int j = max(0, round(location.y/20)-dis+offset); j < min(round(location.y/20)+dis+offset, blocks[i].length); j++) {
          if (blocks[i][j] != null && detectCollision(img, location.x, location.y, blocks[i][j].img, blocks[i][j].x, blocks[i][j].y)) {
            fuse = 0;
            return;
          }
        }
      }
    }
  }
  
  public void display() {
    pushMatrix();
    translate(location.x, location.y);
    rotate(radians(rotation));
    image(img, 0, 0);
    popMatrix();
  }
  
  public void checkPlayerCollision() {
    if (detectCollision(img, location.x, location.y, player.img_left, player.x, player.y)) {
      player.damage(damage);
      fuse = 0;
    }
  }
  
  public boolean detectCollision (PImage img1, float x1, float y1, PImage img2, float x2, float y2) {
    if  ((x1 + img1.width/2 >= x2 - img2.width/2) &&
         (x1 - img1.width/2 <= x2 + img2.width/2) &&
         (y1 + img1.height/2 >= y2 - img2.height/2) &&
         (y1 - img1.height/2 <= y2 + img2.height/2))
    {
          return true;
    }
    return false;
  }
  
  public boolean should_be_destroyed() {
    if (fuse <= 0) {
      return true;
    }
    return false;
  }
}
class ForestWizard extends Enemy {
  int current_attack_cooldown;
  ForestWizard(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "forest wizard", "forest_wizard.png", 4, temp_blocks);
    attack = 0;
    health = 30;
    max_health = 2;
    speed = 2;
    attack_cooldown = 120;
    current_attack_cooldown = attack_cooldown;
  }
  
  public void update(Player player) {
    if (current_attack_cooldown == 0) {
      game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 10, 900, "forest_wizard_bullet.png", 4, 0, true));
      current_attack_cooldown = attack_cooldown;
    } else {
      current_attack_cooldown--;
    }
    // EnemyBullet(float x, float y, float _speed, float range, String img_name, float _damage, float _tracking, boolean _stopped_by_walls) {
    super.update(player);
  }
}
class Game {
  //the class for loading an updating the world
  
  //global variables
  int load_counter;
  float block_yoff, block_x, roughness, size;
  float block_update_counter, max_block_update_counter;
  String state;
  PImage[] backgrounds, biome_backgrounds;
  PImage main_menu_screen;
  PImage loading_bar, original_loading_bar;
  ArrayList<Particle> particles;
  ArrayList<Enemy> enemies;
  ArrayList<EnemyBullet> enemy_bullets;
  FloatList recent_fps;
  boolean underground_init, desert_init, wasteland_init;
  int mountain_caves_amount;
  float[] mountain_caves_height;
  float spawn_speed;
  int player_offset;
  int forest_enemies, cave_enemies, desert_enemies, wasteland_enemies;
  
  Game() {
    //prints instructions
    println("Welcome to Epic of Xathoebar! This is a very rough draft of the Major Project Assignment,");
    println("this version mainly dealing with world generation.");
    println("\nControls:");
    println("WAD to move\nE to access inventory\nLeft-Click to break blocks\nRight-Click to place blocks.");
    println("\nThe game might take a while to load, so please enjoy the beautiful loading bar in the meantime!");
    println("\nRemember to use recipies.txt and tools.txt to access the recipies and mining levels for the items in the game!");
    
    //setup
    noStroke();
    textFont(createFont("Arial", 15, true), 15);
    textAlign(RIGHT);
    rectMode(CENTER);
    imageMode(CENTER);
    
    //global variables init
    backgrounds = new PImage[4];
    for (int i = 0; i < backgrounds.length; i++) {
      backgrounds[i] = texture_manager.get_texture("background_"+(i+1)+".png");
    }
    biome_backgrounds = new PImage[4];
    String[] biome_background_names = {"forest", "cave", "desert", "wasteland"};
    for (int i = 0; i < biome_backgrounds.length; i++) {
      biome_backgrounds[i] = texture_manager.get_texture(biome_background_names[i] + "_background.png");
    }
    main_menu_screen = texture_manager.get_texture("main_menu.png");
    roughness = 10;
    size = 2;
    original_loading_bar = texture_manager.get_texture("loading_bar.png");
    loading_bar = original_loading_bar.get();
    block_x = -land_width/2;
    block_yoff = 0;
    //state = "load_world_file";
    state = "menu";
    load_counter = 0;
    max_block_update_counter = 45;
    block_update_counter = max_block_update_counter;
    particles = new ArrayList<Particle>();
    enemies = new ArrayList<Enemy>();
    enemy_bullets = new ArrayList<EnemyBullet>();
    recent_fps = new FloatList();
    underground_init = false;
    desert_init = false;
    wasteland_init = false;
    mountain_caves_amount = round(random(3, 5));
    mountain_caves_height = new float[mountain_caves_amount];
    for (int i = 0; i < mountain_caves_amount; i++) {
      mountain_caves_height[i] = random(1, 3);
    }
    spawn_speed = 0.2f;
    player_offset = 20;
    forest_enemies = 0;
    cave_enemies = 0;
    desert_enemies = 0;
    wasteland_enemies = 0;
  }

  public void loadGame(int loadingState) {
    //generate the world terrain
    if (loadingState == 1) {    
      state = "load_2";
    } else if (loadingState == 2) {
      background(255);
      if (load_counter < land_width) {
        int i = load_counter;
        if (load_counter < biome_width) { //load_counter < biome_width
          biome_type = "forest";
        } else if (load_counter < biome_width*2) {
          biome_type = "underground";
        } else if (load_counter < biome_width*3) {
          biome_type = "desert";
        } else {
          biome_type = "wasteland";
        }
        if (biome_type.equals("forest")) {
          block_yoff += 0.05f;
          //uses perlin noise to make the shape
          //float n = round(noise(block_yoff) * height / 20) * 20 + 2000; //2000 - 2720
          float n = round(map(noise(block_yoff), 0, 1, 2000, 2720)/20)*20;
          //float n1 = ((round(noise(block_yoff*2) * height / 20)+10) * 20) + 2000;
          float n1 = round(map(noise(block_yoff*2), 0, 1, 2200, 2920)/20)*20;
          //float n2 = ((round(noise(block_yoff*1.5) * height / 20)+30) * 20) + 2000;
          float n2 = round(map(noise(block_yoff*1.5f), 0, 1, 2600, 3320)/20)*20;
          //float n3 = ((round(noise(block_yoff*2) * height / 20)+50) * 20) + 2000;
          float n3 = round(map(noise(block_yoff*2), 0, 1, 3000, 3720)/20)*20;
          //float n4 = ((round(noise(block_yoff*3) * height / 20)+70) * 20) + 2000;
          float n4 = round(map(noise(block_yoff*3), 0, 1, 3400, 4120)/20)*20;
          for (float j = n; j < max(n+20, n1); j += 20) {
            blocks[round(i)][round(j/20)] = new DirtBlock(block_x, j, round(i), round(j/20));
            background_walls[round(i)][round(j/20)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "dirt_bw.png", "dirt bw");
          }
          for (float j = max(n+20, n1); j < max(max(n+20, n1)+20, n2); j += 20) {
            blocks[round(i)][round(j/20)] = new CustomBlock(round(i), round(j/20), "stoney block");
            background_walls[round(i)][round(j/20)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "stoney_bw.png", "stoney bw");
          }
          for (float j = max(max(n+20, n1)+20, n2); j < max(max(max(n+20, n1)+20, n2)+20, n3); j += 20) {
            blocks[round(i)][round(j/20)] = new CustomBlock(round(i), round(j/20), "stone block");
            background_walls[round(i)][round(j/20)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "stone_bw.png", "stone bw");
          }
          for (float j = max(max(max(n+20, n1)+20, n2)+20, n3); j < max(max(max(max(n+20, n1)+20, n2)+20, n3)+20, n4); j += 20) {
            blocks[round(i)][round(j/20)] = new CustomBlock(round(i), round(j/20), "granite block");
            background_walls[round(i)][round(j/20)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "granite_bw.png", "granite bw");
          }
          for (float j = max(max(max(max(n+20, n1)+20, n2)+20, n3)+20, n4); j < max(max(max(max(n+20, n1)+20, n2)+20, n3)+20, n4)+600; j += 20) {
            blocks[round(i)][round(j/20)] = new CustomBlock(round(i), round(j/20), "basalt block");
            background_walls[round(i)][round(j/20)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "basalt_bw.png", "basalt bw");
          }
          saved_alt = n;
        } else if (biome_type.equals("underground")) {
          block_yoff += 0.007f;
          //float n = round((noise(block_yoff)-0.5)*8 * height / 20) * 20 + 2000;
          float n = round(map(noise(block_yoff), 0, 1, -880, 4880)/20)*20;
          //float n1 = ((round(noise(block_yoff*2) * height / 20)+50) * 20) + 2000;
          //float n2 = ((round(noise(block_yoff*3) * height / 20)+70) * 20) + 2000;
          float n1 = round(map(noise(block_yoff*2), 0, 1, 3000, 3720)/20)*20;
          float n2 = round(map(noise(block_yoff*3), 0, 1, 3400, 4120)/20)*20;
          while (!underground_init) {
            block_yoff += 0.001f;
            n = round((noise(block_yoff)-0.5f)*8 * height / 20) * 20 + 2000;
            if (n == saved_alt) {
              underground_init = true;
            }
          }
          float[] ns = new float[mountain_caves_amount];
          for (int j = 0; j < mountain_caves_amount; j++) {
            ns[j] = (round((noise(block_yoff*mountain_caves_height[j])-0.5f)*8 * height / 20)+((j+1)/(ns.length+1))*100) * 20 + 2000;
          }
          
          //stone layer
          for (float j = n; j < max(n+20, n1); j += 20) {
            try {
              blocks[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new CustomBlock(constrain(round(i), 0, blocks.length), constrain(round(j/20), 0, blocks[0].length), "stone block");
              //blocks[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new SandBlock(block_x, j, constrain(round(i), 0, blocks.length), constrain(round(j/20), 0, blocks[0].length));
              background_walls[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "stone_bw.png", "stone bw");  
            } catch (ArrayIndexOutOfBoundsException e) {
              
            }
          }
          
          //granite layer
          for (float j = max(n+20, n1); j < max(max(n+20, n1)+20, n2); j += 20) {
            try {
              blocks[round(i)][round(j/20)] = new CustomBlock(round(i), round(j/20), "granite block");
              //blocks[round(i)][round(j/20)] = new SandBlock(block_x, j, round(i), round(j/20));
              background_walls[round(i)][round(j/20)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "granite_bw.png", "granite bw");
            } catch (ArrayIndexOutOfBoundsException e) {
              
            }
          }
          
          //basalt layer
          for (float j = max(max(n+20, n1)+20, n2); j < max(max(n+20, n1)+20, n2)+600; j += 20) {
            try {
              blocks[round(i)][round(j/20)] = new CustomBlock(round(i), round(j/20), "basalt block");
              //blocks[round(i)][round(j/20)] = new SandBlock(block_x, j, round(i), round(j/20));
              background_walls[round(i)][round(j/20)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "basalt_bw.png", "basalt bw");
            } catch (ArrayIndexOutOfBoundsException e) {
              
            }
          }
          
          //caves
          for (float ns_entry : ns) {
            for (float j = ns_entry; j < ns_entry+200; j+= 20) {
              try {
                blocks[round(i)][round(j/20)] = null;
                if (j < n) {
                  background_walls[round(i)][round(j/20)] = null;
                }
              } catch (ArrayIndexOutOfBoundsException e) {
              
              }
            }
          }
          saved_alt = n;
        }
        else if (biome_type.equals("desert")) {
          block_yoff += 0.003f;
          float n = round(map(noise(block_yoff), 0, 1, -880, 4880)/20)*20;
          //float n1 = round(map(noise(block_yoff), 0, 1, -680, 4880)/20)*20;
          while (!desert_init) {
            block_yoff += 0.001f;
            n = round((noise(block_yoff)-0.5f)*8 * height / 20) * 20 + 2000;
            if (n == saved_alt) {
              desert_init = true;
            }
          }
          
          //sand layer
          for (float j = n; j < n+2000; j += 20) {
            try {
              blocks[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new SandBlock(block_x, j, constrain(round(i), 0, blocks.length), constrain(round(j/20), 0, blocks[0].length));
              //blocks[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new SandBlock(block_x, j, constrain(round(i), 0, blocks.length), constrain(round(j/20), 0, blocks[0].length));
              background_walls[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "sand_bw.png", "sand bw");  
            } catch (ArrayIndexOutOfBoundsException e) {
              
            }
          }
          saved_alt = n;
        }
        else if (biome_type.equals("wasteland")) {
          block_yoff += 0.01f;
          float n = round(map(noise(block_yoff), 0, 1, -880, 4880)/20)*20;
          //float n1 = round(map(noise(block_yoff), 0, 1, -680, 4880)/20)*20;
          while (!wasteland_init) {
            block_yoff += 0.001f;
            n = round((noise(block_yoff)-0.5f)*8 * height / 20) * 20 + 2000;
            if (n == saved_alt) {
              wasteland_init = true;
            }
          }
          
          //dried lava layer
          for (float j = n; j < n+2000; j += 20) {
            try {
              blocks[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new DriedLavaBlock(block_x, j, constrain(round(i), 0, blocks.length), constrain(round(j/20), 0, blocks[0].length));
              //blocks[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new SandBlock(block_x, j, constrain(round(i), 0, blocks.length), constrain(round(j/20), 0, blocks[0].length));
              background_walls[constrain(round(i), 0, blocks.length)][constrain(round(j/20), 0, blocks[0].length)] = new CustomBackgroundWall(block_x, j, round(i), round(j/20), "dried_lava_bw.png", "dried lava bw");  
            } catch (ArrayIndexOutOfBoundsException e) {
              
            }
          }
        }
        block_x += 20;
        load_counter++;
        imageMode(CENTER);

        //a fancy loading bar to make things more interesting
        float transparency_counter = 0;
        if (i*100/land_width < 20) {
          image(backgrounds[0], width/2, height/2);
          transparency_counter = 0;
        } else if (i*100/land_width >= 20 && i*100/land_width < 30) {
          transparency_counter = (i*100/land_width-20);
          image(backgrounds[1], width/2, height/2);
          tint(255, 255-25*transparency_counter);
          //tint(255, 120);
          image(backgrounds[0], width/2, height/2);
        }

        if (i*100/land_width < 45 && i*100/land_width >= 30) {
          image(backgrounds[1], width/2, height/2);
          transparency_counter = 0;
        } else if (i*100/land_width >= 45 && i*100/land_width < 55) {
          transparency_counter = (i*100/land_width-45);
          image(backgrounds[2], width/2, height/2);
          tint(255, 255-25*transparency_counter);
          //tint(255, 120);
          image(backgrounds[1], width/2, height/2);
        }
        if (i*100/land_width < 70 && i*100/land_width >= 55) {
          image(backgrounds[2], width/2, height/2);
          transparency_counter = 0;
        } else if (i*100/land_width >= 70 && i*100/land_width < 80) {
          transparency_counter = (i*100/land_width-70);
          image(backgrounds[3], width/2, height/2);
          tint(255, 255-25*transparency_counter);
          //tint(255, 120);
          image(backgrounds[2], width/2, height/2);
        }

        if (i*100/land_width >= 80) {
          image(backgrounds[3], width/2, height/2);
          transparency_counter = 0;
        }

        noTint();
        image(loading_bar, width/2, height/2);
        rectMode(CORNER);
        fill(0);
        rect(width/2+loading_bar.width/2, height/2-loading_bar.height/2, -loading_bar.width+round(i*loading_bar.width/land_width), loading_bar.height);
        fill(255, 0, 0);
        textFont(createFont("Arial", 50, true), 50);
        textAlign(CENTER);
        text(i*100/land_width+"%", width/2, height/2+17);
        
        if (load_counter == land_width) {
          state = "load_3";
        }
      }
    } else {
      //ore veins
      
      //copper ore
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height; j++) {
          if (blocks[i][j] != null && blocks[i][j].type.equals("stoney block") && random(0, 1) <= 0.005f) {
            blocks[i][j] = new CustomBlock(i, j, "copper ore");
            float x_offset = 0;
            float y_offset = 0;
            for (int k = 0; k < random(4, 12); k++) {
              //x_offset += round(random(0, 2)-0.5)*2-1;
              //y_offset += round(random(0, 2)-0.5)*2-1;
              x_offset += round(random(-1, 1));
              y_offset += round(random(-1, 1));
              if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stoney block")) {
                blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "copper ore");
              }
            }
          }
        }
        block_x += 20;
      }
      //tin ore
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height; j++) {
          if (blocks[i][j] != null && blocks[i][j].type.equals("stoney block") && random(0, 1) <= 0.005f) {
            blocks[i][j] = new CustomBlock(i, j, "tin ore");
            float x_offset = 0;
            float y_offset = 0;
            for (int k = 0; k < random(4, 12); k++) {
              //x_offset += round(random(0, 2)-0.5)*2-1;
              //y_offset += round(random(0, 2)-0.5)*2-1;
              x_offset += round(random(-1, 1));
              y_offset += round(random(-1, 1));
              if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stoney block")) {
                blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "tin ore");
              }
            }
          }
        }
        block_x += 20;
      }
      //iron ore
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height; j++) {
          if (blocks[i][j] != null && blocks[i][j].type.equals("stone block") && random(0, 1) <= 0.003f) {
            blocks[i][j] = new CustomBlock(i, j, "iron ore");
            float x_offset = 0;
            float y_offset = 0;
            for (int k = 0; k < random(4, 12); k++) {
              //x_offset += round(random(0, 2)-0.5)*2-1;
              //y_offset += round(random(0, 2)-0.5)*2-1;
              x_offset += round(random(-1, 1));
              y_offset += round(random(-1, 1));
              if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stone block")) {
                blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "iron ore");
              }
            }
          }
        }
        block_x += 20;
      }
      //coal
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height; j++) {
          if (blocks[i][j] != null && blocks[i][j].type.equals("stone block") && random(0, 1) <= 0.003f) {
            blocks[i][j] = new CustomBlock(i, j, "coal ore");
            float x_offset = 0;
            float y_offset = 0;
            for (int k = 0; k < random(4, 12); k++) {
              //x_offset += round(random(0, 2)-0.5)*2-1;
              //y_offset += round(random(0, 2)-0.5)*2-1;
              x_offset += round(random(-1, 1));
              y_offset += round(random(-1, 1));
              if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("stone block")) {
                blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "coal ore");
              }
            }
          }
        }
        block_x += 20;
      }
      //pottasium, quartz, thorium ore
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height; j++) {
          if (blocks[i][j] != null && blocks[i][j].type.equals("granite block") && random(0, 1) <= 0.003f) {
            int block_name = PApplet.parseInt(random(0, 3)); //0 = pottasium, 1 = quartz, 2 = thorium
            if (block_name == 0) {
              blocks[i][j] = new CustomBlock(i, j, "potassium ore");
            } else if (block_name == 1) {
              blocks[i][j] = new CustomBlock(i, j, "quartz ore");
            } else {
              blocks[i][j] = new CustomBlock(i, j, "thorium ore");
            }
            float x_offset = 0;
            float y_offset = 0;
            for (int k = 0; k < random(4, 12); k++) {
              //x_offset += round(random(0, 2)-0.5)*2-1;
              //y_offset += round(random(0, 2)-0.5)*2-1;
              x_offset += round(random(-1, 1));
              y_offset += round(random(-1, 1));
              if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("granite block")) {
                if (block_name == 0) {
                  blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "potassium ore");
                } else if (block_name == 1) {
                  blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "quartz ore");
                } else {
                  blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "thorium ore");
                }
              }
            }
          }
        }
        block_x += 20;
      }
      //gems
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height; j++) {
          if (blocks[i][j] != null && blocks[i][j].type.equals("quartz ore") && random(0, 1) <= 0.1f) {
            int block_name = PApplet.parseInt(random(0, 4)); //0 = ruby, 1 = sapphire, 2 = topaz, 3 = amethyst
            if (block_name == 0) {
              blocks[i][j] = new CustomBlock(i, j, "ruby ore");
            } else if (block_name == 1) {
              blocks[i][j] = new CustomBlock(i, j, "sapphire ore");
            } else if (block_name == 2) {
              blocks[i][j] = new CustomBlock(i, j, "topaz ore");
            } else {
              blocks[i][j] = new CustomBlock(i, j, "amethyst ore");
            }
          }
        }
        block_x += 20;
      }
      //boulder
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height; j++) {
          if (blocks[i][j] != null && blocks[i][j].type.equals("dirt") && random(0, 1) <= 0.005f) {
            blocks[i][j] = new CustomBlock(i, j, "stone block");
            float x_offset = 0;
            float y_offset = 0;
            for (int k = 0; k < random(8, 20); k++) {
              //x_offset += round(random(0, 2)-0.5)*2-1;
              //y_offset += round(random(0, 2)-0.5)*2-1;
              x_offset = round(random(-2, 1));
              y_offset = round(random(-2, 1));
              if (i+round(x_offset) < land_width && i+round(x_offset) > 0 && j+round(y_offset) < land_height && j+round(y_offset) > 0 && blocks[i+round(x_offset)][j+round(y_offset)] != null && blocks[i+round(x_offset)][j+round(y_offset)].type.equals("dirt")) {
                blocks[i+round(x_offset)][j+round(y_offset)] = new CustomBlock(i+round(x_offset), j+round(y_offset), "stone block");
              }
            }
          }
        }
        block_x += 20;
      }
      //trees
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 12; j < land_height-12; j++) {
          if (blocks[i][j] == null && blocks[i][j+1] != null && blocks[i][j+1].type.equals("dirt") && random(0, 1) <= 0.1f) {
            int leaf_counter = 0;
            int tree_height = round(random(4, 12));
            for (int k = 0; k < tree_height; k++) {
              if (i+2 < land_width && i-2 > 0 && j-k > 0) {
                blocks[i][j-k] = new CustomBlock(i, j-k, "wood block");
                if (k > tree_height/2) {
                  blocks[i+1][j-k] = new LeafBlock(block_x+20, (j-k)*20, i+1, j-k, "right");
                  blocks[i-1][j-k] = new LeafBlock(block_x-20, (j-k)*20, i-1, j-k, "left");
                  blocks[i+2][j-k] = new LeafBlock(block_x+40, (j-k)*20, i+2, j-k);
                  blocks[i-2][j-k] = new LeafBlock(block_x-40, (j-k)*20, i-2, j-k);
                }
                leaf_counter++;
              }
            }
            if (i+1 < land_width && i-1 > 0 && j-leaf_counter-1 > 0) {
              blocks[i][j-leaf_counter] = new LeafBlock(block_x, (j-leaf_counter)*20, i, j-leaf_counter, "top");
              blocks[i+1][j-leaf_counter] = new LeafBlock(block_x+20, (j-leaf_counter)*20, i+1, j-leaf_counter);
              blocks[i-1][j-leaf_counter] = new LeafBlock(block_x-20, (j-leaf_counter)*20, i-1, j-leaf_counter);
              blocks[i][j-leaf_counter-1] = new LeafBlock(block_x, (j-leaf_counter)*20-20, i, j-leaf_counter-1);
            }
          }
        }
        block_x += 20;
      }
      //cactus
      block_x = -land_width/2;
      for (int i = 0; i < land_width; i++) {
        for (int j = 0; j < land_height-2; j++) {
          if (blocks[i][j] == null && blocks[i][j+1] != null && blocks[i][j+1].type.equals("sand") && random(0, 1) <= 0.1f) {
            String orientation = "up";
            int branch_height = 10;
            int block_list_x = 0;
            int block_list_y = 0;
            //branch
            while (branch_height > 0) {
              for (int k = 0; k < branch_height; k++) {
                if (orientation.equals("up")) {
                  block_list_y--;
                }
                else if (orientation.equals("down")) {
                  block_list_y++;
                }
                else if (orientation.equals("right")) {
                  block_list_x++;
                }
                else if (orientation.equals("left")) {
                  block_list_x--;
                }
                
                String rotation = "h";
                if (orientation.equals("up") || orientation.equals("down")) {
                  rotation = "v";
                }
                if (i+block_list_x >= 0 && i+block_list_x < blocks.length && j+block_list_y >= 0 && j+block_list_y < blocks[0].length) {
                  blocks[i+block_list_x][j+block_list_y] = new CactusBlock(block_x+block_list_x*20, (j+block_list_y)*20, i+block_list_x, j+block_list_y, rotation);
                }
              }
              
              //if (orientation.equals("up")) {
              //  orientation = "right";
              //}
              //else if (orientation.equals("down")) {
              //  orientation = "left";
              //}
              //else if (orientation.equals("right")) {
              //  orientation = "down";
              //}
              //else if (orientation.equals("left")) {
              //  orientation = "up";
              //}
              String[] orientation_list = {"up", "down", "right", "left"};
              orientation = orientation_list[round(random(0, orientation_list.length-1))];
              branch_height -= round(random(0, 3));
            }
            
          }
        }
        block_x += 20;
      }
      
      //lava pits
      block_x = -land_width/2;
      for (int i = 0; i < land_width-10; i++) {
        for (int j = 0; j < land_height-30; j++) {
          if (blocks[i][j] == null && blocks[i][j+1] != null && blocks[i][j+1].type.equals("dried lava block") && random(0, 1) <= 0.05f) {
            int pit_depth = round(random(5, 30));
            int pit_width = round(random(4, 10));
            float width_decrease = 0;
            for (int l = -j; l < pit_depth; l++) {
              for (int k = round(width_decrease); k < pit_width-width_decrease; k++) {
                blocks[i+k][j+l] = null;
              }
              //width_decrease = 1;
              if (l > 0) {
                width_decrease += 0.1f;
              }
              //width_decrease++;
            }
            for (int k = 0; k < pit_width; k++) {
              blocks[i+k][j] = new LavaBlock(block_x+k*20, j*20, i+k, j);
            }
          }
        }
        block_x += 20;
      }
      
      ArrayList<Light> lights = new ArrayList<Light>();
      for (int i = max(0, round(player.x/20)-40); i < min(round(player.x/20)+40, blocks.length); i++) {
        for (int j = max(0, round(player.y/20)-40); j < min(round(player.y/20)+40, blocks[i].length); j++) {
          if (blocks[i][j] != null && blocks[i][j].light != null) {
            lights.add(blocks[i][j].light);
          }
        }
      }
      for (int i = max(0, round(player.x/20)-40); i < min(round(player.x/20)+40, blocks.length); i++) {
        int min_y_list_pos = 100000;
        for (int j = 0; j < blocks[i].length; j++) {
          if (blocks[i][j] != null) {
            min_y_list_pos = min(min_y_list_pos, j);
          }
        }
        if (i > 1 && i < blocks.length-1) {
          for (int j = 0; j < min_y_list_pos; j++) {
            if (blocks[i-1][j] != null) {
              lights.add(new Light(blocks[i-1][j].x, blocks[i-1][j].y, 100, color(255)));
            }
            if (blocks[i+1][j] != null) {
              lights.add(new Light(blocks[i+1][j].x, blocks[i+1][j].y, 100, color(255)));
            }
          }
        }
        lights.add(new Light(blocks[i][min_y_list_pos].x, blocks[i][min_y_list_pos].y, 100, color(255)));
      }
      for (Block[] block_row : blocks) {
        for (Block block : block_row) {
          if (block != null) {
            block.update(lights);
          }
        }
      }
      state = "play";
      fill(0);
      textFont(createFont("Arial", 15, true), 15);
      textAlign(RIGHT);
    }
  }

  public void update() {
    if (state.equals("menu")) {
      image(main_menu_screen, width/2, height/2);
      Button button_continue = new Button(width/2, height/2, "button_continue.png", "button_continue_hovered.png");
      Button button_new_game = new Button(width/2, height*0.65f, "button_new_game.png", "button_new_game_hovered.png");
      Button button_exit = new Button(width/2, height*0.9f, "button_exit.png", "button_exit_hovered.png");
      button_continue.display();
      button_new_game.display();
      button_exit.display();
      if (button_continue.clicked) {
        state = "load_world_file";
      } else if (button_new_game.clicked) {
        state = "load_1";
      } else if (button_exit.clicked) {
        exit();
      }
    } else if (state.equals("play")) {
      textAlign(RIGHT);
      background(25, 120, 250);
      pushMatrix();
      
      //float player_biome_offset = (player.x+400)%(biome_width*20);
      if (player.x+400 < biome_width*19) {
        //image(biome_backgrounds[0], width/2+map((player.x+400)%(biome_width*20), 0, biome_width*20, -480, 480), height/2);
        //image(biome_backgrounds[0], width/2+(((player.x+400)/(biome_width*20))*960)-480, height/2);
        //image(biome_backgrounds[0], width/2+(((400)/(biome_width*20))*960)-480, height/2);
        //image(biome_backgrounds[0], ((player.x+400)*(1/(biome_width*20)))*960, height/2);
        //image(biome_backgrounds[0], width/2+(((player.x+400)/(1*(biome_width*20)))*960)-480, height/2);
        image(biome_backgrounds[0], constrain(width/2-PApplet.parseInt((((player.x)+400)/(biome_width*20))*960)+480, 0, width), height/2);
      } else if (player.x+400 < biome_width*21) {
        image(biome_backgrounds[0], constrain(width/2-PApplet.parseInt((((player.x)+400)/(biome_width*20))*960)+480, 0, width), height/2);
        tint(255, map(player.x+400-biome_width*19, 0, biome_width*2, 1, 254));
        image(biome_backgrounds[1], constrain(width/2-PApplet.parseInt((((player.x-biome_width*20)+400)/(biome_width*20))*960)+480, 0, width), height/2);
      } else if (player.x+400 < biome_width*39) {
        image(biome_backgrounds[1], constrain(width/2-PApplet.parseInt((((player.x-biome_width*20)+400)/(biome_width*20))*960)+480, 0, width), height/2);
      } else if (player.x+400 < biome_width*41) {
        image(biome_backgrounds[1], constrain(width/2-PApplet.parseInt((((player.x-biome_width*20)+400)/(biome_width*20))*960)+480, 0, width), height/2);
        tint(255, map(player.x+400-biome_width*39, 0, biome_width*2, 1, 254));
        image(biome_backgrounds[2], constrain(width/2-PApplet.parseInt((((player.x-biome_width*40)+400)/(biome_width*20))*960)+480, 0, width), height/2);
      } else if (player.x+400 < biome_width*59) {
        image(biome_backgrounds[2], constrain(width/2-PApplet.parseInt((((player.x-biome_width*40)+400)/(biome_width*20))*960)+480, 0, width), height/2);
      } else if (player.x+400 < biome_width*61) {
        image(biome_backgrounds[2], constrain(width/2-PApplet.parseInt((((player.x-biome_width*40)+400)/(biome_width*20))*960)+480, 0, width), height/2);
        tint(255, map(player.x+400-biome_width*59, 0, biome_width*2, 1, 254));
        image(biome_backgrounds[3], constrain(width/2-PApplet.parseInt((((player.x-biome_width*60)+400)/(biome_width*20))*960)+480, 0, width), height/2);
      } else {
        image(biome_backgrounds[3], constrain(width/2-PApplet.parseInt((((player.x-biome_width*60)+400)/(biome_width*20))*960)+480, 0, width), height/2);
      }
      noTint();
      
      translate(width/2-player.x, height/2-player.y);
      int render_distance = 25;
      //finds all the light sources
      ArrayList<Light> lights = new ArrayList<Light>();
      for (Particle particle : particles) {
        if (particle.light_level > 0 && particle.fuse > 0) {
          lights.add(new Light(particle.x, particle.y, particle.light_level, particle.theColor));
        }
      }
      for (int i = max(0, round((player.x+200)/20)-render_distance); i < min(round((player.x+200)/20)+render_distance, blocks.length); i++) {
        for (int j = max(0, round(player.y/20)-render_distance); j < min(round(player.y/20)+render_distance, blocks[i].length); j++) {
          if (blocks[i][j] != null && blocks[i][j].light != null) {
            lights.add(blocks[i][j].light);
          }
        }
      }
      
      //the 'sun'
      //render_distance *= 1.5;
      for (int i = max(0, round(player.x/20)-render_distance+player_offset); i < min(round(player.x/20)+render_distance+player_offset, blocks.length); i++) {
        int min_y_list_pos_blocks = 1000000;
        //for (int j = 0; j < blocks[i].length-1; j++) {
        for (int j = max(0, round(player.y/20)-render_distance); j < min(round(player.y/20)+render_distance, blocks[i].length); j++) {
          if (blocks[i][j] != null) {
            min_y_list_pos_blocks = min(min_y_list_pos_blocks, j);
          }
        }
        if (min_y_list_pos_blocks == 1000000) {
          continue;
        }
        
        for (int j = max(0, round(player.y/20)-render_distance); j < min_y_list_pos_blocks; j++) {
          try {
            if (i >= 1 && (blocks[i-1][j] != null)) {
              lights.add(new Light(blocks[i-1][j].x, blocks[i-1][j].y, 100, color(255)));
            }
          } catch (ArrayIndexOutOfBoundsException e) {
            println("i: " + i + " j: " + j);
          }
          if (i <= blocks.length-2 && (blocks[i+1][j] != null)) {
            lights.add(new Light(blocks[i+1][j].x, blocks[i+1][j].y, 100, color(255)));
          }
        }
        
        lights.add(new Light(blocks[i][min_y_list_pos_blocks].x, blocks[i][min_y_list_pos_blocks].y, 100, color(255)));
      }
      //render_distance /= 1.5;
     
      //updates all the blocks evenly over 60 ticks
      for (int i = max(0, round((player.x/20)+player_offset)+round(2*render_distance*(block_update_counter/max_block_update_counter)) - render_distance); i < min(blocks.length, round((player.x/20)+player_offset) + round(2*render_distance*((block_update_counter+1)/max_block_update_counter)) - render_distance); i++) {
        for (int j = max(0, round(player.y/20)-render_distance); j < min(round(player.y/20)+render_distance, blocks[i].length); j++) {
          if (background_walls[i][j] != null) {
            background_walls[i][j].update(lights);
          }
          if (blocks[i][j] != null) {
            blocks[i][j].update(lights);
          }
        }
      }
      for (int i = max(0, round(player.x/20)-render_distance+player_offset); i < min(round(player.x/20)+render_distance+player_offset, blocks.length); i++) {
        for (int j = max(0, round(player.y/20)-render_distance); j < min(round(player.y/20)+render_distance, blocks[i].length); j++) {
          if (background_walls[i][j] != null) {
            background_walls[i][j].display();
          }
        }
      }
      for (int i = max(0, round(player.x/20)-render_distance+player_offset); i < min(round(player.x/20)+render_distance+player_offset, blocks.length); i++) {
        for (int j = max(0, round(player.y/20)-render_distance); j < min(round(player.y/20)+render_distance, blocks[i].length); j++) {
          if (blocks[i][j] != null) {
            blocks[i][j].display(lights);
          }
        }
      }
      
      if (block_update_counter == 0) {
        float average_fps = 0;
        for (float recent_fps_value : recent_fps) {
          average_fps += recent_fps_value/recent_fps.size();
        }
        //if (average_fps < 55) {
        //  max_block_update_counter++;
        //} else {
        //  max_block_update_counter--;
        //}
        if (abs(average_fps-55) > 5) {
          max_block_update_counter = constrain(max_block_update_counter+round((55-average_fps)/5), 10, 10);
        }
        block_update_counter = max_block_update_counter;
      }
      block_update_counter--;
      for (int i = enemies.size() - 1; i > 0; i--) {
        if (!enemies.get(i).is_dead && dist(player.x, player.y, enemies.get(i).location.x, enemies.get(i).location.y) < 20*40) {
          enemies.get(i).update(player);
          enemies.get(i).display();
        } else if (enemies.get(i).is_dead) {
          enemies.remove(i);
        }
      }
      for (int i = enemy_bullets.size() - 1; i > 0; i--) {
        if (enemy_bullets.get(i).should_be_destroyed()) {
          enemy_bullets.remove(i);
        } else {
          enemy_bullets.get(i).update();
        }
      }
      player.update(lights);
      //for (int i = enemies.size() - 1; i > 0; i--) {
      //  player.checkAttack(enemies.get(i));
      //}
      for (Particle particle : particles) {
        particle.update();
      }
      text("FPS: " + str(round(frameRate)), width, 12);
      text("TPU: " + max_block_update_counter, width, 25);
      text("Health: " + player.health, width, 37);
      recent_fps.append(frameRate);
      while (recent_fps.size() >= 50) {
        recent_fps.remove(0);
      }
      
      forest_enemies = 0;
      cave_enemies = 0;
      desert_enemies = 0;
      wasteland_enemies = 0;
      for (Enemy enemy : enemies) {
        if (!enemy.is_dead) {
          if (enemy.type.equals("goblin") || enemy.type.equals("orc") || enemy.type.equals("forest wizard") || enemy.type.equals("phantom") || enemy.type.equals("cyclops") || enemy.type.equals("cyclops tower")) {
            forest_enemies++;
          } else if (enemy.type.equals("skeleton") || enemy.type.equals("skeleton knight") || enemy.type.equals("necromancer")) {
            cave_enemies++;
          } else if (enemy.type.equals("angry cactus") || enemy.type.equals("sand wraith")) {
            desert_enemies++;
          } else if (enemy.type.equals("shear back beetle") || enemy.type.equals("living bomb") || enemy.type.equals("living boulder")) {
            wasteland_enemies++;
          } else {
            println("Unidentified enemy: " + enemy.type);
            exit();
          }
        }
      }
      
      if (player.x + player_offset < biome_width * 20) {                        //forest
        if (pow( spawn_speed, forest_enemies) > random(spawn_speed)) {
          float spawn = random(1);
          float enemy_x = random(-player_offset, biome_width*20-player_offset);
          int enemy_y = 1000000;
          for (int j = 0; j < blocks[0].length-1; j++) {
            if (blocks[round((enemy_x+player_offset)/20)][j] != null) {
              enemy_y = min(enemy_y, j*20);
            }
          }
          
          if (spawn > 0.9f) {
            enemies.add(new ForestWizard(enemy_x, enemy_y, blocks));
          } else if (spawn > 0.3f) {
            enemies.add(new Goblin(enemy_x, enemy_y, blocks));
          } else if (spawn > 0.1f) {
            enemies.add(new Orc(enemy_x, enemy_y, blocks));
          } else {
            enemies.add(new Phantom(enemy_x, random(-player_offset, biome_width*20-player_offset)));
          }
          //enemies.add(new Cyclops(enemy_x, enemy_y, blocks));
        }
      } else if (player.x + player_offset < 2 * biome_width * 20) {             //undergorund
        if (pow( spawn_speed, cave_enemies) > random(spawn_speed)) {
          float spawn = random(1);
          float enemy_x = random(biome_width*20-player_offset, 2*biome_width*20-player_offset);
          int enemy_y = 1000000;
          for (int j = 0; j < blocks[0].length-1; j++) {
            if (blocks[round((enemy_x+player_offset)/20)][j] != null) {
              enemy_y = min(enemy_y, j*20);
            }
          }
          
          if (spawn > 0.4f) {
            enemies.add(new Skeleton(enemy_x, enemy_y, blocks));
          } else if (spawn > 0.1f) {
            enemies.add(new SkeletonKnight(enemy_x, enemy_y, blocks));
          } else {
            enemies.add(new Necromancer(enemy_x, enemy_y, blocks));
          }
        }
      } else if (player.x + player_offset < 3 * biome_width * 20) {            //desert
        if (pow( spawn_speed, desert_enemies) > random(spawn_speed)) {
          float spawn = random(1);
          float enemy_x = random(2*biome_width*20-player_offset, 3*biome_width*20-player_offset);
          int enemy_y = 1000000;
          for (int j = 0; j < blocks[0].length-1; j++) {
            if (blocks[round((enemy_x+player_offset)/20)][j] != null) {
              enemy_y = min(enemy_y, j*20);
            }
          }
          
          if (spawn > 0.5f) {
            enemies.add(new AngryCactus(enemy_x, enemy_y, blocks));
          } else {
            enemies.add(new SandWraith(enemy_x, enemy_y));
          }
        }
      } else if (player.x + player_offset < 4 * biome_width * 20) {              //wasteland
        if (pow( spawn_speed, wasteland_enemies) > random(spawn_speed)) {
          float spawn = random(1);
          float enemy_x = random(3*biome_width*20-player_offset, 4*biome_width*20-player_offset);
          int enemy_y = 1000000;
          for (int j = 0; j < blocks[0].length-1; j++) {
            if (blocks[round((enemy_x+player_offset)/20)][j] != null) {
              enemy_y = min(enemy_y, j*20);
            }
          }
          
          if (spawn > 0.5f) {
            enemies.add(new ShearBackBeetle(enemy_x, enemy_y, blocks));
          } else if (spawn > 0.25f) {
            enemies.add(new LivingBomb(enemy_x, enemy_y, blocks));
          } else {
            enemies.add(new LivingBoulder(enemy_x, enemy_y, blocks));
            println(enemy_x, enemy_y);
          }
        }
      }
    } else if (state.equals("load_1")) {
      loadGame(1);
    } else if (state.equals("load_2")) {
      loadGame(2);
    } else if (state.equals("load_3")) {
      loadGame(3);
    } else if (state.equals("load_world_file")) {
      load_world("world", 0, 0);
    }
  }
  
  public void save_world() {
    JSONArray world = new JSONArray();
    int block_counter = 0;
    for (int i = 0; i < blocks.length; i++) {
      for (int j = 0; j < blocks[i].length; j++) {
        if (blocks[i][j] != null) {
          JSONObject current_block = new JSONObject();
          //current_block.setFloat("x", blocks[i][j].x);
          //current_block.setFloat("y", blocks[i][j].y);
          current_block.setString("data_type", "block");
          current_block.setInt("x_list_pos", blocks[i][j].x_list_pos);
          current_block.setInt("y_list_pos", blocks[i][j].y_list_pos);
          current_block.setString("type", blocks[i][j].type);
          world.setJSONObject(block_counter, current_block);
          block_counter++;
        }
      }
    }
    for (int i = 0; i < background_walls.length; i++) {
      for (int j = 0; j < background_walls[i].length; j++) {
        if (background_walls[i][j] != null) {
          JSONObject current_block = new JSONObject();
          current_block.setString("data_type", "background wall");
          current_block.setFloat("x", background_walls[i][j].x);
          current_block.setFloat("y", background_walls[i][j].y);
          current_block.setInt("x_list_pos", background_walls[i][j].x_list_pos);
          current_block.setInt("y_list_pos", background_walls[i][j].y_list_pos);
          current_block.setString("img_name", background_walls[i][j].img_name);
          current_block.setString("block_name", background_walls[i][j].type);
          world.setJSONObject(block_counter, current_block);
          block_counter++;
        }
      }
    }
    saveJSONArray(world, "data/world.json");
  }
  
  public void load_world(String world_name, int x_off, int y_off) { //blocks
    state = "play";
    JSONArray world;
    world = loadJSONArray("data/"+world_name+".json");
    for (int i = 0; i < world.size(); i++) {
      JSONObject current_block = world.getJSONObject(i);
      if (current_block.getString("data_type").equals("block")) {
        create_block(current_block.getInt("x_list_pos")+x_off, current_block.getInt("y_list_pos")+y_off, current_block.getString("type"));
      } else {
        background_walls[current_block.getInt("x_list_pos")+x_off][current_block.getInt("y_list_pos")+y_off] = new CustomBackgroundWall(current_block.getFloat("x")+x_off*20, current_block.getFloat("y")+y_off*20, current_block.getInt("x_list_pos")+x_off, current_block.getInt("y_list_pos")+y_off, current_block.getString("img_name"), current_block.getString("block_name"));
      }
    }
    for (int i = 0; i < blocks.length; i++) {
      for (int j = 0; j < blocks[i].length; j++) {
        if (blocks[i][j] != null) {
          ArrayList lights = new ArrayList<Light>();
          blocks[i][j].update(lights);
        }
      }
    }
  }
  
  public void create_block(int _x_list_pos, int _y_list_pos, String block_name) {
    if (block_name.equals("altar")) {
      blocks[_x_list_pos][_y_list_pos] = new Altar(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos);
    } else if (block_name.equals("cactus")) {
      blocks[_x_list_pos][_y_list_pos] = new CactusBlock(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos, "v");
    } else if (block_name.equals("dirt")) {
      blocks[_x_list_pos][_y_list_pos] = new DirtBlock(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos);
    } else if (block_name.equals("dried lava block")) {
      blocks[_x_list_pos][_y_list_pos] = new DriedLavaBlock(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos);
    } else if (block_name.equals("lava")) {
      blocks[_x_list_pos][_y_list_pos] = new LavaBlock(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos);
    } else if (block_name.equals("primary leaf block")) {
      blocks[_x_list_pos][_y_list_pos] = new LeafBlock(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos, "top");
    } else if (block_name.equals("secondary leaf block")) {
      blocks[_x_list_pos][_y_list_pos] = new LeafBlock(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos);
    } else if (block_name.equals("sand")) {
      blocks[_x_list_pos][_y_list_pos] = new SandBlock(_x_list_pos*20-400, _y_list_pos*20, _x_list_pos, _y_list_pos);
    } else {
      blocks[_x_list_pos][_y_list_pos] = new CustomBlock(_x_list_pos, _y_list_pos, block_name);
    }
  }
}
class Goblin extends Enemy {
  Goblin(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "goblin", "goblin.png", 50, temp_blocks);
    attack = 1;
    health = 12;
    max_health = 2;
    speed = 2;
    attack_cooldown = 50;
  }
  
  public void update(Player player) {
    //game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, 100, "dark_wizard_bullet.png", 0, 0, true));
    super.update(player);
  }
}
class Item {
  //the class for the items the player has in his inventory
  
  //global variables
  PImage inventory_img;
  String name, type;
  int mining_level, mining_speed, damage, use_cooldown;
  float size_increase;
  
  Item(PImage _inventory_img, String _type, String _name) {
    inventory_img = _inventory_img;
    type = _type;
    name = _name;
    mining_level = 1;
    mining_speed = 40;
    damage = 1;
    use_cooldown = 30;
    size_increase = 1;
  }
  
  //pick
  Item(PImage _inventory_img, String _name, int _mining_level, int _mining_speed, int _use_cooldown, float _size_increase) {
    inventory_img = _inventory_img;
    type = "picaxe";
    name = _name;
    mining_level = _mining_level;
    mining_speed = _mining_speed;
    damage = 1;
    use_cooldown = _use_cooldown;
    size_increase = _size_increase;
  }
  
  //sword
  Item(PImage _inventory_img, String _name, int _damage, int _use_cooldown, float _size_increase) {
    inventory_img = _inventory_img;
    type = "sword";
    name = _name;
    mining_level = 1;
    mining_speed = 40;
    damage = _damage;
    use_cooldown = _use_cooldown;
    size_increase = _size_increase;
  }
  
  //the item is 'used' by right clicking - at the momment, the only items that do anything when
  //used are the ones with the type 'block' (which places the block)
  public boolean use(Player player) {
    if (type.equals("summoning")) {
      if (name.equals("cyclops summoning")) {
        //game.save_world();
        thread("save_world_file");
        for (int i = 0; i < blocks.length; i++) {
          for (int j = 0; j < blocks[i].length; j++) {
            if (blocks[i][j] != null) {
              blocks[i][j].collisionPossible = false;
            }
          }
        }
        //player.x = 300;
        game.load_world("cyclops", round((player.x-300)/20), 0);
        //while (true) {
        //  if (player.y_speed == 0) {
        game.enemies.add(new Cyclops(player.x, 7800, blocks));
        game.enemies.add(new CyclopsTower(player.x-650, 7680, blocks));
        game.enemies.add(new CyclopsTower(player.x+650, 7680, blocks));
        //    break;
        //  }
        //}
        //game.enemies.add(new Cyclops(player.x, player.y, blocks));
        return true;
      }
    }
    if (type.equals("block")) {
      boolean notOnBlock = true;
      for (int i = 0; i < blocks.length; i++) {
        for (int j = 0; j < blocks[i].length; j++) {
          if  (blocks[i][j] != null &&
               (player.x+mouseX-width/2 >= blocks[i][j].x - blocks[i][j].img.width/2) &&
               (player.x+mouseX-width/2 <= blocks[i][j].x + blocks[i][j].img.width/2) &&
               (player.y+mouseY-height/2 >= blocks[i][j].y - blocks[i][j].img.height/2) &&
               (player.y+mouseY-height/2 <= blocks[i][j].y + blocks[i][j].img.height/2))
          {
            notOnBlock = false;
          }
        }
      }
      if (notOnBlock) {
        int x_list_pos = round((player.x+mouseX-width/2)/20)+20;
        int y_list_pos = round((player.y+mouseY-height/2)/20);
        float x = round((player.x+mouseX-width/2)/20)*20;
        float y = round((player.y+mouseY-height/2)/20)*20;
        
        if ((dist(player.x, player.y, x, y) > 120) || (x_list_pos < 0 || x_list_pos > blocks.length-1 || y_list_pos < 0 || y_list_pos > blocks.length-1)) {
          return false;
        }
        
        if ((background_walls[x_list_pos][y_list_pos] == null) &&
            (!checkBlock(x_list_pos+1, y_list_pos)) && 
            (!checkBlock(x_list_pos-1, y_list_pos)) && 
            (!checkBlock(x_list_pos, y_list_pos+1)) && 
            (!checkBlock(x_list_pos, y_list_pos-1))) {
          return false;
        }
        
        
        if (name.equals("altar")) {
          blocks[x_list_pos][y_list_pos] = new Altar(x, y, x_list_pos, y_list_pos);
          updateSurroundingBlocks();
          return true;
        }
        else if (name.equals("dirt")) {
          blocks[x_list_pos][y_list_pos] = new DirtBlock(x, y, x_list_pos, y_list_pos);
          updateSurroundingBlocks();
          return true;
        }
        else if (name.equals("dried lava block")) {
          blocks[x_list_pos][y_list_pos] = new DriedLavaBlock(x, y, x_list_pos, y_list_pos);
          updateSurroundingBlocks();
          return true;
        }
        else if (name.equals("lava")) {
          blocks[x_list_pos][y_list_pos] = new LavaBlock(x, y, x_list_pos, y_list_pos);
          updateSurroundingBlocks();
          return true;
        }
        else if (name.equals("sand")) {
          blocks[x_list_pos][y_list_pos] = new SandBlock(x, y, x_list_pos, y_list_pos);
          updateSurroundingBlocks();
          return true;
        } else if (true) {
          blocks[x_list_pos][y_list_pos] = new CustomBlock(x_list_pos, y_list_pos, name);
          return true;
        }
      }
    }
    return false;
  }
  
  public boolean customBlockExists(String block_name) {
    if (new CustomBlock(0, 0, block_name).mining_level != -1) {
      blocks[0][0] = null;
      return true;
    }
    return false;
  }
  
  public boolean checkBlock(int x_pos, int y_pos) {
    try {
      return (x_pos > 0 && x_pos < blocks.length && y_pos > 0 && y_pos < blocks[0].length && (blocks[x_pos][y_pos] != null));
    } catch (ArrayIndexOutOfBoundsException e) {
      return false;
    }
  }
  
  public void updateSurroundingBlocks() {
    //ArrayList<Light> lights = new ArrayList<Light>();
    //for (int i = max(0, round(round((player.x+mouseX-width/2)/20)*20/20)-5); i < min(round(round((player.x+mouseX-width/2)/20)*20/20)+5, blocks.length); i++) {
    //  for (int j = max(0, round(round((player.y+mouseY-height/2)/20)*20/20)-5); j < min(round(round((player.y+mouseY-height/2)/20)*20/20)+5, blocks[i].length); j++) {
    //    if (blocks[i][j] != null && blocks[i][j].light != null) {
    //      lights.add(blocks[i][j].light);
    //    }
    //  }
    //}
    //for (int i = max(0, round(player.x/20)-40); i < min(round(player.x/20)+40, blocks.length); i++) {
    //  int min_y_list_pos = 100000;
    //  for (int j = 0; j < blocks[i].length; j++) {
    //    if (blocks[i][j] != null) {
    //      min_y_list_pos = min(min_y_list_pos, j);
    //    }
    //  }
    //  if (i > 1 && i < blocks.length-1) {
    //    for (int j = 0; j < min_y_list_pos; j++) {
    //      if (blocks[i-1][j] != null) {
    //        lights.add(new Light(blocks[i-1][j].x, blocks[i-1][j].y, 100, color(255)));
    //      }
    //      if (blocks[i+1][j] != null) {
    //        lights.add(new Light(blocks[i+1][j].x, blocks[i+1][j].y, 100, color(255)));
    //      }
    //    }
    //  }
    //  lights.add(new Light(blocks[i][min_y_list_pos].x, blocks[i][min_y_list_pos].y, 100, color(255)));
    //}
    //for (int i = max(0, round(round((player.x+mouseX-width/2)/20)*20/20)-5); i < min(round(round((player.x+mouseX-width/2)/20)*20/20)+5, blocks.length); i++) {
    //  for (int j = max(0, round(round((player.y+mouseY-height/2)/20)*20/20)-5); j < min(round(round((player.y+mouseY-height/2)/20)*20/20)+5, blocks[i].length); j++) {
    //    if (blocks[i][j] != null) {
    //      blocks[i][j].update(lights);
    //    }
    //  }
    //}
  }
}
class ItemStack {
  //a stack of items to make things slightly easier than using an ArrayList of ArrayLists
  ArrayList<Item> items = new ArrayList<Item>();
  ItemStack(Item item, int amount) {
    for (int i = 0; i < amount; i++) {
      items.add(item);
    }
  }
}
class LavaBlock extends Block {
  //a sub class of block. used instead of CustomBlock as it has an extra script.
  PImage img, original_img;
  String type;
  //float level;
  
  LavaBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "lava_block.png", "lava", 1, null);
    original_img = texture_manager.get_texture("lava_block.png");
    img = original_img.get();
    item = null;
    super.item = null;
    super.level = 1;
    super.collisionPossible = false;
  }
  
  LavaBlock(float _x, float _y, int _x_list_pos, int _y_list_pos, float _level) {
    super(_x, _y, _x_list_pos, _y_list_pos, "lava_block.png", "lava", 1, null);
    original_img = texture_manager.get_texture("lava_block.png");
    img = original_img.get();
    item = null;
    super.item = null;
    super.level = _level;
    super.collisionPossible = false;
  }
  
  
  public void update(ArrayList<Light> lights) {
    if (!checkBlock(x_list_pos, y_list_pos+1) && (x_list_pos > 0 && x_list_pos < blocks.length && y_list_pos > 0 && y_list_pos < blocks[0].length)) {
      blocks[x_list_pos][y_list_pos+1] = new LavaBlock(super.x, super.y+20, super.x_list_pos, super.y_list_pos+1, super.level);
      blocks[x_list_pos][y_list_pos] = null;
      return;
      //update(lights);
    }
    if (checkBlockByName(x_list_pos, y_list_pos+1, "lava") && blocks[x_list_pos][y_list_pos+1].level < 1 && (x_list_pos > 0 && x_list_pos < blocks.length && y_list_pos > 0 && y_list_pos < blocks[0].length)) {
      blocks[x_list_pos][y_list_pos+1].level += super.level;
      if (blocks[x_list_pos][y_list_pos+1].level > 1) {
        super.level = blocks[x_list_pos][y_list_pos+1].level-1;
        blocks[x_list_pos][y_list_pos+1].level = 1;
      } else {
        blocks[x_list_pos][y_list_pos] = null;
        return;
      }
      
    }
    if (!checkBlock(x_list_pos+1, y_list_pos) && (x_list_pos > 0 && x_list_pos < blocks.length-1 && y_list_pos > 0 && y_list_pos < blocks[0].length)) {
      if (super.level > 0.1f) {
        super.level = super.level / 2;
        blocks[x_list_pos+1][y_list_pos] = new LavaBlock(super.x+20, super.y, super.x_list_pos+1, super.y_list_pos, super.level);
      } else {
        blocks[x_list_pos+1][y_list_pos] = new LavaBlock(super.x+20, super.y, super.x_list_pos+1, super.y_list_pos, super.level);
        blocks[x_list_pos][y_list_pos] = null;
        return;
      }
    }
    if (!checkBlock(x_list_pos-1, y_list_pos) && (x_list_pos > 1 && x_list_pos < blocks.length && y_list_pos > 0 && y_list_pos < blocks[0].length)) {
      if (super.level > 0.1f) {
        super.level = super.level / 2;
        blocks[x_list_pos-1][y_list_pos] = new LavaBlock(super.x-20, super.y, super.x_list_pos-1, super.y_list_pos, super.level);
      } else {
        blocks[x_list_pos-1][y_list_pos] = new LavaBlock(super.x-20, super.y, super.x_list_pos-1, super.y_list_pos, super.level);
        blocks[x_list_pos][y_list_pos] = null;
        return;
      }
      
    }
    if (checkBlockByName(x_list_pos+1, y_list_pos, "lava") && !(super.level >= 1 && blocks[x_list_pos+1][y_list_pos].level >= 1) && (x_list_pos > 0 && x_list_pos < blocks.length && y_list_pos > 0 && y_list_pos < blocks[0].length)) {
      super.level = (super.level+blocks[x_list_pos+1][y_list_pos].level)/2;
      blocks[x_list_pos+1][y_list_pos].level = super.level;
      
    }
    if (checkBlockByName(x_list_pos-1, y_list_pos, "lava") && !(super.level >= 1 && blocks[x_list_pos-1][y_list_pos].level >= 1) && (x_list_pos > 0 && x_list_pos < blocks.length && y_list_pos > 0 && y_list_pos < blocks[0].length)) {
      super.level = (super.level+blocks[x_list_pos-1][y_list_pos].level)/2;
      blocks[x_list_pos-1][y_list_pos].level = super.level;
    }
    
    super.img = original_img.get();
    super.img.loadPixels();
    for (int i = 0; i < super.img.width*super.img.height*(1-level); i++) {
      super.img.pixels[i] = color(0, 1);
    }
    super.img.updatePixels();
    super.update(lights);
    
    if (super.level < 0.01f) {
      blocks[x_list_pos][y_list_pos] = null;
      return;
    }// else if (super.level > 0.95) {
    //  super.level = 1;
    //}
    
    super.light = new Light(x, y, level*100, color(255, 255, 255));
    
    if (checkPlayerCollision()) {
      player.damage(level*10);
    }
  }
  
  public void display(ArrayList<Light> lights) {
    super.img = original_img.get();
    super.img.loadPixels();
    for (int i = 0; i < super.img.width*super.img.height*(1-level); i++) {
      super.img.pixels[i] = color(0, 1);
    }
    super.img.updatePixels();
    super.display(lights);
  }
  
  public boolean checkBlock(int x_pos, int y_pos) {
    try {
      return (x_pos > 0 && x_pos < blocks.length && y_pos > 0 && y_pos < blocks[0].length && (blocks[x_pos][y_pos] != null));
    } catch (ArrayIndexOutOfBoundsException e) {
      return false;
    }
  }
  
  public boolean checkBlockByName(int x_pos, int y_pos, String block_type) {
    try {
      return (x_pos > 0 && x_pos < blocks.length && y_pos > 0 && y_pos < blocks[0].length && (blocks[x_pos][y_pos] != null && blocks[x_pos][y_pos].type.equals(block_type)));
    } catch (ArrayIndexOutOfBoundsException e) {
      return false;
    }
  }
  
  public boolean checkPlayerCollision () {
    if  ((player.x + player.img_right.width/2 >= x - img.width/2) &&
         (player.x - player.img_right.width/2 <= x + img.width/2) &&
         (player.y + player.img_right.height/2 >= y - img.height/2) &&
         (player.y - player.img_right.height/2 <= y + img.height/2))
    {
          return true;
    }
    return false;
  }
}
class LeafBlock extends Block {
  //a sub class of block. used instead of CustomBlock as it has an extra script.
  LeafBlock(float _x, float _y, int _x_list_pos, int _y_list_pos, String rotation) { //primary leaf block
    super(_x, _y, _x_list_pos, _y_list_pos, "leaf_block.png", "primary leaf block", 1, null);
    img = texture_manager.get_texture("primary_leaf_block_" + rotation + ".png");
    super.item = null;
    super.max_block_health = 1;
    super.block_health = 1;
  }
  
  LeafBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) { //secondary leaf block
    super(_x, _y, _x_list_pos, _y_list_pos, "leaf_block.png", "secondary leaf block", 1, null);
    img = texture_manager.get_texture("leaf_block.png");
    super.item = null;
    super.max_block_health = 1;
    super.block_health = 1;
  }
  
  public void update(ArrayList<Light> lights) {
    if (blocks[x_list_pos][y_list_pos].type.equals("secondary leaf block")) {
      //if there is no primary leaf block in the 4 adjacent places then the secondary leaf breaks.
      if (!checkBlock(x_list_pos, y_list_pos-1, "primary leaf block") &&
          !checkBlock(x_list_pos, y_list_pos+1, "primary leaf block") &&
          !checkBlock(x_list_pos-1, y_list_pos, "primary leaf block") &&
          !checkBlock(x_list_pos+1, y_list_pos, "primary leaf block")) {
        blocks[x_list_pos][y_list_pos] = null;
        return;
      }
    } else {
      //if there is no wood in the 4 adjacent places then the primary leaf breaks.
      if (!checkBlock(x_list_pos, y_list_pos-1, "wood block") &&
          !checkBlock(x_list_pos, y_list_pos+1, "wood block") &&
          !checkBlock(x_list_pos-1, y_list_pos, "wood block") &&
          !checkBlock(x_list_pos+1, y_list_pos, "wood block")) {
        blocks[x_list_pos][y_list_pos] = null;
        return;
      }
    }
    super.img = img.get();
    super.update(lights);
  }
  
  public boolean checkBlock(int x_pos, int y_pos, String block_type) {
    return (x_pos > 0 && x_pos < blocks.length && y_pos > 0 && y_pos < blocks[0].length && (blocks[x_pos][y_pos] != null && blocks[x_pos][y_pos].type.equals(block_type)));
  }
}
class Light {
  //just a nice class to keep all the information about lights 
  float x, y, intensity;
  int lightColor;
  
  Light(float _x, float _y, float _intensity, int _lightColor) {
    x = _x;
    y = _y;
    intensity = _intensity;
    lightColor = _lightColor;
  }
}
class LivingBomb extends Enemy {
  LivingBomb(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "living bomb", "living_bomb.png", 50, temp_blocks);
    attack = 0;
    health = 10;
    max_health = 10;
    speed = 2;
    attack_cooldown = 0;
  }
  
  public void update(Player player) {
    //game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, 100, "dark_wizard_bullet.png", 0, 0, true));
    super.update(player);
    if (is_dead || dist(location.x, location.y, player.x, player.y) < 100) {
      float[] bullet_directions = new float[16];
      for (float i = 0; i < 360; i += 22.5f) {
        bullet_directions[PApplet.parseInt(i/22.5f)] = i;
      }
      for (float i : bullet_directions) {
        game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, i, 500, "living_bomb_bullet.png", 8, 0, true));
      }
      super.is_dead = true;
    }
  }
}
class LivingBoulder extends Enemy {
  float rotation;
  
  LivingBoulder(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "living boulder", "living_boulder.png", 50, temp_blocks);
    attack = 10000;
    health = 100;
    max_health = 100;
    speed = 1;
    attack_cooldown = 1;
    rotation = 0;
  }
  
  //void update(Player player) {
  //  if (player.x < location.x) {
  //    rotation++;
  //  } else {
  //    rotation--;
  //  }
  //  super.update(player);
  //}
  
  //void display() {
  //  pushMatrix();
  //  translate(location.x, location.y);
  //  rotate(radians(rotation));
  //  image(img, location.x, location.y);
  //  popMatrix();
  //}
}
class Necromancer extends Enemy {
  int spawn_timer, max_spawn_timer;
  
  Necromancer(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "necromancer", "necromancer.png", 50, temp_blocks);
    attack = 1;
    health = 25;
    max_health = 2;
    speed = 2;
    attack_cooldown = 50;
    max_spawn_timer = 500;
    spawn_timer = max_spawn_timer;
  }
  
  public void update(Player player) {
    if (spawn_timer == 0) {
      game.enemies.add(new Skeleton(location.x, location.y, blocks));
      spawn_timer = max_spawn_timer;
    } else {
      spawn_timer--;
    }
    super.update(player);
  }
}
class Orc extends Enemy {
  Orc(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "orc", "orc.png", 100, temp_blocks);
    attack = 5;
    health = 40;
    max_health = 40;
    speed = 2;
    attack_cooldown = 100;
  }
}
class Particle {
  //a class for a particle
  float x, y, x_speed, y_speed, light_level, fuse, max_fuse, size;
  boolean fade;
  int theColor;
  boolean xy;
  PImage img;
  
  Particle(float _x, float _y, float _x_speed, float _y_speed, float _fuse, int _color, float _size, float _light_level, boolean _fade) {
    x = _x;
    y = _y;
    x_speed = _x_speed;
    y_speed = _y_speed;
    light_level = _light_level;
    fuse = _fuse;
    max_fuse = _fuse;
    theColor = _color;
    size = _size;
    fade = _fade;
  }
  
  public void update() {
    if (fuse > 0) {
      x += x_speed;
      y += y_speed;
      fuse--;
      drawSprite();
    }
  }
  
  public void drawSprite() {
    rectMode(CENTER);
    if (fade) {
      fill(theColor, 255*fuse/max_fuse);
    } else {
      fill(theColor);
    }
    rect(x, y, size, size);
  }
}
class Phantom extends Enemy {
  boolean movingDown, movingUp;
  
  Phantom(float temp_x, float temp_y) {
    super(temp_x, temp_y, "phantom", "phantom_left.png", 70, null);
    attack = 3;
    health = 25;
    max_health = 25;
    speed = 5;
    attack_cooldown = 70;
  }
  
  public void update(Player _player) {
    health_check();
    checkAttack(_player);
    move();
    if (player.x < location.x) {
      super.img = texture_manager.get_texture("phantom_left.png");
    } else {
      super.img = texture_manager.get_texture("phantom_right.png");
    }
    display();
  }
  
  public void move() {
    if (player.x < location.x) {
      movingLeft = true;
      movingRight = false;
    } else {
      movingLeft = false;
      movingRight = true;
    }
    
    if (player.y < location.y) {
      movingDown = true;
      movingUp = false;
    } else {
      movingDown = false;
      movingUp = true;
    }
    
    if (movingLeft) {
      location.x -= speed;
    } else if (movingRight) {
      location.x += speed;
    }
    
    if (movingUp) {
      location.y += speed;
    } else if (movingDown) {
      location.y -= speed;
    }
  }
}
class Player {
  
  //global variables
  float x, y, speed;
  Block[][] blocks;
  
  float g_const, y_speed;
  boolean touching_ground;
  boolean facing_right;
  
  PImage img_right, img_left, original_img_right, original_img_left;
  boolean w_pressed, a_pressed, d_pressed;
  float step_cycle;
  float step_cycle_increase;
  //S, L1, L2, L1, S, R1, R2, R1
  String[] img_index_array_left = {"player_left.png", "player_left_left_step_1.png", "player_left_left_step_2.png", "player_left_left_step_1.png",
                                   "player_left.png", "player_left_right_step_1.png", "player_left_right_step_2.png", "player_left_right_step_1.png"};
  String[] img_index_array_right = {"player_right.png", "player_right_left_step_1.png", "player_right_left_step_2.png", "player_right_left_step_1.png",
                                    "player_right.png", "player_right_right_step_1.png", "player_right_right_step_2.png", "player_right_right_step_1.png"};
  
  PImage hotbar_frame, hotbar_frame_selected, recipe_frame;
  int hotbar_frame_selected_index;
  ItemStack[] inventory;
  ItemStack[] armor;
  ArrayList<RecipePointer> crafting_controller_recipe_pointers;
  boolean show_inventory;
  ItemStack held_item;
  CraftingController crafting_controller;
  
  int item_use_cooldown, max_item_use_cooldown;
  int attack, health, max_health;
  float armor_value;
  
  float playerBrightness;
  
  Player(float _x, float _y, Block[][] _blocks) {
    //global variables init
    x = _x;
    y = _y;
    speed = 5;
    original_img_right = texture_manager.get_texture("player_right.png");
    original_img_left = texture_manager.get_texture("player_left.png");
    img_right = original_img_right.get();
    img_left = original_img_left.get();
    facing_right = true;
    step_cycle = 0;
    step_cycle_increase = 0.5f;
    
    blocks = _blocks;
    
    y_speed = 0;
    g_const = 1;
    touching_ground = false;
    
    hotbar_frame = texture_manager.get_texture("hotbar.png");
    hotbar_frame_selected = texture_manager.get_texture("hotbar_selected.png");
    recipe_frame = texture_manager.get_texture("recipe_frame.png");
    hotbar_frame_selected_index = 0;
    show_inventory = false;
    
    inventory = new ItemStack[210];
    armor = new ItemStack[4];
    crafting_controller = new CraftingController(inventory);
    crafting_controller_recipe_pointers = crafting_controller.returnRecipes();
    
    item_use_cooldown = 0;
    attack = 1;
    health = 20;
    max_health = 20;
    armor_value = 0;
    
    //Item bronze_pic = new Item(texture_manager.get_texture("steel_picaxe.png"), "steel picaxe", 200000000, 100, 30, 1.25);
    //addToStack(inventory, bronze_pic);
    //addToStack(inventory, new Item(texture_manager.get_texture("altar.png"), "block", "altar"));
    //Item wooden_sword = new Item(texture_manager.get_texture("wooden_sword.png"), "wooden sword", 100, 30, 1.25);
    //addToStack(inventory, wooden_sword);
    //for (int i = 0; i < 5000; i++) {
    //  addToStack(inventory, new Item(texture_manager.get_texture("lava_block.png"), "block", "lava"));
    //  addToStack(inventory, new Item(texture_manager.get_texture("torch.png"), "block", "torch"));
    //  addToStack(inventory, new Item(texture_manager.get_texture("stone_brick.png"), "block", "stone brick"));
      
    //  addToStack(inventory, new Item(texture_manager.get_texture("copper_ingot.png"), "item", "copper ingot"));
    //  addToStack(inventory, new Item(texture_manager.get_texture("tin_ingot.png"), "item", "tin ingot"));
    //  addToStack(inventory, new Item(texture_manager.get_texture("bronze_ingot.png"), "item", "bronze ingot"));
    //  addToStack(inventory, new Item(texture_manager.get_texture("iron_ingot.png"), "item", "iron ingot"));
    //  addToStack(inventory, new Item(texture_manager.get_texture("steel_ingot.png"), "item", "steel ingot"));
    //}
    //addToStack(inventory, new Item(texture_manager.get_texture("goblin.png"), "summoning", "cyclops summoning"));
    //addToStack(inventory, new Item(texture_manager.get_texture("iron_armor.png"), "armor", "iron armor"));
  }
  
  public void update(ArrayList<Light> lights) {
    println("x: "+x+"\ty: "+y);
    try {
      max_item_use_cooldown = inventory[hotbar_frame_selected_index].items.get(0).use_cooldown;
    } catch (NullPointerException e) {
      max_item_use_cooldown = 30;
    }
    check_health();
    move();
    applyGravity();
    display(lights);
    popMatrix();
    checkBlockBreaking();
    //checkAttack();
    //loadPixels();
    //for (int i = 0; i < pixels.length; i++) {
    //  pixels[i] = lerpColor(color(pixels[i]), color(0, 50, 120), 0.8);
    //}
    //updatePixels();
    fill(0, 50, 120, 200);
    //rect(0, 0, width, height);
    drawHotbar();
    drawInventory();
  }
  
  //player controls
  public void keyPressed() {
    if (key == 'a') {
      a_pressed = true;
      facing_right = false;
    }
    if (key == 'd') {
      d_pressed = true;
      facing_right = true;
    }
    if (key == 'w') {
      w_pressed = true;
    }
    
    if (key == '1' || key == '2' || key == '3' || key == '4' || key == '5' || key == '6' || key == '7' || key == '8' || key == '9' || key == '0') {
      hotbar_frame_selected_index = PApplet.parseInt(str(key))-1;
      if (hotbar_frame_selected_index == -1) {
        hotbar_frame_selected_index = 9;
      }
    }
    
    if (key == 'e') {
      show_inventory = !show_inventory;
    }
    
    if (key == 'q') {
      game.save_world();
    }
  }
  
  public void keyReleased() {
    if (key == 'a') {
      a_pressed = false;
    }
    if (key == 'd') {
      d_pressed = false;
    }
    if (key == 'w') {
      w_pressed = false;
    }
  }
  
  public void mousePressed() {
    //rect(player.x+mouseX-width/2, player.y+mouseY-height/2, 20, 20);
    if (mouseButton == RIGHT && !show_inventory) {
      if (inventory.length > hotbar_frame_selected_index) {
        if (inventory[hotbar_frame_selected_index] != null) {
          if (inventory[hotbar_frame_selected_index].items.get(0).use(player)) {
            inventory[hotbar_frame_selected_index].items.remove(0);
            if (inventory[hotbar_frame_selected_index].items.size() <= 0) {
              inventory[hotbar_frame_selected_index] = null;
            }
          }
        }
      }
    }
  }
  
  public void mouseClicked() {
    if (show_inventory) {
      for (int i = 0; i < crafting_controller.returnRecipes().size(); i++) {
        if (mouseX < 30+i*40 + recipe_frame.width/2 &&
            mouseX > 30+i*40 - recipe_frame.width/2 &&
            mouseY < 550 + recipe_frame.height/2 &&
            mouseY > 550 - recipe_frame.height/2) {
            crafting_controller.executeRecipe(crafting_controller.returnRecipes().get(i));
            return;
        }
      }
    
      for (int i = 0; i < 10; i++) {
        if (mouseX < 30+i*50 + hotbar_frame.width/2 &&
            mouseX > 30+i*50 - hotbar_frame.width/2 &&
            mouseY < 30 + hotbar_frame.height/2 &&
            mouseY > 30 - hotbar_frame.height/2) {
            if (held_item == null) {
              held_item = inventory[i];
              inventory[i] = null;
            } else if (held_item != null && inventory[i] == null) {
              inventory[i] = held_item;
              held_item = null;
            } else if (held_item != null && inventory[i] != null) {
              ItemStack temp_item = held_item;
              held_item = inventory[i];
              inventory[i] = temp_item;
            }
            return;
        }
        
      }
      
      for (int i = 0; i < 20; i++) {
        for (int j = 1; j < 11; j++) {
          if (mouseX < 30+i*40 + hotbar_frame.width/2 &&
              mouseX > 30+i*40 - hotbar_frame.width/2 &&
              mouseY < 30+j*40 + hotbar_frame.height/2 &&
              mouseY > 30+j*40 - hotbar_frame.height/2) {
              if (held_item == null) {
                held_item = inventory[i+j*20-10];
                inventory[i+j*20-10] = null;
              } else if (held_item != null && inventory[i+j*20-10] == null) {
                inventory[i+j*20-10] = held_item;
                held_item = null;
              } else if (held_item != null && inventory[i+j*20-10] != null) {
                ItemStack temp_item = held_item;
                held_item = inventory[i+j*20-10];
                inventory[i+j*20-10] = temp_item;
              }
        }
      }
    }
    
    
    for (int i = 0; i < armor.length; i++) {
      if (held_item == null ||
          (i == 0 && held_item.items.get(0).type.equals("helmet")) || 
          (i == 1 && held_item.items.get(0).type.equals("armor")) || 
          (i == 2 && held_item.items.get(0).type.equals("boots")) || 
          (i == 3 && held_item.items.get(0).type.equals("accessory"))) {
        if (mouseX < width - 100 + hotbar_frame.width/2 &&
            mouseX > width - 100 - hotbar_frame.width/2 &&
            mouseY < 80+i*40 + hotbar_frame.height/2 &&
            mouseY > 80+i*40 - hotbar_frame.height/2) {
            if (held_item == null) {
              held_item = armor[i];
              armor[i] = null;
            } else if (held_item != null && armor[i] == null) {
              armor[i] = held_item;
              held_item = null;
            } else if (held_item != null && armor[i] != null) {
              ItemStack temp_item = held_item;
              held_item = armor[i];
              armor[i] = temp_item;
            }
            return;
        }
      }
    }
    
    //for (int i = 0; i < armor.length; i++) {
    //  if (
    //  image(hotbar_frame, width-100, 80+i*40);
    //  if (armor[i] != null) {
    //    image(inventory[inventory_counter].items.get(0).inventory_img, width-100, 80+i*40);
    //  }
    //}
    
    }
  }
  
  //adds an item to the inventory - first checks if a stack
  //of items of the same type already exists (in which case it
  //adds the item to the stack), or creates a new stack of items
  //of that type
  public void addToStack(ItemStack[] inventory, Item item) {
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] != null) {
        if (inventory[i].items.get(0).name.equals(item.name)) {
          inventory[i].items.add(item);
          return;
        }
      }
    }
    for (int i = 0; i < inventory.length; i++) {
      if (inventory[i] == null) {
        inventory[i] = new ItemStack(item, 1);
        return;
      }
    }
  }
  
  public void move() {
    if (a_pressed) {
      x -= speed;
      boolean noCollision = true;
      for (int i = max(0, round(x/20)-40); i < min(round(x/20)+40, blocks.length); i++) {
        for (int j = max(0, round(y/20)-40); j < min(round(y/20)+40, blocks[i].length); j++) {
          if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectBlockCollision(blocks[i][j])) {
            noCollision = false;
          }
        }
      }
      if (!noCollision) {
        x += speed;
        if (touching_ground) {
          y_speed = -7;
        }
      }
      step_cycle += step_cycle_increase;
      if (step_cycle >= 8) {
        step_cycle = 0;
      }
      original_img_left = texture_manager.get_texture(img_index_array_left[PApplet.parseInt(step_cycle)]);
    }
    if (d_pressed) {
      x += speed;
      boolean noCollision = true;
      for (int i = max(0, round(x/20)-40); i < min(round(x/20)+40, blocks.length); i++) {
        for (int j = max(0, round(y/20)-40); j < min(round(y/20)+40, blocks[i].length); j++) {
          if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectBlockCollision(blocks[i][j])) {
            noCollision = false;
          }
        }
      }
      if (!noCollision) {
        x -= speed;
        if (touching_ground) {
          y_speed = -7;
        }
      }
      step_cycle += step_cycle_increase;
      if (step_cycle >= 8) {
        step_cycle = 0;
      }
      original_img_right = texture_manager.get_texture(img_index_array_right[PApplet.parseInt(step_cycle)]);
    }
    if (w_pressed && touching_ground) {
      y_speed = -15;
    }
  }
  
  public void check_health() {
    if (health <= 0) {
      //println("You dun goofed.");
      //exit();
      x = 400;
      y = -height/2;
      health = 20;
    } else if (y > 10000) {
      x = 400;
      y = -height/2;
      health = 20;
    }
  }
  
  //displays the player and the item in his hand
  public void display(ArrayList<Light> lights) {
    roughLighting(lights);
    if (facing_right) {
      image(img_right, x, y);
      if (inventory[hotbar_frame_selected_index] != null) {
        PImage holding_item_image = inventory[hotbar_frame_selected_index].items.get(0).inventory_img.get();
        holding_item_image = itemRoughLighting(lights, holding_item_image);
        pushMatrix();
        if (inventory[hotbar_frame_selected_index].items.get(0).type.equals("picaxe")) {
          holding_item_image.resize(round(inventory[hotbar_frame_selected_index].items.get(0).inventory_img.width*inventory[hotbar_frame_selected_index].items.get(0).size_increase), round(inventory[hotbar_frame_selected_index].items.get(0).inventory_img.height*inventory[hotbar_frame_selected_index].items.get(0).size_increase));
          translate(x+7.5f, y+7.5f);
          rotate(radians(map(max_item_use_cooldown-item_use_cooldown, 0, max_item_use_cooldown, 0, 30)*4));
          translate(12.5f, -12.5f);
        } else if (inventory[hotbar_frame_selected_index].items.get(0).type.equals("sword")) {
          holding_item_image.resize(round(inventory[hotbar_frame_selected_index].items.get(0).inventory_img.width*inventory[hotbar_frame_selected_index].items.get(0).size_increase), round(inventory[hotbar_frame_selected_index].items.get(0).inventory_img.height*inventory[hotbar_frame_selected_index].items.get(0).size_increase));
          if (item_use_cooldown>max_item_use_cooldown/3) {
            translate(x+7.5f+map(max_item_use_cooldown-item_use_cooldown, 0, max_item_use_cooldown, 0, 30)/3, y+7.5f);
            rotate(radians(map(max_item_use_cooldown-item_use_cooldown, 0, max_item_use_cooldown, 0, 30)*2.25f));
            translate(12.5f, -12.5f);
          } else {
            translate(x+7.5f+(map(item_use_cooldown, 0, max_item_use_cooldown, 0, 30))/3, y+7.5f);
            rotate(radians(45));
            translate(12.5f, -12.5f);
          }
        } else {
          holding_item_image.resize(10, 10);
          translate(x+10, y+10);
          rotate(radians(80));
        }
        image(holding_item_image, 0, 0);
        popMatrix();
        if (armor[1] != null) {
          image(armor[1].items.get(0).inventory_img, x, y);
          println("!");
        }
      }
    } else {
      image(img_left, x, y);
      if (inventory[hotbar_frame_selected_index] != null) {
        PImage holding_item_image = inventory[hotbar_frame_selected_index].items.get(0).inventory_img.get();
        holding_item_image = itemRoughLighting(lights, holding_item_image);
        pushMatrix();
        if (inventory[hotbar_frame_selected_index].items.get(0).type.equals("picaxe")) {
          holding_item_image.resize(25, 25);
          translate(x-7.5f, y+7.5f);
          rotate(radians(map(max_item_use_cooldown-item_use_cooldown, 0, max_item_use_cooldown, 0, 30)*-4));
          translate(-12.5f, -12.5f);
          rotate(radians(-90));
        } else if (inventory[hotbar_frame_selected_index].items.get(0).type.equals("sword")) {
          holding_item_image.resize(25, 25);
          if (item_use_cooldown>max_item_use_cooldown/3) {
            translate(x-7.5f-(map(max_item_use_cooldown-item_use_cooldown, 0, max_item_use_cooldown, 0, 30))/3, y+7.5f);
            rotate(radians((map(max_item_use_cooldown-item_use_cooldown, 0, max_item_use_cooldown, 0, 30))*-2.25f));
            translate(-12.5f, -12.5f);
            rotate(radians(-90));
          } else {
            translate(x-7.5f-map(item_use_cooldown, 0, max_item_use_cooldown, 0, 30)/3, y+7.5f);
            rotate(radians(-45));
            translate(-12.5f, -12.5f);
            rotate(radians(-90));
          }
        } else {
          holding_item_image.resize(10, 10);
          translate(x-10, y+10);
          rotate(radians(-80));
        }
        image(holding_item_image, 0, 0);
        popMatrix();
      }
    }
  }
  
  public void roughLighting(ArrayList<Light> lights) {
    playerBrightness = 0;
    PImage img;
    if (facing_right) {
      img = original_img_right.get();
    } else {
      img = original_img_left.get();
    }
    img.loadPixels();
    for (Light light : lights) {
      float dist_to_light = dist(x, y, light.x, light.y);
      float current_light_intensity = constrain(light.intensity/pow(dist_to_light/50, 2), 0, light.intensity);
      for (int i = 0; i < img.width*img.height; i++) {
        int r = round(red(img.pixels[i]));
        int g = round(green(img.pixels[i]));
        int b = round(blue(img.pixels[i]));
        if (light.lightColor != color(255)) {
          if (current_light_intensity <= 1) {
            r = round((red(img.pixels[i]) + red(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
            g = round((green(img.pixels[i]) + green(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
            b = round((blue(img.pixels[i]) + blue(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
          } else {
            r = round((red(img.pixels[i]) + red(light.lightColor))/2);
            g = round((green(img.pixels[i]) + green(light.lightColor))/2);
            b = round((blue(img.pixels[i]) + blue(light.lightColor))/2);
          }
          }
        img.pixels[i] = color(round(r), round(g), round(b), alpha(img.pixels[i]));
      }
      float tempBrightness = current_light_intensity/10;
      playerBrightness = max(playerBrightness, tempBrightness);
    }
    playerBrightness = constrain(playerBrightness, 0, 1);
    for (int i = 0; i < img.width*img.height; i++) {
      img.pixels[i] = color(red(img.pixels[i])*playerBrightness, green(img.pixels[i])*playerBrightness, blue(img.pixels[i])*playerBrightness, alpha(img.pixels[i]));
    }
    img.updatePixels();
    if (facing_right) {
      img_right = img.get();
    } else {
      img_left = img.get();
    }
  }
  
  public PImage itemRoughLighting(ArrayList<Light> lights, PImage img) {
    playerBrightness = 0;
    img.loadPixels();
    for (Light light : lights) {
      float dist_to_light = dist(x, y, light.x, light.y);
      float current_light_intensity = constrain(light.intensity/pow(dist_to_light/50, 2), 0, light.intensity);
      for (int i = 0; i < img.width*img.height; i++) {
        int r = round(red(img.pixels[i]));
        int g = round(green(img.pixels[i]));
        int b = round(blue(img.pixels[i]));
        if (light.lightColor != color(255)) {
          if (current_light_intensity <= 1) {
            r = round((red(img.pixels[i]) + red(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
            g = round((green(img.pixels[i]) + green(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
            b = round((blue(img.pixels[i]) + blue(light.lightColor)*current_light_intensity)/(1+current_light_intensity));
          } else {
            r = round((red(img.pixels[i]) + red(light.lightColor))/2);
            g = round((green(img.pixels[i]) + green(light.lightColor))/2);
            b = round((blue(img.pixels[i]) + blue(light.lightColor))/2);
          }
          }
        img.pixels[i] = color(round(r), round(g), round(b), alpha(img.pixels[i]));
      }
      float tempBrightness = current_light_intensity/10;
      playerBrightness = max(playerBrightness, tempBrightness);
    }
    playerBrightness = constrain(playerBrightness, 0, 1);
    for (int i = 0; i < img.width*img.height; i++) {
      img.pixels[i] = color(red(img.pixels[i])*playerBrightness, green(img.pixels[i])*playerBrightness, blue(img.pixels[i])*playerBrightness, alpha(img.pixels[i]));
    }
    img.updatePixels();
    return img;
  }
  
  public void applyGravity() {
    y_speed = constrain(100000000, 200, y_speed+g_const);
    y += y_speed;
    boolean noCollision = true;
    touching_ground = false;
    for (int i = max(0, round(x/20)-40); i < min(round(x/20)+40, blocks.length); i++) {
      for (int j = max(0, round(y/20)-40); j < min(round(y/20)+40, blocks[i].length); j++) {
        if (blocks[i][j] != null && blocks[i][j].collisionPossible && detectBlockCollision(blocks[i][j])) {
          noCollision = false;
        }
      }
    }
    if (!noCollision) {
      y -= y_speed;
      y_speed = 0;
      touching_ground = true;
    }
  }
  
  public boolean detectBlockCollision (Block block) {
    if  ((x + img_right.width/2 >= block.x - block.img.width/2) &&
         (x - img_right.width/2 <= block.x + block.img.width/2) &&
         (y + img_right.height/2 >= block.y - block.img.height/2) &&
         (y - img_right.height/2 <= block.y + block.img.height/2))
    {
          return true;
    }
    return false;
  }
  
  public boolean detectCollision (PImage img1, float x1, float y1, PImage img2, float x2, float y2) {
    if  ((x1 + img1.width/2 >= x2 - img2.width/2) &&
         (x1 - img1.width/2 <= x2 + img2.width/2) &&
         (y1 + img1.height/2 >= y2 - img2.height/2) &&
         (y1 - img1.height/2 <= y2 + img2.height/2))
    {
          return true;
    }
    return false;
  }
  
  //checks if the player is hitting a block
  public void checkBlockBreaking() {
    if (mousePressed && mouseButton == LEFT) {
      if (item_use_cooldown == 0) {
        item_use_cooldown = max_item_use_cooldown;
        if (!show_inventory) {
          for (int i = 0; i < blocks.length; i++) {
            for (int j = 0; j < blocks[i].length; j++) {
              if  (blocks[i][j] != null &&
                   (player.x+mouseX-width/2 >= blocks[i][j].x - blocks[i][j].img.width/2) &&
                   (player.x+mouseX-width/2 <= blocks[i][j].x + blocks[i][j].img.width/2) &&
                   (player.y+mouseY-height/2 >= blocks[i][j].y - blocks[i][j].img.height/2) &&
                   (player.y+mouseY-height/2 <= blocks[i][j].y + blocks[i][j].img.height/2) &&
                   (dist(player.x, player.y, blocks[i][j].x, blocks[i][j].y) < 120))
              {
                int player_mining_level, player_mining_speed;
                if (inventory[hotbar_frame_selected_index] == null) {
                  player_mining_level = 1;
                  player_mining_speed = 40;
                } else {
                  player_mining_level = inventory[hotbar_frame_selected_index].items.get(0).mining_level;
                  player_mining_speed = inventory[hotbar_frame_selected_index].items.get(0).mining_speed;
                }
                if (blocks[i][j].mining_level <= player_mining_level) {
                  blocks[i][j].block_health -= player_mining_speed;
                  if (blocks[i][j].block_health <= 0) {
                    if (blocks[i][j].item != null) {
                      addToStack(inventory, blocks[i][j].item);
                    }
                    blocks[i][j].kill();
                    //blocks[i][j] = null;
                  }
                }
              }
            }
          }
          
          for (int i = 0; i < game.enemies.size(); i++) {
            if (inventory[hotbar_frame_selected_index] != null) {
              //println("click" + dist(0, 0, inventory[hotbar_frame_selected_index].items.get(0).inventory_img.width*inventory[hotbar_frame_selected_index].items.get(0).size_increase, inventory[hotbar_frame_selected_index].items.get(0).inventory_img.height*inventory[hotbar_frame_selected_index].items.get(0).size_increase));
              if ((facing_right && dist(x+20, y-5, game.enemies.get(i).location.x, game.enemies.get(i).location.y) < dist(0, 0, inventory[hotbar_frame_selected_index].items.get(0).inventory_img.width*inventory[hotbar_frame_selected_index].items.get(0).size_increase, inventory[hotbar_frame_selected_index].items.get(0).inventory_img.height*inventory[hotbar_frame_selected_index].items.get(0).size_increase) + dist(0, 0, game.enemies.get(i).img.width/2, game.enemies.get(i).img.height/2)) ||
                  (!facing_right && dist(x-20, y-5, game.enemies.get(i).location.x, game.enemies.get(i).location.y) < dist(0, 0, inventory[hotbar_frame_selected_index].items.get(0).inventory_img.width*inventory[hotbar_frame_selected_index].items.get(0).size_increase, inventory[hotbar_frame_selected_index].items.get(0).inventory_img.height*inventory[hotbar_frame_selected_index].items.get(0).size_increase) + dist(0, 0, game.enemies.get(i).img.width/2, game.enemies.get(i).img.height/2))) {
                game.enemies.get(i).health -= inventory[hotbar_frame_selected_index].items.get(0).damage;
                game.enemies.get(i).knockback_on = true;
                PVector temp = new PVector(game.enemies.get(i).location.x - x, game.enemies.get(i).location.y - y - img_right.height/2);
                temp.normalize();
                temp.mult(10);
                game.enemies.get(i).knockback = temp;
                println("hit " + inventory[hotbar_frame_selected_index].items.get(0).damage);
              }
            } else {
              if ((facing_right && dist(x+20, y-5, game.enemies.get(i).location.x, game.enemies.get(i).location.y) < 50) ||
                  (!facing_right && dist(x-20, y-5, game.enemies.get(i).location.x, game.enemies.get(i).location.y) < 50)) {
                game.enemies.get(i).health -= 1;
                game.enemies.get(i).knockback_on = true;
                PVector temp = new PVector(game.enemies.get(i).location.x - x, game.enemies.get(i).location.y - y - img_right.height/2);
                temp.normalize();
                temp.mult(10);
                game.enemies.get(i).knockback = temp;
              }
            }
          }
          
        }
      } else {
        item_use_cooldown--;
      }
    } else {
      item_use_cooldown = max_item_use_cooldown;
    }
  }
  
  //draws the hotbar
  public void drawHotbar() {
    for (int i = 0; i < 10; i++) {
      if (i == hotbar_frame_selected_index) {
        image(hotbar_frame_selected, 30+i*50, 30);
      } else {
        image(hotbar_frame, 30+i*50, 30);
      }
      if (inventory.length > i) {
        if (inventory[i] != null) {
          image(inventory[i].items.get(0).inventory_img, 30+i*50, 30);
          if (inventory[i].items.size() > 0) {
            fill(0);
            text("x"+str(inventory[i].items.size()), 30+hotbar_frame.width/2+i*50, 40);
          }
        }
      }
    }
  }
  
  //draws the inventory if needed
  public void drawInventory() {
    if (show_inventory) {
      int inventory_counter = 10;
      for (int j = 1; j < 11; j++) {
        for (int i = 0; i < 20; i++) {
          image(hotbar_frame, 30+i*40, 30+j*40);
            if (inventory[inventory_counter] != null) {
              image(inventory[inventory_counter].items.get(0).inventory_img, 30+i*40, 30+j*40);
              if (inventory[inventory_counter].items.size() >= 2) {
                fill(0);
                text("x"+str(inventory[inventory_counter].items.size()), 30+hotbar_frame.width/2+i*40, 40+j*40);
              }
            }
          inventory_counter++;
        }
      }
      
      for (int i = 0; i < armor.length; i++) {
        image(hotbar_frame, width-100, 80+i*40);
        if (armor[i] != null) {
          image(armor[i].items.get(0).inventory_img, width-100, 80+i*40);
        }
      }
      //boolean inventory_update_needed = false;
      //for (int i = 0; i < inventory.length; i++) {
      //  //if (!(inventory[i] == null && crafting_controller.previous_inventory[i] == null || (!inventory[i].equals(crafting_controller.previous_inventory[i])))) {
      //  if  ((inventory[i] == null && crafting_controller.previous_inventory[i] != null) ||
      //      (inventory[i] != null && crafting_controller.previous_inventory[i] == null) ||
      //      ((inventory[i] != null && crafting_controller.previous_inventory[i] != null) && !(inventory[i].equals(crafting_controller.previous_inventory[i])))) {
      //    inventory_update_needed = true;
      //    break;
      //  }
      //}
      //if (inventory_update_needed) {
      //  thread("updatePlayerInventory");
      //  println(millis());
      //}
      updatePlayerInventory();
      for (int i = 0; i < crafting_controller_recipe_pointers.size(); i++) {
        image(recipe_frame, 30+i*40, 550);
        image(crafting_controller_recipe_pointers.get(i).img, 30+i*40, 550);
      }
      
      if (held_item != null) {
        //image(held_item.items.get(0).inventory_img, mouseX-held_item.items.get(0).inventory_img.width/2, mouseY-held_item.items.get(0).inventory_img.height/2);
        image(held_item.items.get(0).inventory_img, mouseX, mouseY);
        text("x"+str(held_item.items.size()), hotbar_frame.width/2+mouseX, 10+mouseY);
      } else {
        textAlign(LEFT, TOP);
        
          //for (int i = 0; i < crafting_controller.returnRecipes().size(); i++) {
          //  if (mouseX < 30+i*40 + recipe_frame.width/2 &&
          //      mouseX > 30+i*40 - recipe_frame.width/2 &&
          //      mouseY < 550 + recipe_frame.height/2 &&
          //      mouseY > 550 - recipe_frame.height/2) {
          //      crafting_controller.executeRecipe(crafting_controller.returnRecipes().get(i));
          //      return;
          //  }
          //}
        
          for (int i = 0; i < 10; i++) {
            if (mouseX < 30+i*50 + hotbar_frame.width/2 &&
                mouseX > 30+i*50 - hotbar_frame.width/2 &&
                mouseY < 30 + hotbar_frame.height/2 &&
                mouseY > 30 - hotbar_frame.height/2) {
                  if (inventory[i] != null) {
                    text(inventory[i].items.get(0).name, mouseX, mouseY);
                  }
            }
            
          }
          
          for (int i = 0; i < 20; i++) {
            for (int j = 1; j < 11; j++) {
              if (mouseX < 30+i*40 + hotbar_frame.width/2 &&
                  mouseX > 30+i*40 - hotbar_frame.width/2 &&
                  mouseY < 30+j*40 + hotbar_frame.height/2 &&
                  mouseY > 30+j*40 - hotbar_frame.height/2) {
                    if (inventory[i+j*20-10] != null) {
                      text(inventory[i+j*20-10].items.get(0).name, mouseX, mouseY);
                    }
            }
          }
        }
        
        
        for (int i = 0; i < armor.length; i++) {
            if (mouseX < width - 100 + hotbar_frame.width/2 &&
                mouseX > width - 100 - hotbar_frame.width/2 &&
                mouseY < 80+i*40 + hotbar_frame.height/2 &&
                mouseY > 80+i*40 - hotbar_frame.height/2) {
                  if (armor[i] != null) {
                    text(armor[i].items.get(0).name, mouseX, mouseY);
                  }
            }
        }
            
        textAlign(CENTER);
      }
      
    }
  }
  
  public void updateInventory() {
    for (int i = 0; i < inventory.length; i++) {
      crafting_controller.previous_inventory[i] = inventory[i];
    }
    crafting_controller_recipe_pointers = crafting_controller.returnRecipes();
  }
  
  public void damage(float enemy_attack) {
    health -= constrain(enemy_attack-armor_value, 1, health);
  }
}
class RecipePointer {
  //a class with an image and a name, used to transfer information about recipies
  //between the player and the CraftingController
  PImage img;
  String name;
  RecipePointer(PImage _img, String _name) {
    img = _img;
    name = _name;
  }
}
class SandBlock extends Block {
  //a sub class of block. used instead of CustomBlock as it has an extra script.
  PImage img;
  String type;
  int y_off;
  
  SandBlock(float _x, float _y, int _x_list_pos, int _y_list_pos) {
    super(_x, _y, _x_list_pos, _y_list_pos, "sand_block.png", "sand", 1, null);
    img = texture_manager.get_texture("sand_block.png");
    item = new Item(texture_manager.get_texture("sand_block.png"), "block", "sand");
    super.item = item;
    super.img = img.get();
    y_off = 0;
  }
  
  //grow grass over itself if there is not blocks above it
  public void update(ArrayList<Light> lights) {
    //super.img = img.get();
    super.update(lights);
  }
  
  public void display(ArrayList<Light> lights) {
    if (!checkBlock(x_list_pos, y_list_pos+1) || (x_list_pos > 0 && x_list_pos < blocks.length && y_list_pos > 0 && y_list_pos < blocks[0].length && blocks[x_list_pos][y_list_pos+1].y > super.y+20)) {
      y_off += 4;
      super.y += 4;
    } else {
      y_off = 0;
    }
    
    if (y_off == 0) {
      update(lights);
    }
    
    if (y_off >= 20) {
      y_off = 0;
      blocks[x_list_pos][y_list_pos+1] = new SandBlock(super.x, super.y, super.x_list_pos, super.y_list_pos+1);
      blocks[x_list_pos][y_list_pos] = null;
      update(lights);
    }
    
    super.display(lights);
  }
  
  public boolean checkBlock(int x_pos, int y_pos) {
    return (x_pos > 0 && x_pos < blocks.length && y_pos > 0 && y_pos < blocks[0].length && (blocks[x_pos][y_pos] != null));
  }
}
class SandWraith extends Enemy {
  boolean movingDown, movingUp;
  
  SandWraith(float temp_x, float temp_y) {
    super(temp_x, temp_y, "sand wraith", "sand_wraith.png", 70, null);
    attack = 30;
    health = 50;
    max_health = 50;
    speed = 4;
    attack_cooldown = 0;
  }
  
  public void update(Player _player) {
    health_check();
    game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 3, 100, "sand_wraith_bullet.png", 2, 0, true));
    move();
    display();
  }
  
  public void move() {
    if (player.x < location.x) {
      movingLeft = true;
      movingRight = false;
    } else {
      movingLeft = false;
      movingRight = true;
    }
    
    if (player.y < location.y) {
      movingDown = true;
      movingUp = false;
    } else {
      movingDown = false;
      movingUp = true;
    }
    
    if (movingLeft) {
      location.x -= speed;
    } else if (movingRight) {
      location.x += speed;
    }
    
    if (movingUp) {
      location.y += speed;
    } else if (movingDown) {
      location.y -= speed;
    }
  }
}
class ShearBackBeetle extends Enemy {
  ShearBackBeetle(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "shear back beetle", "shear_back_beetle.png", 50, temp_blocks);
    attack = 7;
    health = 50;
    max_health = 50;
    speed = 4;
    attack_cooldown = 30;
  }
  
  public void update(Player player) {
    //game.enemy_bullets.add(new EnemyBullet(super.location.x, super.location.y, 5, 100, "dark_wizard_bullet.png", 0, 0, true));
    super.update(player);
  }
}
class Skeleton extends Enemy {
  Skeleton(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "skeleton", "skeleton.png", 50, temp_blocks);
    attack = 2;
    health = 15;
    max_health = 15;
    speed = 2;
    attack_cooldown = 50;
  }
  
  public void update(Player player) {
    super.update(player);
  }
}
class SkeletonKnight extends Enemy {
  SkeletonKnight(float temp_x, float temp_y, Block[][] temp_blocks) {
    super(temp_x, temp_y, "skeleton knight", "skeleton_knight.png", 50, temp_blocks);
    attack = 8;
    health = 50;
    max_health = 50;
    speed = 2;
    attack_cooldown = 50;
  }
  
  public void update(Player player) {
    super.update(player);
  }
}
class TextureManager {
  ArrayList<String> names;
  ArrayList<PImage> textures;
  
  TextureManager() {
    names = new ArrayList<String>();
    textures = new ArrayList<PImage>();
    loadTextures();
  }
  
  public void loadTextures() {
    //animations
    names.add("animations/block_breaking_1.png");
    names.add("animations/block_breaking_2.png");
    names.add("animations/block_breaking_3.png");
    names.add("animations/block_breaking_4.png");
    names.add("animations/cyclops_death.png");
    
    //armor
    names.add("armor/copper_armor.png");
    names.add("armor/bronze_armor.png");
    names.add("armor/iron_armor.png");
    names.add("armor/steel_armor.png");
    names.add("armor/copper_armor_left.png");
    names.add("armor/bronze_armor_left.png");
    names.add("armor/iron_armor_left.png");
    names.add("armor/steel_armor_left.png");
    
    //background_walls
    names.add("background_walls/basalt_bw.png");
    names.add("background_walls/dirt_bw.png");
    names.add("background_walls/dried_lava_bw.png");
    names.add("background_walls/granite_bw.png");
    names.add("background_walls/sand_bw.png");
    names.add("background_walls/stone_bw.png");
    names.add("background_walls/stoney_bw.png");
    
    //backgrounds
    names.add("backgrounds/main_menu.png");
    names.add("backgrounds/background_1.png");
    names.add("backgrounds/background_2.png");
    names.add("backgrounds/background_3.png");
    names.add("backgrounds/background_4.png");
    names.add("backgrounds/forest_background.png");
    names.add("backgrounds/cave_background.png");
    names.add("backgrounds/desert_background.png");
    names.add("backgrounds/wasteland_background.png");
    
    //blocks
    names.add("blocks/alloy_smelter.png");
    names.add("blocks/altar.png");
    names.add("blocks/altar_lit.png");
    names.add("blocks/amethyst_ore.png");
    names.add("blocks/basalt_block.png");
    names.add("blocks/cactus_h.png");
    names.add("blocks/cactus_v.png");
    names.add("blocks/campfire.png");
    names.add("blocks/coal_ore.png");
    names.add("blocks/copper_ore.png");
    names.add("blocks/crafting_bench.png");
    names.add("blocks/dirt_block.png");
    names.add("blocks/dirt_block_top.png");
    names.add("blocks/dried_lava_block.png");
    names.add("blocks/enchanted_wood.png");
    names.add("blocks/furnace.png");
    names.add("blocks/granite_block.png");
    names.add("blocks/iron_ore.png");
    names.add("blocks/lava_block.png");
    names.add("blocks/leaf_block.png");
    names.add("blocks/potassium_ore.png");
    names.add("blocks/primary_leaf_block_left.png");
    names.add("blocks/primary_leaf_block_right.png");
    names.add("blocks/primary_leaf_block_top.png");
    names.add("blocks/quartz_ore.png");
    names.add("blocks/ruby_ore.png");
    names.add("blocks/sand_block.png");
    names.add("blocks/sapphire_ore.png");
    names.add("blocks/stone_block.png");
    names.add("blocks/stoney_block.png");
    names.add("blocks/stone_brick.png");
    names.add("blocks/thorium_ore.png");
    names.add("blocks/tin_ore.png");
    names.add("blocks/tool_station.png");
    names.add("blocks/topaz_ore.png");
    names.add("blocks/torch.png");
    names.add("blocks/wood.png");
    names.add("blocks/wood_block.png");
    
    //bullets
    names.add("bullets/angry_cactus_bullet.png");
    names.add("bullets/dark_wizard_bullet.png");
    names.add("bullets/forest_wizard_bullet.png");
    names.add("bullets/living_bomb_bullet.png");
    names.add("bullets/cyclops_bullet.png");
    names.add("bullets/cyclops_tower_bullet.png");
    names.add("bullets/sand_wraith_bullet.png");
    
    //items
    names.add("items/amethyst.png");
    names.add("items/bronze_ingot.png");
    names.add("items/celestial_stone.png");
    names.add("items/coal.png");
    names.add("items/copper_ingot.png");
    names.add("items/iron_ingot.png");
    names.add("items/potassium.png");
    names.add("items/quartz.png");
    names.add("items/ruby.png");
    names.add("items/sapphire.png");
    names.add("items/steel_ingot.png");
    names.add("items/tin_ingot.png");
    names.add("items/topaz.png");
    
    //sprites (gabling, gobloid, orn)
    names.add("sprites/angry_cactus.png");
    names.add("sprites/cyclops.png");
    names.add("sprites/forest_wizard.png");
    names.add("sprites/cyclops_tower.png");
    names.add("sprites/goblin.png");
    names.add("sprites/living_bomb.png");
    names.add("sprites/living_boulder.png");
    names.add("sprites/orc.png");
    names.add("sprites/necromancer.png");
    names.add("sprites/phantom_left.png");
    names.add("sprites/phantom_right.png");
    names.add("sprites/player_left.png");
    names.add("sprites/player_left_left_step_1.png");
    names.add("sprites/player_left_left_step_2.png");
    names.add("sprites/player_left_right_step_1.png");
    names.add("sprites/player_left_right_step_2.png");
    names.add("sprites/player_right_left_step_1.png");
    names.add("sprites/player_right_left_step_2.png");
    names.add("sprites/player_right_right_step_1.png");
    names.add("sprites/player_right_right_step_2.png");
    names.add("sprites/player_right.png");
    names.add("sprites/sand_wraith.png");
    names.add("sprites/shear_back_beetle.png");
    names.add("sprites/skeleton.png");
    names.add("sprites/skeleton_knight.png");
    
    //tools
    names.add("tools/bronze_picaxe.png");
    names.add("tools/bronze_sword.png");
    names.add("tools/copper_picaxe.png");
    names.add("tools/copper_sword.png");
    names.add("tools/iron_picaxe.png");
    names.add("tools/iron_sword.png");
    names.add("tools/steel_picaxe.png");
    names.add("tools/steel_sword.png");
    names.add("tools/stone_picaxe.png");
    names.add("tools/stone_sword.png");
    names.add("tools/wooden_picaxe.png");
    names.add("tools/wooden_sword.png");
    
    //ui
    names.add("ui/button_continue.png");
    names.add("ui/button_continue_hovered.png");
    names.add("ui/button_new_game.png");
    names.add("ui/button_new_game_hovered.png");
    names.add("ui/button_exit.png");
    names.add("ui/button_exit_hovered.png");
    names.add("ui/hotbar.png");
    names.add("ui/hotbar_selected.png");
    names.add("ui/loading_bar.png");
    names.add("ui/recipe_frame.png");
    
    for (String name : names) {
      textures.add(loadImage(name));
    }
  }
    
  public PImage get_texture(String texture_name) {
    for (int i = 0; i < names.size(); i++) {
      if (splitString(names.get(i)).equals(texture_name)) {
        return textures.get(i);
      }
      //println(splitString(names.get(i)));
    }
    println("No texture called " + texture_name);
    return null;
  }
  
  public String splitString(String name) {
    String f_name = "error";
    for (int i = 0; i < name.length(); i++) {
      if (name.charAt(i) == '/') {
        f_name = name.substring(i+1);
        break;
      }
    }
    return f_name;
  }
}
  public void settings() {  size(960, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "eox_0_10_22" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
