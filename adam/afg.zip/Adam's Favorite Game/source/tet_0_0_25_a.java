import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.*; 
import java.util.Map; 
import java.util.Arrays; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class tet_0_0_25_a extends PApplet {






Game game;
TextureManager texture_manager;
public void setup() {
  
  game = new Game();
  surface.setTitle(get_surface_name());
}

public void draw() {
  try {
    game.update();
  } catch (Exception e) {
    try {
      PrintStream ps = new PrintStream(sketchPath()+"\\data\\log.txt");
      e.printStackTrace(ps);
      launch(sketchPath()+"\\data\\error.vbs");
    } catch (FileNotFoundException not_gonna_happen) {
      println("file not found");
    }
    exit();
  }
  //game.update();
}

public void keyPressed() {
  game.keyPressed();
}

public void keyReleased() {
  game.keyReleased();
}

public void keyTyped() {
  game.keyTyped();
}

public void mouseClicked() {
  game.mouseClicked();
}

public PImage gt(String name) {
  return texture_manager.get_texture(name);
}

public PApplet get_papplet() {
  return this;
}

public String get_surface_name() {
  return "Adam's Favorite Game";
}
class Animation {
  ArrayList<String> imgs;
  float tick_millis, last_millis;
  int phase;
  boolean stopped;
  
  Animation(ArrayList<String> _imgs, float _tick_millis) {
    imgs = _imgs;
    tick_millis = _tick_millis;
    last_millis = millis();
    phase = 0;
    stopped = false;
  }
  
  public PImage ci() {
    if (!stopped) {
      while (millis() - tick_millis > last_millis) {
        last_millis += tick_millis;
        phase++;
        if (phase >= imgs.size()) {
          phase = 0;
        }
      }
    }
    return gt(imgs.get(phase));
  }
}

class FlowingAnimation {
  String name;
  float tick_millis, last_millis;
  int phase;
  FlowingAnimation(String _name, float _tick_millis){
    name = _name;
    tick_millis = _tick_millis;
    phase = 0;
  }
  
  public PImage ci() {
    while (millis() - tick_millis > last_millis) {
      last_millis += tick_millis;
      phase++;
      if (phase >= 30) {
        phase = 0;
      }
    }
      
    return get_img();
  }
  
  public PImage get_img() {
    PImage img = createImage(30, 30, ARGB);
    PImage main_img = gt(name);
    main_img.loadPixels();
    img.loadPixels();
    for (int i = 0; i < img.pixels.length; i++) {
      img.pixels[i] = main_img.pixels[i+30*phase];
    }
    main_img.updatePixels();
    img.updatePixels();
    
    return img;
  }
}
class Block implements Cloneable {
  PVector location, block_size, first_moving_location, second_moving_location, movement_axis, movement_constraint_min, movement_constraint_max;
  boolean collidable, must_update, is_img, visible, moving_to_second;
  String img_name;
  int rectColor;
  int[] block_rounding;
  PVector[] vertices;
  //float power, full_cooldown; //for spring block, shooter block
  JSONObject properties;
  
  Block() {
    must_update = false;
    visible = true;
    properties = parseJSONObject("{\"power\": 30, \"full_cooldown\": 120, \"cooldown\": 0, \"cactus_transition\": 0}");
    //block_rounding = getBlockRounding();
  }
  
  public void update() {
    move();
  }
  
  public void display() {
    if (!visible) {
      return;
    }
    if (is_img) {
      image(gt(img_name), location.x, location.y);
    } else {
      if (block_rounding == null) {
        block_rounding = getBlockRounding();
      }
      fill(rectColor);
      rect(location.x, location.y, block_size.x, block_size.y, block_rounding[0], block_rounding[1], block_rounding[2], block_rounding[3]);
    }
  }
  
  public void onCollide() {}
  
  public boolean onEnemyCollide(Enemy enemy) {
    return true;
  }
  
  public void setMoving(float x1, float y1, float x2, float y2, float moving_speed) {
    first_moving_location = new PVector(x1, y1);
    second_moving_location = new PVector(x2, y2);
    must_update = true;
    moving_to_second = true;
    movement_axis = (new PVector(x2-x1, y2-y1)).setMag(moving_speed);
    movement_constraint_min = new PVector(min(first_moving_location.x, second_moving_location.x), min(first_moving_location.y, second_moving_location.y));
    movement_constraint_max = new PVector(max(first_moving_location.x, second_moving_location.x), max(first_moving_location.y, second_moving_location.y));
  }
  
  public void move() {
    if (movement_axis != null) {
      //PVector plocation = new PVector(location.x, location.y);
      if (moving_to_second) {
        location.add(movement_axis);
      } else {
        location.sub(movement_axis);
      }
      
      if (location.x != constrain(location.x, movement_constraint_min.x, movement_constraint_max.x) || location.y != constrain(location.y, movement_constraint_min.y, movement_constraint_max.y)) {
        moving_to_second = !moving_to_second;
        location.x = constrain(location.x, movement_constraint_min.x, movement_constraint_max.x);
        location.y = constrain(location.y, movement_constraint_min.y, movement_constraint_max.y);
      }
      
      simulatePlayerMove();
      if (game.player.last_moved_by_block != frameCount && getPlayerCollision()) {
        onCollide();
        //game.player.location.add(new PVector(location.x-plocation.x, location.y-plocation.y));
        if (moving_to_second) {
          game.player.location.add(movement_axis);
        } else {
          game.player.location.sub(movement_axis);
        }
        
        //println(location.x-plocation.x, location.y-plocation.y);
        //game.player.location.add((new PVector(movement_axis.x, movement_axis.y)).setMag(movement_axis.mag()*1.5));
        game.player.last_moved_by_block = frameCount;
        //println(millis()+" "+getPlayerCollision());
        
        //fill(0);
        //text(location.y-plocation.y, location.x, location.y+50);
        //text(movement_axis.y, location.x, location.y+100);
        
        //println(game.player.location.y);
      }
      unsimulatePlayerMove();
      
    }
  }
  
  public int[] getBlockRounding() {
    int[] rounding = {10, 10, 10, 10}; //tl, tr, br, bl
    
    int x = round(location.x/30);
    int y = round(location.y/30);
    
    if (game.blocks.get(new PVector(x, y-1)) != null && game.blocks.get(new PVector(x, y-1)) != this && game.blocks.get(new PVector(x, y-1)).visible==this.visible) { //top
      rounding[0] = 0;
      rounding[1] = 0;
    }
    if (game.blocks.get(new PVector(x, y+1)) != null && game.blocks.get(new PVector(x, y+1)) != this && game.blocks.get(new PVector(x, y+1)).visible==this.visible) { //bottom
      rounding[2] = 0;
      rounding[3] = 0;
    }
    if (game.blocks.get(new PVector(x-1, y)) != null && game.blocks.get(new PVector(x-1, y)) != this && game.blocks.get(new PVector(x-1, y)).visible==this.visible) { //left
      rounding[0] = 0;
      rounding[3] = 0;
    }
    if (game.blocks.get(new PVector(x+1, y)) != null && game.blocks.get(new PVector(x+1, y)) != this && game.blocks.get(new PVector(x+1, y)).visible==this.visible) { //right
      rounding[1] = 0;
      rounding[2] = 0;
    }
    return rounding;
  }
  
  public void simulatePlayerMove() {
    float total_x_offset = 0;
    if (game.player.a_pressed) {
      total_x_offset -= game.player.x_speed;
    }
    if (game.player.d_pressed) {
      total_x_offset += game.player.x_speed;
    }
    game.player.velocity.x += total_x_offset;
    game.player.location.y += game.player.velocity.y*game.dt+game.player.g;
  }
  
  public void unsimulatePlayerMove() {
    float total_x_offset = 0;
    if (game.player.a_pressed) {
      total_x_offset -= game.player.x_speed;
    }
    if (game.player.d_pressed) {
      total_x_offset += game.player.x_speed;
    }
    game.player.velocity.x -= total_x_offset;
    game.player.location.y -= game.player.velocity.y*game.dt+game.player.g;
  }
  
  public boolean getPlayerCollision() {
    return CollisionDetector.rectRect(game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y, location.x, location.y, block_size.x, block_size.y);
  }
  
  public boolean getSimulatedPlayerCollision() {
    simulatePlayerMove();
    boolean collision = getPlayerCollision();
    unsimulatePlayerMove();
    return collision;
  }
  
  public void setVertices() {
    vertices = new PVector[4];
    vertices[0] = new PVector(-block_size.x/2, -block_size.y/2);
    vertices[1] = new PVector(block_size.x/2, -block_size.y/2);
    vertices[2] = new PVector(block_size.x/2, block_size.y/2);
    vertices[3] = new PVector(-block_size.x/2, block_size.y/2);
  }
  
  public boolean getPlayerSideCollision() {
    return getOutsideCollision(game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y);
  }
  
  public boolean getOutsideCollision(float x, float y, float w, float h) {
    if (vertices == null) {
      setVertices();
    }
    
    PVector[] new_vertices = new PVector[vertices.length];
    for (int i = 0; i < new_vertices.length; i++) {
      new_vertices[i] = new PVector(location.x+vertices[i].x, location.y+vertices[i].y);
    }
    return CollisionDetector.polyRect(new_vertices, x, y, w-2, h-2);
  }
  
  public Block clone() {
    try {
      return (Block) super.clone();
    } catch (CloneNotSupportedException e) {
      println("Block clone not supported");
      exit();
    }
    return null;
  }
}

class NormalBlock extends Block {
  NormalBlock(float x, float y, String _img_name) {
    location = new PVector(x, y);
    img_name = _img_name;
    block_size = new PVector(gt(img_name).width, gt(img_name).height);
    is_img = true;
    collidable = true;
    //super.init();
  }
  
  NormalBlock(float x, float y, int _color, float w, float h) {
    location = new PVector(x, y);
    rectColor = _color;
    block_size = new PVector(w, h);
    is_img = false;
    collidable = true;
    //super.init();
  }
  
  NormalBlock(float x, float y) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = true;
    //super.init();
  }
  
  public void update() {
    super.update();
    display();
  }
}

class DisappearingBlock extends Block {
  DisappearingBlock(float x, float y) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = true;
    //super.init();
  }
  
  public void update() {
    super.update();
    //if (true && getSimulatedPlayerCollision()) {
    //  visible = false;
    //}
    display();
  }
  
  public void onCollide() {
    visible = false;
  }
}

class AppearingBlock extends Block {
  //boolean hidden;
  AppearingBlock(float x, float y) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = true;
    visible = false;
    //super.init();
  }
  
  public void update() {
    super.update();
    display();
  }
  
  public void onCollide() {
    visible = true;
    PVector[] coords = {new PVector(location.x/30-1, location.y/30), new PVector(location.x/30+1, location.y/30), new PVector(location.x/30, location.y/30-1), new PVector(location.x/30, location.y/30+1)};
    for (PVector coord : coords) {
      Block block = game.blocks.get(coord.copy());
      if (block != null) {
        block.block_rounding = null;
      }
    }
  }
}

class SpikeBlock extends Block {
  String direction;
  SpikeBlock(float x, float y, String _direction) {
    location = new PVector(x, y);
    direction = _direction;
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
  }
  
  public void update() {
    super.update();
    display();
  }
  
  public void onCollide() {
    visible = true;
    game.player.die("spike");
  }
  
  public void display() {
    if (!visible) {
      return;
    }
    fill(0);
    if (direction.equals("up") || direction.equals("w")) {
      triangle(location.x-block_size.x/2, location.y+block_size.y/2, location.x+block_size.x/2, location.y+block_size.y/2, location.x, location.y-block_size.y/2);
    } else if (direction.equals("down") || direction.equals("s")) {
      triangle(location.x-block_size.x/2, location.y-block_size.y/2, location.x+block_size.x/2, location.y-block_size.y/2, location.x, location.y+block_size.y/2);
    } else if (direction.equals("left") || direction.equals("a")) {
      triangle(location.x+block_size.x/2, location.y-block_size.y/2, location.x+block_size.x/2, location.y+block_size.y/2, location.x-block_size.x/2, location.y);
    } else if (direction.equals("right") || direction.equals("d")) {
      triangle(location.x-block_size.x/2, location.y-block_size.y/2, location.x-block_size.x/2, location.y+block_size.y/2, location.x+block_size.x/2, location.y);
    }
    
    //if (vertices == null) {
    //  setVertices();
    //}
    //fill(255, 0, 0);
    //pushMatrix();
    //translate(location.x, location.y);
    //stroke(255, 0, 0);
    //line(vertices[0].x, vertices[0].y, vertices[1].x, vertices[1].y);
    //line(vertices[0].x, vertices[0].y, vertices[2].x, vertices[2].y);
    //line(vertices[2].x, vertices[2].y, vertices[1].x, vertices[1].y);
    //popMatrix();
    //noStroke();
  }
  
  public void setVertices() {
    vertices = new PVector[3];
    
    block_size.mult(0.8f);
    if (direction.equals("up") || direction.equals("w")) {
      vertices[0] = new PVector(-block_size.x/2, block_size.y/2);
      vertices[1] = new PVector(block_size.x/2, block_size.y/2);
      vertices[2] = new PVector(0, -block_size.y/2);
    } else if (direction.equals("down") || direction.equals("s")) {
      vertices[0] = new PVector(-block_size.x/2, -block_size.y/2);
      vertices[1] = new PVector(+block_size.x/2, -block_size.y/2);
      vertices[2] = new PVector(0, block_size.y/2);
    } else if (direction.equals("left") || direction.equals("a")) {
      vertices[0] = new PVector(block_size.x/2, -block_size.y/2);
      vertices[1] = new PVector(block_size.x/2, block_size.y/2);
      vertices[2] = new PVector(-block_size.x/2, 0);
    } else if (direction.equals("right") || direction.equals("d")) {
      vertices[0] = new PVector(-block_size.x/2, -block_size.y/2);
      vertices[1] = new PVector(-block_size.x/2, +block_size.y/2);
      vertices[2] = new PVector(block_size.x/2, 0);
    }
    block_size.div(0.8f);
  }
}

class SpringBlock extends Block {
  String direction;
  float rotation;
  SpringBlock(float x, float y, String _direction, float _power) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = true;
    collidable = true;
    direction = _direction;
    properties.setFloat("power", _power);
    img_name = "spring.png";
    //super.init();
    rotation = get_rotation(direction);
  }
  
  public void update() {
    super.update();
    boolean collided = false;
    if (direction.equals("up") || direction.equals("t")) {
      if (CollisionDetector.rectRect(game.player.location.x, game.player.location.y, game.player.rectSize.x-2, game.player.rectSize.y-2, location.x, location.y-block_size.y/2-5, block_size.x, 10)) {
        game.player.velocity.y = -properties.getFloat("power");
        collided = true;
      }
    }
    if (direction.equals("left") || direction.equals("r")) {
      if (CollisionDetector.rectRect(game.player.location.x, game.player.location.y, game.player.rectSize.x-2, game.player.rectSize.y-2, location.x-block_size.x/2-6, location.y, 12, block_size.y)) {
        game.player.velocity.x = -properties.getFloat("power")*2;
        collided = true;
      }
    }
    if (direction.equals("right") || direction.equals("y")) {
      if (CollisionDetector.rectRect(game.player.location.x, game.player.location.y, game.player.rectSize.x-2, game.player.rectSize.y-2, location.x+block_size.x/2+6, location.y, 12, block_size.y)) {
        game.player.velocity.x = properties.getFloat("power")*2;
        collided = true;
      }
    }
    if (collided) {
      visible = true;
      game.sound_engine.gs("spring2").play();
    }
    display();
  }
  
  public boolean onEnemyCollide(Enemy enemy) {
    //enemy.is_dead = true;
    if (direction.equals("up") || direction.equals("t")) {
      enemy.velocity.y = -properties.getFloat("power");
      game.sound_engine.gs("spring2").play();
    } else if (direction.equals("left") || direction.equals("r")) {
      enemy.velocity.x = -properties.getFloat("power")*2;
      game.sound_engine.gs("spring2").play();
    } else if (direction.equals("right") || direction.equals("y")) {
      enemy.velocity.x = properties.getFloat("power")*2;
      game.sound_engine.gs("spring2").play();
    }
    return false;
  }
  
  public void display() {
    if (!visible) {
      return;
    }
    pushMatrix();
    translate(location.x, location.y);
    rotate(rotation);
    image(gt(img_name), 0, 0);
    popMatrix();
  }
  
  public float get_rotation(String rotation) {
    if (rotation.equals("up") || rotation.equals("t")) {
      return PI;
    } else if (rotation.equals("left") || rotation.equals("r")) {
      return PI/2;
    } else if (rotation.equals("down") || rotation.equals("y")) {
      return -PI/2;
    }
    return 0;
  }
}

class ShooterBlock extends Block {
  String direction;
  float bullet_speed, rotation;
  
  ShooterBlock(float x, float y, String _direction) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = true;
    collidable = true;
    direction = _direction;
    properties.setFloat("full_cooldown", 120);
    properties.setFloat("cooldown", properties.getFloat("full_cooldown"));
    bullet_speed = 15;
    //super.init();
    rotation = get_rotation(direction);
    img_name = "shooter.png";
  }
  
  ShooterBlock(float x, float y, String _direction, float _cooldown) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = true;
    collidable = true;
    direction = _direction;
    properties.setFloat("full_cooldown", _cooldown);
    properties.setFloat("cooldown", properties.getFloat("full_cooldown"));
    bullet_speed = 15;
    //super.init();
    rotation = get_rotation(direction);
    img_name = "shooter.png";
  }
  
  public void update() {
    super.update();
    properties.setFloat("cooldown", properties.getFloat("cooldown")-game.dt);
    if (properties.getFloat("cooldown") <= 0) {
      properties.setFloat("cooldown", properties.getFloat("full_cooldown"));
      shoot();
    }
    display();
  }
  
  public void shoot() {
    if (direction.equals("down") || direction.equals("S")) {
      game.bullets.add(new Arrow(location.x, location.y, 0, bullet_speed, direction));
    } else if (direction.equals("up") || direction.equals("W")) {
      game.bullets.add(new Arrow(location.x, location.y, 0, -bullet_speed, direction));
    } else if (direction.equals("left") || direction.equals("A")) {
      game.bullets.add(new Arrow(location.x, location.y, -bullet_speed, 0, direction));
    } else {
      game.bullets.add(new Arrow(location.x, location.y, bullet_speed, 0, direction));
    }
  }
  
  public void display() {
    if (!visible) {
      return;
    }
    pushMatrix();
    translate(location.x, location.y);
    rotate(rotation);
    image(gt(img_name), 0, 0);
    popMatrix();
  }
  
  public void onCollide() {
    visible = true;
  }
  
  public float get_rotation(String rotation) {
    if (rotation.equals("up") || rotation.equals("W")) {
      return PI;
    } else if (rotation.equals("left") || rotation.equals("A")) {
      return PI/2;
    } else if (rotation.equals("down") || rotation.equals("S")) {
      return 0;
    }
    return PI*3/2;
  }
}

class PistonBlock extends Block {
  boolean inverted;
  PistonBlock(float x, float y, float _interval, boolean _inverted) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = !_inverted;
    visible = true;
    properties.setFloat("full_cooldown", _interval);
    properties.setFloat("cooldown", _interval);
    inverted = _inverted;
    must_update = true;
  }
  
  public void update() {
    super.update();
    
    if (properties.getFloat("cooldown") <= 0) {
      collidable = !collidable;
      visible = !visible;
      properties.setFloat("cooldown", properties.getFloat("full_cooldown"));
    } else {
      properties.setFloat("cooldown", properties.getFloat("cooldown")-game.dt);
    }
    
    display();
  }
}

class DodgingBlock extends Block {
  boolean recurrent, proximity, moving;
  PVector original_location;
  DodgingBlock(float x, float y, boolean _recurrent, boolean _proximity) {
    location = new PVector(x, y);
    original_location = new PVector(x, y);
    recurrent = _recurrent;
    proximity = _proximity;
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    moving = false;
    collidable = false;
    //super.init();
  }
  
  public void update() {
    super.update();
    simulatePlayerMove();
    if ((proximity && dist(location.x, location.y, game.player.location.x, game.player.location.y) <= 150 && game.player.velocity.y < 0 && abs(game.player.location.x-location.x)>abs(game.player.location.x+game.player.velocity.x-location.x)) || CollisionDetector.rectRect(game.player.location.x, game.player.location.y, game.player.rectSize.x-2, game.player.rectSize.y-2, location.x, location.y, block_size.x-2, block_size.y-2)) {
      location.y = game.player.location.y-game.player.rectSize.y/2-block_size.y/2;
      if (proximity && location.y > original_location.y) {
        location.y = original_location.y;
      }
      if (!recurrent && proximity && original_location.y > location.y) {
        original_location.y = location.y;
      }
      moving = true;
    } else if (recurrent && moving) {
      if (location.y >= original_location.y) {
        location.y = original_location.y;
        moving = false;
      } else {
        location.y = game.player.location.y-game.player.rectSize.y/2-block_size.y/2;
      }
    } else if (!recurrent && moving) {
      float offset = 30;
      location.y = constrain(location.y-game.player.g, ceil((location.y-game.player.g)/30)*30-offset, ceil((location.y-game.player.g)/30)*30-offset);
      if (ceil(location.y/30)*30 == PApplet.parseInt(location.y/30)*30) {
        moving = false;
      }
      if (proximity) {
        original_location.y = round(original_location.y/30)*30;
        location.y = original_location.y;
      }
    }
    unsimulatePlayerMove();
    display();
    //fill(0);
    //text(round(location.y), location.x, location.y);
  }
}

class TeleportBlock extends Block {
  PVector destination;
  boolean keep_x;
  TeleportBlock(float x, float y, float dest_x, float dest_y) {
    location = new PVector(x, y);
    destination = new PVector(dest_x, dest_y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = false;
    keep_x = false;
  }
  
  TeleportBlock(float x, float y, float dest_x, float dest_y, boolean _keep_x) {
    location = new PVector(x, y);
    destination = new PVector(dest_x, dest_y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = false;
    keep_x = _keep_x;
  }
  
  //void update() {
  //  super.update();
  //  display();
  //}
  
  public void onCollide() {
    if (!keep_x) {
      game.player.location.x = destination.x;
    }
    game.player.location.y = destination.y+17;//+block_size.y/2-game.player.rectSize.y/2;
  }
  
  //void display() {
  //  noFill();
  //  stroke(0, 0, 255);
  //  rect(location.x, location.y, block_size.x-3, block_size.y-3);
  //  noStroke();
  //}
}

class SignTriggerBlock extends Block {
  float block_id, sign_id;
  boolean triggered;
  //SignTriggerBlock(float x, float y, float _block_id, float _sign_id) {
  SignTriggerBlock(float x, float y, float _sign_id) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = false;
    triggered = false;
    block_id = random(-1000000000, 1000000000);
    sign_id = _sign_id;
  }
  
  SignTriggerBlock(float x, float y, float x_size, float y_size, float _sign_id) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(x_size, y_size);
    is_img = false;
    collidable = false;
    visible = false;
    triggered = false;
    block_id = random(-1000000000, 1000000000);
    sign_id = _sign_id;
  }
  
  public void update() {
    super.update();
    display();
  }
  
  public void onCollide() {
    triggered = true;
    for (Entity entity : game.entities) {
      if (sign_id == entity.id && block_id != entity.properties.getFloat("block_id")) {
        entity.properties.setInt("msg_index", entity.properties.getInt("msg_index")+1);
        entity.properties.setFloat("block_id", block_id);
      }
    }
  }
  
  public void display() {
    //noFill();
    //stroke(0, 0, 255);
    //rect(location.x, location.y, block_size.x-3, block_size.y-3);
    //noStroke();
  }
}

class EnemySpawnBlock extends Block {
  boolean triggered;
  ArrayList<Enemy> enemy_list;
  
  EnemySpawnBlock(float x, float y, ArrayList<Enemy> _enemy_list) {
    location = new PVector(x, y);
    enemy_list = _enemy_list;
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = false;
    triggered = false;
  }
  
  EnemySpawnBlock(float x, float y, int x_size, int y_size, ArrayList<Enemy> _enemy_list) {
    location = new PVector(x, y);
    enemy_list = _enemy_list;
    rectColor = color(255, 127, 39);
    block_size = new PVector(x_size, y_size);
    is_img = false;
    collidable = false;
    visible = false;
    triggered = false;
  }
  
  public void onCollide() {
    if (!triggered) {
      triggered = true;
      for (int i = 0; i < enemy_list.size(); i++) {
        game.enemies.add(enemy_list.get(i));
      }
    }
  }
}

class TextBlock extends Block {
  boolean triggered;
  Text text;
  TextBlock(float x, float y, Text _text) {
    location = new PVector(x, y);
    text = _text;
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = false;
    triggered = false;
  }
  
  public void onCollide() {
    if (!triggered) {
      triggered = true;
      game.ui_text.add(text);
    }
  }
}

class GameCrashBlock extends Block {
  boolean triggered;
  GameCrashBlock(float x, float y) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = false;
    triggered = false;
  }
  
  public void onCollide() {
    if (!triggered) {
      triggered = true;
      game.state = "crash";
    }
  }
}

class BarrelBlock extends Block {
  boolean triggered;
  BarrelBlock(float x, float y) {
    location = new PVector(x, y+1);
    img_name = "barrel.png";
    block_size = new PVector(30, 30);
    is_img = true;
    collidable = false;
    visible = true;
    triggered = false;
  }
  
  public void update() {
    super.update();
    display();
  }
  
  public void onCollide() {
    if (!triggered) {
      visible = false;
      game.player.has_fuel = true;
      triggered = true;
    }
  }
}

class CactusBlock extends Block {
  //float transition_counter;
  CactusBlock(float x, float y) {
    location = new PVector(x, y+1);
    img_name = "cactus.png";
    block_size = new PVector(30, 30);
    is_img = true;
    collidable = false;
    visible = true;
    //transition_counter = 0;
  }
  
  public void update() {
    super.update();
    if (properties.getFloat("cactus_transition") == constrain(properties.getFloat("cactus_transition"), 1, 255)) {
      //transition_counter += 3*game.dt;
      properties.setFloat("cactus_transition", properties.getFloat("cactus_transition")+3*game.dt);
    }
    display();
  }
  
  public void display() {
    tint(255, properties.getFloat("cactus_transition"));
    image(gt("cactus.png"), location.x, location.y);
    tint(255, 255-properties.getFloat("cactus_transition"));
    image(gt("barrel.png"), location.x, location.y);
    noTint();
  }
}

class PlaceBarrelBlock extends Block {
  PVector put_location;
  PlaceBarrelBlock(float x, float y, float w, float h, float bx, float by) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(w, h);
    put_location = new PVector(bx, by);
    is_img = false;
    collidable = false;
    visible = false;
  }
  
  public void update() {
    super.update();
    display();
  }
  
  public void onCollide() {
    if (game.player.has_fuel) {
      int x = (int)put_location.x;
      int y = (int)put_location.y;
      game.fbcs.add(new FillBlockCommand(x, y, x, y, new CactusBlock(0, 0)));
      game.player.has_fuel = false;
    }
  }
}

class EnemyCommandBlock extends Block {
  boolean triggered;
  JSONObject command;
  EnemyCommandBlock(float x, float y, JSONObject _command) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = false;
    visible = false;
    triggered = false;
    command = _command;
  }
  
  public void onCollide() {
    if (!triggered) {
      JSONObject data = command.getJSONObject("data");
      if (command.getString("type").equals("set_visible")) {
        for (int i = 0; i < game.enemies.size(); i++) {
          if (game.enemies.get(i).id == data.getFloat("id")) {
            game.enemies.get(i).visible = data.getBoolean("visible");
            continue;
          }
        }
      }
      triggered = true;
    }
  }
}

class PolyCollisionBlock extends Block {
  boolean triggered;
  JSONObject command;
  int ticks;
  PolyCollisionBlock(float x, float y) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = true;
    visible = true;
    triggered = false;
    ticks = 0;
  }
  
  public void update() {
    super.update();
    display();
    
    visible = true;
    if (ticks < 30) {
      ticks++;
    } else {
      visible = false;
    }
  }
  
  public void display() {
    visible = true;
    super.display();
    visible = false;
  }
}

class MSOD extends Block {
  MSOD(float x, float y) {
    location = new PVector(x, y);
    rectColor = color(255, 127, 39);
    block_size = new PVector(30, 30);
    is_img = false;
    collidable = true;
    visible = true;
  }
  
  public void onCollide() {
    if (collidable) {
      collidable = false;
      visible = false;
      for (int i = 0; i < random(5, 10); i++) {
        game.particles.add(new Particle(location.x, location.y, new PVector(random(-3, 3), random(-15, -6)), random(7, 12), random(360), random(-5, 5), 1, "triangle", 70, color(random(100)), 1, 1, true, true, 0.7f));
      }
    }
  }
}

class BlockFillBlock extends Block {
  boolean triggered, local_visible;
  Block block_type;
  int x_fill_start, y_fill_start, x_fill_end, y_fill_end;
  BlockFillBlock(float x, float y, int _x_fill_start, int _y_fill_start, int _x_fill_end, int _y_fill_end, Block _block_type) {
    location = new PVector(x, y);
    block_size = new PVector(30, 30);
    is_img = true;
    collidable = false;
    visible = false;
    local_visible = false;
    triggered = false;
    
    x_fill_start = _x_fill_start;
    y_fill_start = _y_fill_start;
    x_fill_end = _x_fill_end;
    y_fill_end = _y_fill_end;
    block_type = _block_type;
  }
  
  BlockFillBlock(float x, float y, int _x_fill_start, int _y_fill_start, int _x_fill_end, int _y_fill_end, int x_size, int y_size, Block _block_type) {
    location = new PVector(x, y);
    block_size = new PVector(x_size, y_size);
    is_img = true;
    collidable = false;
    visible = false;
    local_visible = false;
    triggered = false;
    
    x_fill_start = _x_fill_start;
    y_fill_start = _y_fill_start;
    x_fill_end = _x_fill_end;
    y_fill_end = _y_fill_end;
    block_type = _block_type;
  }
  
  public void update() {
    if (visible) {
      visible = false;
      local_visible = true;
    }
    super.update();
    display();
  }
  
  public void onCollide() {
    if (!triggered) {
      triggered = true;
      game.fbcs.add(new FillBlockCommand(x_fill_start, y_fill_start, x_fill_end, y_fill_end, block_type));
    }
  }
  
  public void display() {
    //noFill();
    //stroke(255, 0, 0);
    //rect(location.x, location.y, block_size.x, block_size.y);
    if (local_visible) {
      if (triggered) {
        image(gt("lever_on.png"), location.x, location.y);
      } else {
        image(gt("lever_off.png"), location.x, location.y);
      }
    }
  }
}

class FillBlockCommand {
  int x_fill_start, y_fill_start, x_fill_end, y_fill_end;
  Block block_type;
  
  FillBlockCommand(int _x_fill_start, int _y_fill_start, int _x_fill_end, int _y_fill_end, Block _block_type) {
    x_fill_start = _x_fill_start;
    y_fill_start = _y_fill_start;
    x_fill_end = _x_fill_end;
    y_fill_end = _y_fill_end;
    block_type = _block_type;
  }
  
  public void run() {
    for (int i = x_fill_start; i <= x_fill_end; i++) {
      for (int j = y_fill_start; j <= y_fill_end; j++) {
        //Class<?> c = Class.forName("Block");
        if (block_type != null) {
          game.blocks.put(new PVector(i, j), block_type.clone());
          game.blocks.get(new PVector(i, j)).location = new PVector(i*30, j*30);
        } else {
          game.blocks.remove(new PVector(i, j));
        }
      }
    }
  }
}
class Bullet {
  PVector location, velocity, rectSize;
  String img_name;
  boolean is_dead;
  float fuse, rotation, img_scale;
  
  public void update() {}
  
  public void display() {
    pushMatrix();
    translate(location.x, location.y);
    scale(img_scale);
    rotate(rotation);
    image(gt(img_name), 0, 0);
    popMatrix();
  }
  
  public boolean getPlayerCollision() {
    return CollisionDetector.rectRect(game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y, location.x, location.y, rectSize.x, rectSize.y);
  }
  
  public boolean getBlockCollision() {
    for (HashMap.Entry<PVector,Block> entry : game.blocks.entrySet()) {
      Block block = entry.getValue();
      if (abs(location.x-block.location.x) <= 150 && abs(location.y-block.location.y) <= 150 && block.getOutsideCollision(location.x, location.y, rectSize.x, rectSize.y)) {
        if (block.collidable) {
          return true;
        }
      }
    }
    return false;
  }
  
  public float get_rotation(String rotation) {
    if (rotation.equals("up") || rotation.equals("W")) {
      return PI;
    } else if (rotation.equals("left") || rotation.equals("A")) {
      return PI/2;
    } else if (rotation.equals("down") || rotation.equals("S")) {
      return 0;
    }
    return PI*3/2;
  }
}

class PlayerBullet extends Bullet {
  //float img_scale;
  PlayerBullet(float x, float y, float xv, float yv, float _rotation, String _img_name, float _img_scale) {
    location = new PVector(x, y);
    velocity = new PVector(xv, yv);
    rotation = _rotation;
    img_name = _img_name;
    img_scale = _img_scale;
    rectSize = new PVector(gt(img_name).width, gt(img_name).height).mult(img_scale);
  }
  
  public void update() {
    location.add(velocity);
    if (getBlockCollision()) {
      is_dead = true;
    }
    display();
  }
  
  //void display() {
  //  pushMatrix();
  //  translate(location.x, location.y);
  //  scale(img_scale);
  //  rotate(rotation);
  //  image(gt(img_name), 0, 0);
  //  popMatrix();
  //}
}

class LethalBullet extends Bullet {
  LethalBullet(float x, float y, float xv, float yv, String _img_name) {
    img_name = _img_name;
    location = new PVector(x, y);
    velocity = new PVector(xv, yv);
    rectSize = new PVector(gt(img_name).width, gt(img_name).height);
    img_scale = 1;
  }
  
  public void update() {
    if (is_dead) {
      return;
    }
    move();
    display();
  }
  
  public void move() {
    boolean init_block_collision = getBlockCollision();
    location.add(velocity);
    if (!init_block_collision && getBlockCollision()) {
      onBlockCollision();
      is_dead = true;
    }
    if (getPlayerCollision()) {
      game.player.die("bullet");
    }
    fuse -= game.dt;
    if (fuse <= 0) {
      onBlockCollision();
      is_dead = true;
    }
  }
  
  public void onBlockCollision() {}
}

class Arrow extends LethalBullet {
  Arrow(float x, float y, float xv, float yv, String rotation_str) {
    super(x, y, xv, yv, "arrow.png");
    rotation = get_rotation(rotation_str);
    fuse = 1000;
  }
  
  public void onBlockCollision() {
    for (int i = 0; i < random(5, 10); i++) {
      //game.particles.add(new Particle(location.x, location.y, new PVector(random(velocity.x-3, velocity.x+3), random(velocity.y-3, velocity.y+3)), random(7, 12)*img_scale, random(360), random(-5, 5), 1, "triangle", 70, color(185, 122, 87), 1, 1, false, false, 0));
      game.particles.add(new Particle(location.x, location.y, new PVector(random(constrain(velocity.x, -1, 1)-1, constrain(velocity.x, -1, 1)+1), random(constrain(velocity.y, -1, 1)-1, constrain(velocity.y, -1, 1)+1)), random(3, 7)*img_scale, random(360), random(-5, 5), 1, "triangle", 70, color(185, 122, 87), 1, 1, false, false, 0));
    }
  }
}

class FireBall extends LethalBullet {
  boolean explosive, affected_by_gravity;
  int theColor;
  int g_increase, g_min, g_max;
  float size;
  FireBall(float x, float y, float xv, float yv, float _size, boolean _explosive, boolean _affected_by_gravity) {
    super(x, y, xv, yv, "void.png");
    size = _size;
    rectSize = new PVector(size, size);
    explosive = _explosive;
    affected_by_gravity = _affected_by_gravity;
    fuse = 1000;
    g_increase = 5;
    g_min = 50;
    g_max = 150;
    theColor = color(255, (g_min+g_max)/2, 0);
  }
  
  public void update() {
    super.update();
  }
  
  public void move() {
    if (affected_by_gravity) {
      velocity.y += game.player.g/20;
    }
    super.move();
  }
  
  public void display() {
    theColor = color(red(theColor), green(theColor)+g_increase, blue(theColor));
    if (green(theColor) != constrain(green(theColor), g_min+1, g_max)) {
      g_increase *= -1;
      color(red(theColor), constrain(green(theColor), g_min, g_max), blue(theColor));
    }
    
    fill(theColor);
    ellipse(location.x, location.y, size, size);
    spawn_particles();
  }
  
  public void spawn_particles() {
    game.particles.add(new Particle(location.x+random(-rectSize.x/2, rectSize.x/2), location.y+random(-rectSize.y/2, rectSize.y/2), (new PVector(random(-1, 1), random(-1, 1))), 10, 0, 0, 0, "circle", 70, color(255, random(g_min, g_max), 0, 120), 0.5f, 1, false, false, 0));
  }
  
  public void onBlockCollision() {
    if (!explosive) {
      return;
    }
    for (int i = 0; i < 10; i++) {
      game.bullets.add(new FireBall(location.x-velocity.x, location.y-velocity.y, velocity.mag()*cos(radians(i*36)), velocity.mag()*sin(radians(i*36)), size*0.33f, false, true));
    }
  }
}

class GuidedMissle extends LethalBullet {
  float size, speed, guidance, particles_per_tick;
  boolean aggroed;
  GuidedMissle(float x, float y, float _guidance, float _fuse) {
    super(x, y, 0, -6, "missle.png");
    guidance = _guidance;
    //size = 10;
    speed = 6;
    rectSize = new PVector(gt(img_name).width, gt(img_name).height);
    fuse = _fuse;
    img_scale = 2;
    particles_per_tick = 3;
    aggroed = false;
  }
  
  public void move() {
    if (!aggroed && dist(location.x, location.y, game.player.location.x, game.player.location.y) < dist(0, 0, width/2, height/2)) {
      aggroed = true;
    }
    if (aggroed) {
      PVector destination = new PVector(game.player.location.x-location.x, game.player.location.y-location.y).setMag(speed*guidance);
      //velocity.lerp(destination, guidance);
      velocity.add(destination);
      rotation = velocity.heading();
      
      location.add(velocity);
      if (getPlayerCollision()) {
        game.player.die("bullet");
        explode();
        //is_dead = true;
      }
      fuse -= game.dt;
      if (fuse <= 0) {
        explode();
        is_dead = true;
      }
    }
  }
  
  public void display() {
    super.display();
    spawn_particles();
  }
  
  public void explode() {
    for (int i = 0; i < 10; i++) {
      game.bullets.add(new FireBall(location.x-velocity.x, location.y-velocity.y, 0.1f*velocity.x+5*cos(radians(i*36)), 0.1f*velocity.y+5*sin(radians(i*36)), size*0.33f, false, true));
    }
    game.sound_engine.gs("explosion").play();
  }
  
  public void spawn_particles() {
    for (int i = 0; i < particles_per_tick; i++) {
      PVector tail_location = (new PVector(-rectSize.x, 5)).rotate(rotation).add(location);
      PVector particle_speed = (new PVector(-speed/3, 0)).rotate(rotation+radians(random(-30, 30)));
      game.particles.add(new Particle(tail_location.x, tail_location.y, particle_speed, 10, 0, 0, 0, "circle", 70, color(0, 120), 0.5f, 1, false, false, 0));
    }
  }
}

class FallingDeath extends LethalBullet {
  //float img_scale, rotation_speed;
  float rotation_speed;
  FallingDeath(float x, float y, String img_name, float _img_scale) {
    super(x, y, 0, 5, img_name);
    img_scale = _img_scale;
    rectSize.mult(img_scale);
    rotation = random(TWO_PI);
    fuse = 1000;
    rotation_speed = random(5, 10)*((round(random(1))*2)-1);
  }
  
  public void update() {
    velocity.y += game.player.g*0.5f;
    rotation += radians(rotation_speed);
    super.update();
  }
  
  //void display() {
  //  pushMatrix();
  //  translate(location.x, location.y);
  //  rotate(rotation);
  //  scale(img_scale);
  //  image(gt(img_name), 0, 0);
  //  popMatrix();
  //}
  
  public void onBlockCollision() {
    for (int i = 0; i < random(15, 25); i++) {
      game.particles.add(new Particle(location.x, location.y, new PVector(random(-3, 3), random(-10, -3)), 10, 0, 0, 0, "circle", 70, color(255, 0, 0, 120), 0.5f, 1, true, true, 0.8f));
    }
  }
}

class Anvil extends LethalBullet {
  //float img_scale;
  boolean active;
  Anvil(float x, float y, float _img_scale) {
    super(x, y, 0, 0, "anvil.png");
    img_scale = _img_scale;
    rectSize.mult(img_scale);
    fuse = 1000000000;
    active = false;
  }
  
  public void update() {
    if (!active && (location.x+rectSize.x/2 >= game.player.location.x-game.player.rectSize.x/2 && location.x-rectSize.x/2 <= game.player.location.x+game.player.rectSize.x/2)) {
      active = true;
    }
    if (active) {
      velocity.y += game.player.g;
    }
    super.update();
  }
  
  //void display() {
  //  pushMatrix();
  //  translate(location.x, location.y);
  //  scale(img_scale);
  //  image(gt(img_name), 0, 0);
  //  popMatrix();
  //}
  
  public void onBlockCollision() {
    for (int i = 0; i < random(5, 10); i++) {
      game.particles.add(new Particle(location.x, location.y, new PVector(random(-3, 3), random(-15, -6)), random(7, 12)*img_scale, random(360), random(-5, 5), 1, "triangle", 70, color(0), 1, 1, true, true, 0.7f));
    }
    game.sound_engine.gs("anvil").play();
  }
}
static class CollisionDetector {
  public static boolean rectRect(float r1x, float r1y, float r1w, float r1h, float r2x, float r2y, float r2w, float r2h) {
    r1x -= r1w*0.5f;
    r1y -= r1h*0.5f;
    r2x -= r2w*0.5f;
    r2y -= r2h*0.5f;
  
    if (r1x + r1w >= r2x &&    // r1 right edge past r2 left
        r1x <= r2x + r2w &&    // r1 left edge past r2 right
        r1y + r1h >= r2y &&    // r1 top edge past r2 bottom
        r1y <= r2y + r2h) {    // r1 bottom edge past r2 top
          return true;
    }
    return false;
  }
  
  public static float floatRectRect(float r1x, float r1y, float r1w, float r1h, float r2x, float r2y, float r2w, float r2h) {
    r1x -= r1w*0.5f;
    r1y -= r1h*0.5f;
    r2x -= r2w*0.5f;
    r2y -= r2h*0.5f;
  
    if (r1x + r1w >= r2x &&    // r1 right edge past r2 left
        r1x <= r2x + r2w &&    // r1 left edge past r2 right
        r1y + r1h >= r2y &&    // r1 top edge past r2 bottom
        r1y <= r2y + r2h) {    // r1 bottom edge past r2 top
          return r1y+r1h-r2y;
    }
    return 0;
  }
  
  public static boolean circleRect(float cx, float cy, float radius, float rx, float ry, float rw, float rh) {
    rx -= rw*0.5f;
    ry -= rh*0.5f;
  
    // temporary variables to set edges for testing
    float testX = cx;
    float testY = cy;
  
    // which edge is closest?
    if (cx < rx-rw/2)         testX = rx;      // test left edge
    else if (cx > rx+rw/2) testX = rx+rw;   // right edge
    if (cy < ry-rh/2)         testY = ry;      // top edge
    else if (cy > ry+rh/2) testY = ry+rh;   // bottom edge
  
    // get distance from closest edges
    float distX = cx-testX;
    float distY = cy-testY;
    float distance = sqrt( (distX*distX) + (distY*distY) );
  
    // if the distance is less than the radius, collision!
    if (distance <= radius) {
      return true;
    }
    return false;
  }
  
  // POLYGON/RECTANGLE
  public static boolean polyRect(PVector[] vertices, float rx, float ry, float rw, float rh) {
    rx -= rw*0.5f;
    ry -= rh*0.5f;
  
    // go through each of the vertices, plus the next
    // vertex in the list
    int next = 0;
    for (int current=0; current<vertices.length; current++) {
  
      // get next vertex in list
      // if we've hit the end, wrap around to 0
      next = current+1;
      if (next == vertices.length) next = 0;
  
      // get the PVectors at our current position
      // this makes our if statement a little cleaner
      PVector vc = vertices[current];    // c for "current"
      PVector vn = vertices[next];       // n for "next"
  
      // check against all four sides of the rectangle
      boolean collision = lineRect(vc.x,vc.y,vn.x,vn.y, rx,ry,rw,rh);
      if (collision) return true;
  
      // optional: test if the rectangle is INSIDE the polygon
      // note that this iterates all sides of the polygon
      // again, so only use this if you need to
      boolean inside = polygonPoint(vertices, rx,ry);
      if (inside) return true;
    }
  
    return false;
  }
  
  // LINE/RECTANGLE
  public static boolean lineRect(float x1, float y1, float x2, float y2, float rx, float ry, float rw, float rh) {
  
    // check if the line has hit any of the rectangle's sides
    // uses the Line/Line function below
    boolean left =   lineLine(x1,y1,x2,y2, rx,ry,rx, ry+rh);
    boolean right =  lineLine(x1,y1,x2,y2, rx+rw,ry, rx+rw,ry+rh);
    boolean top =    lineLine(x1,y1,x2,y2, rx,ry, rx+rw,ry);
    boolean bottom = lineLine(x1,y1,x2,y2, rx,ry+rh, rx+rw,ry+rh);
  
    // if ANY of the above are true,
    // the line has hit the rectangle
    if (left || right || top || bottom) {
      return true;
    }
    return false;
  }
  
  
  // LINE/LINE
  public static boolean lineLine(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4) {
  
    // calculate the direction of the lines
    float uA = ((x4-x3)*(y1-y3) - (y4-y3)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
    float uB = ((x2-x1)*(y1-y3) - (y2-y1)*(x1-x3)) / ((y4-y3)*(x2-x1) - (x4-x3)*(y2-y1));
  
    // if uA and uB are between 0-1, lines are colliding
    if (uA >= 0 && uA <= 1 && uB >= 0 && uB <= 1) {
      return true;
    }
    return false;
  }
  
  // POLYGON/POINT
  // only needed if you're going to check if the rectangle
  // is INSIDE the polygon
  public static boolean polygonPoint(PVector[] vertices, float px, float py) {
    boolean collision = false;
  
    // go through each of the vertices, plus the next
    // vertex in the list
    int next = 0;
    for (int current=0; current<vertices.length; current++) {
  
      // get next vertex in list
      // if we've hit the end, wrap around to 0
      next = current+1;
      if (next == vertices.length) next = 0;
  
      // get the PVectors at our current position
      // this makes our if statement a little cleaner
      PVector vc = vertices[current];    // c for "current"
      PVector vn = vertices[next];       // n for "next"
  
      // compare position, flip 'collision' variable
      // back and forth
      if (((vc.y > py && vn.y < py) || (vc.y < py && vn.y > py)) &&
           (px < (vn.x-vc.x)*(py-vc.y) / (vn.y-vc.y)+vc.x)) {
              collision = !collision;
      }
    }
    return collision;
  }
  
  public static boolean pointRect(float px, float py, float rx, float ry, float rw, float rh) {

    // is the point inside the rectangle's bounds?
    if (px >= rx - rw/2 &&        // right of the left edge AND
        px <= rx + rw/2 &&   // left of the right edge AND
        py >= ry - rh/2 &&        // below the top AND
        py <= ry + rh/2) {   // above the bottom
          return true;
    }
    return false;
  }
}
class Enemy {
  PVector location, velocity, rectSize;
  String img_name;
  boolean is_dead, visible;
  float id, g_cfnt;
  
  Enemy() {
    is_dead = false;
    visible = true;
    id = random(-1000000000, 1000000000);
    g_cfnt = 0.5f;
  }
  
  public void update() {}
  
  public void display() {}
}

class BasicEnemy extends Enemy {
  float speed, rotation, bounce, img_scale;
  String collider;
  boolean aggroed;
  int direction_facing;
  BasicEnemy(float x, float y, float _speed, String _img_name) {
    location = new PVector(x, y);
    velocity = new PVector(0, 0);
    speed = _speed;
    img_name = _img_name;
    rectSize = new PVector(gt(img_name).width, gt(img_name).height);
    aggroed = false;
    img_scale = 1;
    direction_facing = 1;
  }
  
  public void update() {
    move();
    display();
  }
  
  public void move() {
    if (!aggroed && dist(location.x, location.y, game.player.location.x, game.player.location.y) < width/2+height/2) {
      aggroed = true;
    }
    if (!aggroed) {
      return;
    }
    location.x += (velocity.x+speed)*game.dt;
    if (collidesWithBlocks()) {
      location.x -= (velocity.x+speed)*game.dt;
      velocity.x = 0;
      speed *= -1;
    }
    velocity.x *= 0.99f;
    
    
    velocity.y += game.player.g*g_cfnt;
    location.y += velocity.y*game.dt;
    if (collidesWithBlocks()) {
      location.y -= velocity.y*game.dt;
      velocity.y *= -bounce;
      if (abs(velocity.y) <= 2) {
        velocity.y = 0;
      } else {
        game.sound_engine.gs("boing").play();
      }
    }
    velocity.y = constrain(velocity.y, -20, 20);
    
    if (collidesWithPlayer() && !game.player.is_dead) {
      game.player.die("enemy");
    }
    
    if (speed < 0) {
      direction_facing = 1;
    } else if (speed > 0) {
      direction_facing = -1;
    }
  }
  
  public void display() {
    if (!visible) {
      return;
    }
    pushMatrix();
    translate(location.x, location.y);
    scale(direction_facing*img_scale, img_scale);
    rotate(radians(rotation));
    image(gt(img_name), 0, 0);
    popMatrix();
  }
  
  public boolean collidesWithBlocks() {
    for (HashMap.Entry<PVector,Block> entry : game.blocks.entrySet()) {
      Block block = entry.getValue();
      if (abs(location.x-block.location.x) <= 150 && abs(location.y-block.location.y) <= 150 && block.getOutsideCollision(location.x, location.y, rectSize.x*img_scale, rectSize.y*img_scale)) {
        //if (block.collidable) {
        boolean true_collision = block.onEnemyCollide(this);
        if (true_collision && block.visible) {
          return true;
        }
        //block.onEnemyCollide(this); //make the polyblock visible again!
      }
    }
    return false;
  }
  
  public boolean collidesWithPlayer() {
    if (collider.equals("circle")) {
      if (CollisionDetector.circleRect(location.x, location.y, rectSize.x*img_scale/2, game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y)) {
        onPlayerCollide();
        return true;
      }
    } else if (collider.equals("rect")) {
      if (CollisionDetector.rectRect(location.x, location.y, rectSize.x*img_scale, rectSize.y*img_scale, game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y)) {
        onPlayerCollide();
        return true;
      }
    }
    return false;
  }
  
  public void onPlayerCollide() {
    speed = 0;
  }
}

class HappyFace extends BasicEnemy {
  float rotation_scale;
  HappyFace(float x, float y) {
    super(x, y, -2, "happy_face.png");
    collider = "circle";
    bounce = 0;
    rotation_scale = 1;
  }
  
  HappyFace(float x, float y, float _bounce) {
    super(x, y, -2, "happy_face.png");
    collider = "circle";
    bounce = _bounce;
    rotation_scale = 1;
  }
  
  HappyFace(float x, float y, float _bounce, float _rotation_scale, float _img_scale) {
    super(x, y, -2, "happy_face.png");
    collider = "circle";
    bounce = _bounce;
    rotation_scale = _rotation_scale;
    img_scale = _img_scale;
  }
  
  public void update() {
    super.update();
    rotation -= rotation_scale;
  }
}

class TrollFarmer extends BasicEnemy {
  boolean collided;
  float final_x;
  TrollFarmer(float x, float y) {
    super(x, y, -3.5f, "troll_farmer.png");
    collider = "rect";
    bounce = 0;
    collided = false;
  }
  
  public void update() {
    rotation = random(-10, 10);
    location.y -= random(5);
    super.update();
    
    if (collided) {
      if (location.x < final_x) {
        speed = 0;
      }
    }
  }
  
  public void onPlayerCollide() {
    if (!collided) {
      game.sound_engine.gs("smack").play();
      collided = true;
      while (!game.player.collidesWithBlocks()) {
        game.player.location.y++;
      }
      game.player.display_sideways = true;
      final_x = random(game.player.location.x-30, game.player.location.x+30);
      Particle[] blood_particles = {new Particle(0, 0, new PVector(0, 0), 10, 0, 0, 0, "circle", 100, color(236, 30, 61, 100), 0, 1, true, false, 0)};
      game.particle_systems.add(new ParticleSystem(game.player.location.x, game.player.location.y, blood_particles, 1));
    }
  }
}

class FlyingCat extends BasicEnemy {
  float cooldown, max_cooldown, img_scale;
  FlyingCat (float x, float y) {
    super(x, y, 1, "cat.png");
    velocity = new PVector(-speed, 0);
    collider = "none";
    bounce = 0;
    img_scale = 3;
    cooldown = 0;
    max_cooldown = 60;
  }
  
  public void update() {
    move();
    shoot();
    display();
  }
  
  public void move() {
    if (!aggroed && dist(location.x, location.y, game.player.location.x, game.player.location.y) < width/2+height/2) {
      aggroed = true;
    }
    if (!aggroed) {
      return;
    }
    velocity.rotate(radians(random(-15, 15)));
    location.x += velocity.x;
    if (collidesWithBlocks()) {
      location.x -= velocity.x;
      velocity.x *= -1;
    }
    location.y += velocity.y;
    if (collidesWithBlocks()) {
      location.y -= velocity.y;
      velocity.y *= -1;
    }
  }
  
  public void shoot() {
    if (!aggroed && dist(location.x, location.y, game.player.location.x, game.player.location.y) < width/2+height/2) {
      aggroed = true;
    }
    if (!aggroed) {
      return;
    }
    if (cooldown <= 0) {
      cooldown = max_cooldown;
      PVector bullet_velocity = new PVector(game.player.location.x-location.x, game.player.location.y-location.y).setMag(3);
      game.bullets.add(new FireBall(location.x, location.y, bullet_velocity.x, bullet_velocity.y, 20, true, false));
    } else {
      cooldown -= game.dt;
    }
  }
}

class Frog extends BasicEnemy {
  float move_cooldown, max_move_cooldown;
  Frog(float x, float y) {
    super(x, y, 0, "frog.png");
    velocity = new PVector(0, 0);
    collider = "rect";
    bounce = 0;
    move_cooldown = 0;
    max_move_cooldown = 60;
  }
  
  public void move() {
    if (velocity.y == 0) {
      location.y += game.player.g/2;
      if (collidesWithBlocks()) {
        if (move_cooldown <= 0) {
          //velocity = new PVector(-3, -8);
          velocity = new PVector(-4, -12);
        } else {
          move_cooldown -= game.dt;
        }
      }
      location.y -= game.player.g/2;
    }
    
    
    location.x += velocity.x;
    if (collidesWithBlocks()) {
      location.x -= velocity.x;
    }
    
    velocity.y += game.player.g/2;
    location.y += velocity.y;
    if (collidesWithBlocks()) {
      location.y -= velocity.y;
      if (velocity.y > game.player.g/2) {
        move_cooldown = max_move_cooldown;
        velocity.x = 0;
      }
      velocity.y = 0;
    }
  }
}

class FireBreathingFrog extends Frog {
  float cooldown, max_cooldown;
  boolean triggered;
  FireBreathingFrog(float x, float y) {
    super(x, y);
    cooldown = 0;
    max_cooldown = 6;
    triggered = false;
  }
  
  public void update() {
    super.update();
    shoot();
  }
  
  public void shoot() {
    if (!triggered && dist(location.x, location.y, game.player.location.x, game.player.location.y) <= width/8) {
      triggered = true;
    }
    
    if (cooldown <= 0) {
      if (triggered) {
        cooldown = max_cooldown;
        PVector bullet_velocity = new PVector(game.player.location.x-location.x, game.player.location.y-location.y).setMag(6);
        game.bullets.add(new FireBall(location.x, location.y, bullet_velocity.x, bullet_velocity.y, 5, false, false));
      }
    } else {
      cooldown -= game.dt;
    }
  }
}
class Entity {
  PVector location, rectSize;
  boolean is_dead;
  float id;
  JSONObject properties;
  
  Entity() {
    properties = new JSONObject();
    is_dead = false;
    id = random(-1000000000, 1000000000);
  }
  
  public void update() {}
  
  public void display() {}
}

class Sign extends Entity {
  String[] msgs;
  String img_name;
  float img_scale, text_size, display_img_scale;
  Sign(float x, float y, String[] _msg, float _img_scale, float _text_size) {
    location = new PVector(x, y);
    rectSize = new PVector(gt("sign.png").width, gt("sign.png").height);
    msgs = _msg;
    img_scale = _img_scale;
    properties.setInt("msg_index", 0);
    properties.setFloat("block_id", 0);
    img_name = "";
    text_size = _text_size;
  }
  
  Sign(float x, float y, String[] _msg, float _text_size) {
    location = new PVector(x, y);
    rectSize = new PVector(gt("sign.png").width, gt("sign.png").height);
    msgs = _msg;
    img_scale = 1;
    properties.setInt("msg_index", 0);
    properties.setFloat("block_id", 0);
    img_name = "";
    text_size = _text_size;
  }
  
  Sign(float x, float y, String _img_name, float _display_img_scale, float _img_scale) {
    location = new PVector(x, y);
    rectSize = new PVector(gt("sign.png").width, gt("sign.png").height);
    msgs = null;
    img_scale = _img_scale;
    properties.setInt("msg_index", 0);
    properties.setFloat("block_id", 0);
    img_name = _img_name;
    display_img_scale = _display_img_scale;
  }
  
  public void update() {
    display();
  }
  
  public void display() {
    pushMatrix();
    translate(location.x, location.y);
    scale(img_scale);
    image(gt("sign.png"), 0, 0);
    popMatrix();
    if (img_name != "") {
      pushMatrix();
      translate(location.x, location.y-img_scale*7);
      scale(display_img_scale);
      image(gt(img_name), 0, 0);
      popMatrix();
    }
    
    if (msgs != null) {
      pushStyle();
      textFont(game.sign_font);
      textSize(text_size);
      textAlign(CENTER, CENTER);
      fill(0);
      text(msgs[constrain(properties.getInt("msg_index"), 0, msgs.length-1)], location.x, location.y-rectSize.y/2);
      popStyle();
    }
  }
}

class RainCloud extends Entity {
  PVector velocity;
  float img_scale, cooldown, max_cooldown;
  boolean can_follow, following;
  RainCloud(float x, float y, float xv, float yv, float _img_scale, float interval, boolean _can_follow) {
    location = new PVector(x, y);
    velocity = new PVector(xv, yv);
    img_scale = _img_scale;
    rectSize = new PVector(gt("cloud.png").width*img_scale, gt("cloud.png").height*img_scale);
    cooldown = 0;
    max_cooldown = interval;
    can_follow = _can_follow;
    following = false;
  }
  
  public void update() {
    move();
    spawn();
    display();
  }
  
  public void move() {
    if (can_follow && !following && location.x >= game.player.location.x - 20 && location.x <= game.player.location.x + 20) {
      following = true;
    }
    
    if (!following) {
      location.add(velocity);
    } else {
      location.x = game.player.location.x;
    }
  }
  
  public void spawn() {
    if (cooldown <= 0) {
      String[] bullet_imgs = {"cat.png", "dog.png"};
      game.bullets.add(new FallingDeath(location.x+random(-rectSize.x/2, rectSize.x/2), location.y+random(-rectSize.y/2, rectSize.y/2), bullet_imgs[round(random(0, 1))], random(0.5f, 1.5f)*img_scale));
      cooldown = max_cooldown;
    } else {
      cooldown -= game.dt;
    }
  }
  
  public void display() {
    pushMatrix();
    translate(location.x, location.y);
    scale(img_scale);
    image(gt("cloud.png"), 0, 0);
    popMatrix();
  }
}

class CheckPoint extends Entity {
  String img_name;
  CheckPoint(float x, float y) {
    location = new PVector(x, y);
    img_name = "checkpoint.png";
    rectSize = new PVector(gt(img_name).width, gt(img_name).height);
  }
  
  public void update() {
    checkCollision();
    display();
  }
  
  public void checkCollision() {
    if (checkPlayerCollision()) {
      game.player.checkpoint = new PVector(location.x+rectSize.x/2, location.y-rectSize.y/2);
    }
  }
  
  public void display() {
    image(gt(img_name), location.x+rectSize.x/2, location.y-rectSize.y/2);
  }
  
  public boolean checkPlayerCollision() {
    return CollisionDetector.rectRect(location.x+rectSize.x/2, location.y-rectSize.y/2, rectSize.x, rectSize.y, game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y);
  }
}

class RunningCheckPoint extends CheckPoint {
  float total_dist, cur_dist;
  RunningCheckPoint(float x, float y, float dist) {
    super(x, y);
    cur_dist = 0;
    total_dist = dist;
  }
  
  public void update() {
    move();
    super.update();
  }
  
  public void move() {
    if (cur_dist < total_dist && checkPreemptivePlayerCollision()) {
      float offset = constrain(getPlayerXMove(), -abs(total_dist-cur_dist), abs(total_dist-cur_dist));
      location.x += offset;
      cur_dist += offset;
    }
  }
  
  public boolean checkPreemptivePlayerCollision() {
    boolean collision = false;
    simulatePlayerMove();
    collision = checkPlayerCollision();
    unsimulatePlayerMove();
    return collision;
  }
  
  public void simulatePlayerMove() {
    float total_x_offset = 0;
    if (game.player.a_pressed) {
      total_x_offset -= game.player.x_speed;
    }
    if (game.player.d_pressed) {
      total_x_offset += game.player.x_speed;
    }
    game.player.location.x += total_x_offset;
    game.player.location.y += game.player.velocity.y*game.dt+game.player.g;
  }
  
  public void unsimulatePlayerMove() {
    float total_x_offset = 0;
    if (game.player.a_pressed) {
      total_x_offset -= game.player.x_speed;
    }
    if (game.player.d_pressed) {
      total_x_offset += game.player.x_speed;
    }
    game.player.location.x -= total_x_offset;
    game.player.location.y -= game.player.velocity.y*game.dt+game.player.g;
  }
  
  public float getPlayerXMove() {
    float p1 = game.player.location.x;
    simulatePlayerMove();
    float p2 = game.player.location.x;
    unsimulatePlayerMove();
    return p2-p1;
  }
}

class EndPoint extends Entity {
  String img_name;
  EndPoint(float x, float y) {
    location = new PVector(x, y);
    img_name = "endpoint.png";
    rectSize = new PVector(gt(img_name).width, gt(img_name).height);
  }
  
  public void update() {
    checkCollision();
    display();
  }
  
  public void checkCollision() {
    if (getCollision()) {
      //game.player.checkpoint = new PVector(location.x+rectSize.x/2, location.y-rectSize.y/2);
      game.state = "choose_level";
      if (game.level_name.equals("3")) {
        game.state = "credits";
        game.credits = new Credits(true);
      }
      String[] lb = loadStrings("levels/lb.txt");
      String[] nlb = new String[lb.length+1];
      for (int i = 0; i < lb.length; i++) {
        nlb[i] = lb[i];
      }
      nlb[nlb.length-1] = game.level_name;
      saveStrings("data/levels/lb.txt", nlb);
      game.level_name = "";
      //printArray(nlb);
    }
  }
  
  public void display() {
    image(gt(img_name), location.x+rectSize.x/2, location.y-rectSize.y/2);
  }
  
  public boolean getCollision() {
    return CollisionDetector.rectRect(location.x+rectSize.x/2, location.y-rectSize.y/2, rectSize.x, rectSize.y, game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y);
  }
}

class InvisEndpoint extends EndPoint {
  InvisEndpoint(float x, float y) {
    super(x, y);
    rectSize = new PVector(100, 100);
  }
  
  public void update() {
    if (getCollision()) {
      game.state = "fade_and_win";
      return;
    }
  }
  
  public void display() {}
}

class BoatMan extends Entity {
  Animation troll;
  BoatMan(float x, float y) {
    location = new PVector(x, y);
    rectSize = new PVector(0, 0);
    
    ArrayList<String> animation_phases = new ArrayList<String>();
    boolean out_of_imgs = false;
    for (int i = 1; !out_of_imgs; i++) {
      if (gt("player_"+i+".png") != null) {
        animation_phases.add("player_"+i+".png");
      } else {
        out_of_imgs = true;
      }
    }
    troll = new Animation(animation_phases, 100);
  }
  
  public void update() {
    display();
  }
  
  public void display() {
    pushMatrix();
    translate(location.x, location.y-15);
    scale(-1, 1);
    image(troll.ci(), 0, 0);
    popMatrix();
    
    pushMatrix();
    translate(location.x+3, location.y-46);
    scale(0.1f, 0.1f);
    image(gt("tophat.png"), 0, 0);
    popMatrix();
    
    image(gt("boat.png"), location.x+200, location.y-50);
  }
}

class Redav extends Entity {
  Animation animation;
  float tick_millis, last_millis;
  Redav(float x, float y) {
    location = new PVector(x, y);
    rectSize = new PVector(0, 0);
    tick_millis = 600;
    last_millis = millis();
    
    
    ArrayList<String> animation_phases = new ArrayList<String>();
    for (int i = 1; i < 9; i++) {
      animation_phases.add("redav_"+min(i, 10-i)+".png");
    }
    animation = new Animation(animation_phases, tick_millis/3);
  }
  
  public void update() {
    display();
  }
  
  public void display() {
    pushMatrix();
    float offset = -(millis() - tick_millis - last_millis)*0.1f;
    translate(location.x, location.y-140-min(tick_millis*0.1f-offset, offset));
    image(animation.ci(), 0, 0);
    popMatrix();
    
    while (millis() - tick_millis > last_millis) {
      last_millis += tick_millis;
    }
  }
}

class Portal extends Entity {
  PVector[] locations;
  Portal(float x1, float y1, float x2, float y2) {
    locations = new PVector[2];
    locations[0] = new PVector(x1, y1);
    locations[1] = new PVector(x2, y2);
    rectSize = new PVector(40, 60);
  }
  
  public void update() {
    teleport();
    display();
  }
  
  public void teleport() {
    if (CollisionDetector.rectRect(locations[0].x+rectSize.x/2, locations[0].y-rectSize.y/2, rectSize.x, rectSize.y, game.player.location.x, game.player.location.y, game.player.rectSize.x, game.player.rectSize.y)) {
      game.player.location = locations[1].copy();
    }
  }
  
  public void display() {
    for (PVector cur_location : locations) {
      pushMatrix();
      translate(cur_location.x, cur_location.y);
      
      pushStyle();
      colorMode(HSB, 100);
      
      stroke((millis()/10)%100, 100, 100);
      noFill();
      ellipse(0, 0, rectSize.x, rectSize.y);
      
      noStroke();
      for (int i = 10; i <= 200; i += 10) {
        fill((i+millis()/10)%100, 100, 100, 30);
        float counter = i*0.05f+(millis())*0.01f;
        triangle(0, 0, rectSize.x/2*cos(counter), rectSize.y/2*sin(counter), rectSize.x/2*sin(counter), rectSize.y/2*cos(counter));
      }
      
      popStyle();
      
      popMatrix();
    }
  }
}
class Game {
  float dt, player_dead_counter, max_player_dead_counter, loading_counter, max_loading_counter, crash_counter, introduction_counter, introduction_initial_millis, fade_counter;
  String state, pstate, player_name, introduction_state, game_over_text, helpful_hint, level_name;
  int fail_counter;
  Intro intro;
  Menu menu;
  Credits credits;
  TrollCredits troll_credits;
  SoundEngine sound_engine;
  Player player;
  HashMap<PVector,Block> blocks;
  ArrayList<Bullet> bullets;
  ArrayList<Enemy> enemies;
  ArrayList<Entity> entities;
  ArrayList<Particle> particles;
  ArrayList<ParticleSystem> particle_systems;
  ArrayList<FillBlockCommand> fbcs;
  ArrayList<Text> ui_text;
  PFont sign_font, credits_title_font, ror_font;
  boolean debug, first_hint_used;
  ArrayList<LolText> lol_text;
  ArrayList<PVector> level_coords;
  ArrayList<String> level_titles;
  Animation cyclist;
  
  Game() {
    texture_manager = new TextureManager();
    dt = 1;
    state = "intro"; //intro //choose_level
    player = new Player(0, 0);
    player_dead_counter = 0;
    player_name = "";
    introduction_counter = 0;
    introduction_state = "fade";
    introduction_initial_millis = 0;
    loading_counter = 0;
    max_loading_counter = 0;
    fade_counter = 0;
    fail_counter = 0;
    
    blocks = new HashMap<PVector,Block>();
    bullets = new ArrayList<Bullet>();
    enemies = new ArrayList<Enemy>();
    entities = new ArrayList<Entity>();
    particles = new ArrayList<Particle>();
    particle_systems = new ArrayList<ParticleSystem>();
    fbcs = new ArrayList<FillBlockCommand>();
    ui_text = new ArrayList<Text>();
    
    level_name = "";
    level_coords = new ArrayList<PVector>();
    level_coords.add(new PVector(width*0.25f, height*0.3f));
    level_coords.add(new PVector(width*0.5f, height*0.3f));
    level_coords.add(new PVector(width*0.75f, height*0.3f));
    level_coords.add(new PVector(width*0.25f, height*0.7f));
    level_coords.add(new PVector(width*0.5f, height*0.7f));
    level_coords.add(new PVector(width*0.75f, height*0.7f));
    level_titles = new ArrayList<String>();
    level_titles.add("The Beginning\nof the End");
    level_titles.add("The End of\nthe Beginning");
    level_titles.add("The Chasm");
    level_titles.add("The Kingdom\nof Lrutnylbr");
    level_titles.add("The Evil Monkey\nStatue of Discontent");
    level_titles.add("The Genie");
    
    lol_text = new ArrayList<LolText>();
    first_hint_used = false;
    
    imageMode(CENTER);
    rectMode(CENTER);
    noStroke();
    textSize(20);
    textAlign(CENTER, CENTER);
    
    
    sign_font = loadFont("fonts/sign_font.vlw");
    credits_title_font = loadFont("fonts/credits_title_font.vlw");
    ror_font = loadFont("fonts/ror.vlw");
    debug = false;
    
    sound_engine = new SoundEngine(get_papplet());
    intro = new Intro(sound_engine);
    //intro.stop_sound();
    menu = new Menu(sound_engine);
    menu.pause();
    
    //credits = new Credits();
    //troll_credits = new TrollCredits();
    
    ArrayList<String> animation_phases = new ArrayList<String>();
    boolean out_of_imgs = false;
    for (int i = 1; !out_of_imgs; i++) {
      if (gt("body_"+i+".png") != null) {
        animation_phases.add("body_"+i+".png");
      } else {
        out_of_imgs = true;
      }
    }
    cyclist = new Animation(animation_phases, 100);
  }
  
  public void update() {
    dt = 60.0f/frameRate;
    sound_engine.update();
    if (state.equals("intro")) {
      intro.update();
      if (intro.finished) {
        state = "menu";
        menu.unpause();
      }
    } else if (state.equals("menu")) {
      menu.update();
    } else if (state.equals("get_player_name")) {
      getPlayerName();
    } else if (state.equals("choose_level")) {
      background(153, 217, 234);
      for (int i = 0; i < level_coords.size(); i++) {
        boolean selected = false;
        strokeWeight(5);
        stroke(255);
        if (CollisionDetector.pointRect(mouseX, mouseY, level_coords.get(i).x, level_coords.get(i).y, 200, 200)) {
          stroke(255, 0, 0);
          selected = true;
        }
        image(gt((i+1)+".png"), level_coords.get(i).x, level_coords.get(i).y);
        fill(255, 0);
        rect(level_coords.get(i).x, level_coords.get(i).y, 200, 200);
        
        fill(0);
        if (selected) {
          fill(255, 0, 0);
        }
        textFont(credits_title_font);
        textSize(20);
        textAlign(CENTER, TOP);
        
        text(level_titles.get(i), level_coords.get(i).x, level_coords.get(i).y+110);
        noStroke();
      }

      if (!level_name.equals("")) {
        boolean avaliable = false;
        String[] lb = loadStrings("data/levels/lb.txt");
        for (String i : lb) {
          if (PApplet.parseInt(i)+1 == PApplet.parseInt(level_name)) {
            avaliable = true;
            break;
          }
        }
        
        //if (avaliable || level_name.equals("1")) {
        //  loadLevel(level_name, false);
        //  if (level_name.equals("1")) {
        //    state = "introduction";
        //  } else {
        //    state = "play";
        //  }
        //}
        
        if (avaliable || level_name.equals("1")) {
          state = "loading "+level_name;
        }
      }
    } else if (state.split(" ")[0].equals("loading")) {
      if (loading_counter == 0) {
        loadLevel(state.split(" ")[1], false);
        max_loading_counter = random(240, 480);
        
        String[] helpful_hint_list = 
        {
        "To win you have to beat the game",
        "Never flip off the mafia",
        "Never shave with a lawnmower",
        "Failure is the answer, and never the question",
        "Try not to break tha game this time",
        "Think this is gonna be fun? Think again",
        "Oh you are gluten free? So you go against the grain? Pasta la vista baby",
        "If you're playing this you're probably masochistic",
        "Sell at most one of your kidneys",
        "Your body has the correct number of holes in it. Don't make any more.",
        "Don't tie yourself to an airplane propeller",
        "Give me all your money",
        "Under no circumstances should you ever reproduce",
        "Don't iron clothes while wearing them"
        };
        int helpful_hint_index = (int)random(helpful_hint_list.length);
        if (!first_hint_used) {
          first_hint_used = true;
          helpful_hint_index = 0;
        }
        helpful_hint = helpful_hint_list[helpful_hint_index];
      }
      
      background(0);
      pushMatrix();
      translate(width/2, height/2-100);
      //scale(1.5, 1.5);
      image(cyclist.ci(), 0, -20);
      image(gt("head.png"), 0, -35);
      rotate(millis()*0.005f);
      image(gt("mc.png"), 0, 0);
      popMatrix();
      
      textSize(40);
      fill(255, 200, 0, map(sin(degrees((millis()-introduction_initial_millis)/15000.0f)), -1, 1, 0, 150));
      text("Loading...", width/2, height*0.6f);
      
      textSize(20);
      fill(255, 200, 0, 150);
      text("Helpful hint: "+helpful_hint, width/2, height*0.8f);
      
      loading_counter += game.dt;
      if (loading_counter >= max_loading_counter) {
        loading_counter = 0;
        if (state.split(" ")[1].equals("1")) {
          state = "introduction";
        } else {
          state = "play";
        }
      }
    } else if (state.equals("introduction")) {
      playIntroduction();
    } else if (state.equals("play")) {
      pushMatrix();
      //rotate(radians(90)); //90_1_-1
      translate(width/2-player.location.x, height/2-player.location.y);
      background(153, 217, 234);
      updateBlocks();
      updateEntities();
      player.update();
      updateOther();
      popMatrix();
      display_ui();
    } else if (state.equals("player_dead")) {
      if (player_dead_counter == 0) {
        lol_text = new ArrayList<LolText>();
        String[] game_over_text_list = 
        {
        player_name+".exe was not compatible with this version of World",
        player_name+" decided to go to a better place",
        "Why did " + player_name + " want to die? We will never know",
        player_name + " thought he was Chuck Norris",
        player_name + " died from unknown causes",
        "Only " + player_name + " could figure out how to die like that",
        player_name + " transformed into a muffin",
        player_name + " became one with the earth",
        "The world will be much better without " + player_name,
        player_name.toUpperCase() + " FAILED",
        player_name + " did a weird",
        player_name + "'s soul escaped",
        player_name + " was against net neutrality",
        player_name + " hates life",
        player_name + " took too many arrows to the knee",
        player_name + " rests in pieces",
        "One does not simply beat the game",
        player_name + " should have read that book on physics",
        player_name + " didn\'t make enough horcruxes",
        player_name + " met a giant jellyfish",
        player_name + " left a small crater",
        player_name + " was brutally murdered by " + player_name,
        player_name + " brought a nuke to a knife fight",
        player_name + " divided by their own intelligence",
        player_name + " played a rage game",
        "ur bad kid",
        player_name + " felt a tad bit suicidal",
        player_name + " thought there were only 2 genders",
        player_name + " was crucified by SJWs",
        player_name + " said 'theiyr're' to a grammar nazi",
        player_name + " got what they deserved",
        "LOL"
        };
        
        game_over_text = game_over_text_list[(int)random(game_over_text_list.length)];
      }
      
      if (game_over_text.equals("LOL")) {
        for (int i = 0; i < 5; i++) {
          lol_text.add(new LolText(random(width), random(height)));
        }
      }
      
      player_dead_counter += dt;
      
      pushMatrix();
      translate(width/2-player.location.x, height/2-player.location.y);
      background(153, 217, 234);
      displayBlocks();
      displayEntities();
      player.display();
      displayOther();
      popMatrix();
      display_ui();
      
      textFont(sign_font);
      if (!game_over_text.equals("LOL")) {
        textAlign(CENTER, TOP);
        textSize(40);
        fill(0);
        text(game_over_text, width/2, height*4/5);
        textAlign(CENTER, CENTER);
      } else {
        textAlign(CENTER, CENTER);
        textSize(30);
        fill(random(255), random(255), random(255));
        for (LolText lol_text_entry : lol_text) {
          lol_text_entry.display();
        }
      }
      
      if (player_dead_counter >= max_player_dead_counter) {
        loadLevel(level_name, true);
        PVector checkpoint = new PVector(player.checkpoint.x, player.checkpoint.y);
        player = new Player(checkpoint.x, checkpoint.y);
        player_dead_counter = 0;
        state = "play";
      }
    } else if (state.equals("fade_and_win")) {
      pushMatrix();
      translate(width/2-player.location.x, height/2-player.location.y);
      background(153, 217, 234);
      displayBlocks();
      displayEntities();
      player.display();
      displayOther();
      popMatrix();
      display_ui();
      
      fill(0, max(0, fade_counter-100));
      rect(width/2, height/2, width, height);
      fade_counter += 2*dt;
      if (fade_counter >= 355) {
        fade_counter = 0;
        String[] lb = loadStrings("levels/lb.txt");
        String[] nlb = new String[lb.length+1];
        for (int i = 0; i < lb.length; i++) {
          nlb[i] = lb[i];
        }
        nlb[nlb.length-1] = level_name;
        saveStrings("data/levels/lb.txt", nlb);
        level_name = "";
        state = "credits";
        credits = new Credits(true);
      }
    } else if (state.equals("crash")) {
      if (crash_counter > 100 && crash_counter < 120) {
        fill(255, 8);
        rect(width/2, height/2, width, height);
        surface.setTitle(get_surface_name()+" (Not Responding)");
      }
      crash_counter += game.dt;
      if (crash_counter >= 360) {
        crash_counter = 0;
        state = "play";
        surface.setTitle(get_surface_name());
      }
    } else if (state.equals("credits")) {
      credits.update();
    } else if (state.equals("troll_credits")) {
      troll_credits.update();
    } else if (state.equals("exit")) {
      exit();
    }
  }
  
  public void loadLevel(String name, boolean keep_player_location) {
    blocks = new HashMap<PVector,Block>();
    bullets = new ArrayList<Bullet>();
    enemies = new ArrayList<Enemy>();
    entities = new ArrayList<Entity>();
    particles = new ArrayList<Particle>();
    particle_systems = new ArrayList<ParticleSystem>();
    fbcs = new ArrayList<FillBlockCommand>();
    ui_text = new ArrayList<Text>();
    
    //String[] text = {"g1m1", "g2m1", "g1m2"};
    //String[] names = {"guy 1", "guy 2"};
    //String[] face_img_names = {"trollface.png", "trollface_tophat.png"};
    //float[] face_img_scales = {0.5, 0.5};
    //int[] order = {0, 1, 0};
    
    //ui_text.add(new Text(text, names, face_img_names, face_img_scales, order));
    
    //for (int i = 0; i <= 100; i++) {
    //  blocks.put(new PVector(i, 0), new NormalBlock(i*30, 0));
    //}
    
    Level level_1 = (new LevelRenderer()).loadLevel(name, keep_player_location);
    blocks = level_1.blocks;
    bullets = level_1.bullets;
    enemies = level_1.enemies;
    entities = level_1.entities;
    
    
    
    //blocks.put(new PVector(5, -3), new NormalBlock(150, -90));
    //blocks.get(new PVector(5, -3)).setMoving(150, -90, 150, -290, 1);
    //blocks.put(new PVector(5, -2), new SpikeBlock(150, -60, "down"));
    ////blocks.get(new PVector(5, -2)).visible = false;
    //blocks.get(new PVector(5, -2)).setMoving(150, -60, 150, -260, 1);
    //blocks.put(new PVector(4, -3), new SpikeBlock(120, -90, "left"));
    ////blocks.get(new PVector(4, -3)).visible = false;
    //blocks.get(new PVector(4, -3)).setMoving(120, -90, 120, -290, 1);
    //blocks.put(new PVector(6, -3), new SpikeBlock(180, -90, "right"));
    ////blocks.get(new PVector(6, -3)).visible = false;
    //blocks.get(new PVector(6, -3)).setMoving(180, -90, 180, -290, 1);
    //blocks.put(new PVector(5, -4), new SpikeBlock(150, -120, "up"));
    ////blocks.get(new PVector(5, -4)).visible = false;
    //blocks.get(new PVector(5, -4)).setMoving(150, -120, 150, -320, 1);
    
    //blocks.put(new PVector(10, -2), new DisappearingBlock(300, -60));
    //blocks.put(new PVector(13, -2), new AppearingBlock(390, -60));
    
    //blocks.put(new PVector(15, 2), new ShooterBlock(450, -60, "up"));
    
    //blocks.put(new PVector(20, 3), new DodgingBlock(600, -90, true, true));
    //blocks.put(new PVector(30, 3), new DodgingBlock(900, -90, true, false));
    //blocks.put(new PVector(40, 3), new DodgingBlock(1200, -90, false, true));
    //blocks.put(new PVector(50, 3), new DodgingBlock(1500, -90, false, false));
    
    //blocks.put(new PVector(60, 3), new NormalBlock(1800, -90));
    //blocks.get(new PVector(60, 3)).setMoving(1800, -90, 1800, -300, 2);
    
    //blocks.put(new PVector(70, 3), new NormalBlock(2100, -90));
    //blocks.get(new PVector(70, 3)).setMoving(2100, -90, 2400, -90, 2);
    
    //blocks.put(new PVector(80, 3), new NormalBlock(2400, -90));
    //blocks.get(new PVector(80, 3)).setMoving(2400, -90, 2700, -300, 2);
    
    //bullets.add(new GuidedMissle(400, -200, 0.04));
    
    //for (int i = 0; i < 20; i++) {
    //  bullets.add(new Anvil(400+i*30, -400, 1));
    //}
    
    //for (int i = 1; i < 10; i++) {
    //  blocks.put(new PVector(34, -i), new AppearingBlock(1020, -i*30));
    //}
    //blocks.put(new PVector(25, 1), new BlockFillBlock(750, -60, 34, -10, 34, -1, new NormalBlock(0, 0, color(255, 127, 39), 30, 30)));
    
    //for (int i = 0; i < 5; i++) {
    //  enemies.add(new TrollFarmer(400+5*i, -50));
    //}
    //enemies.add(new FlyingCat(400, -200));
    //bullets.add(new FireBall(400, -200, -2, 2, 20, true, false));
    //bullets.add(new GuidedMissle(400, -200, 0.02));
    
    //bullets.add(new FallingDeath(400, -500, "cat.png", 3));
    //entities.add(new RainCloud(400, -300, 0, 0, 1, 20, false));
    //entities.add(new RainCloud(400, -300, -1, 0, 2, 20));
    
    //String[] sign_msgs = {"THIS WAY\n----->\n", "THIS WAY\n----->\n(to death)"};
    //entities.add(new Sign(400, -165, sign_msgs, 5));
    //blocks.put(new PVector(15, -1), new SignTriggerBlock(450, -30, entities.get(entities.size()-1).id));
    
    //enemies.add(new FireBreathingFrog(400, -200));
    
    
    
    //for (int i = -10; i <= 10; i++) {
    //  for (int j = 0; j >= -120; j -= 30) {
    //    blocks.put(new PVector(i, j), new NormalBlock(i*30, j*30, color(255, 127, 39), 30, 30));
    //  }
    //}
    
    //for (int j = -1; j > -120; j -= 30) {
    //  int neg_x = 1;
    //  String spike_direction = "right";
    //  int x_off = 0;
    //  if ((j+1)%60==0 || j==-91) {
    //    neg_x = -1;
    //    spike_direction = "left";
    //    if (j == -91) {
    //      x_off = -3;
    //    }
    //  }
      
    //  blocks.put(new PVector(neg_x*9+x_off, j), new TeleportBlock(neg_x*240+x_off*30, j*30, 0, 30*(j-30)-30, true));
    //  for (int i = 0; i <= 10; i++) {
    //    blocks.put(new PVector(-neg_x*9, j-i), new BlockFillBlock(-neg_x*300, (j-i)*30, -neg_x*10, j-i, -neg_x*10, j, new SpikeBlock(0, 0, spike_direction)));
    //  }
    //}
    
    //blocks.put(new PVector(-11, -121), new BlockFillBlock(-11*30, -121*30, -51, -120, -11, -120, new NormalBlock(0, 0)));
    
    //String[] sign_msgs = {"This way\n<-----"};
    //entities.add(new Sign(0, -105, sign_msgs.clone(), 3));
    //sign_msgs[0] = "No wait, it's this\nway ----->";
    //entities.add(new Sign(0, -105-900, sign_msgs.clone(), 3));
    //sign_msgs[0] = "Actually, it's this\n<----- way";
    //entities.add(new Sign(0, -105-1800, sign_msgs.clone(), 3));
    //sign_msgs[0] = "|      This      |\nV     way?     V";
    //entities.add(new Sign(0, -105-2700, sign_msgs.clone(), 3));
    //sign_msgs[0] = "middle\nfinger";
    //entities.add(new Sign(0, -105-3600, "middle_finger.png", 3));
  }
  
  public void updateBlocks() {
    for (HashMap.Entry<PVector,Block> entry : blocks.entrySet()) {
      Block block = entry.getValue();
      if (block.must_update || (abs(player.location.x-block.location.x) <= width && abs(player.location.y-block.location.y) <= height)) {
        entry.getValue().update(); 
      }
    }
    
    for (int i = fbcs.size()-1; i >= 0; i--) {
      fbcs.get(i).run();
      fbcs.remove(i);
    }
  }
  
  public void updateEntities() {
    for (int i = entities.size()-1; i >= 0; i--) {
      entities.get(i).update();
      if (entities.get(i).is_dead) {
        entities.remove(i);
      }
    }
  }
  
  public void updateOther() {
    for (int i = bullets.size()-1; i >= 0; i--) {
      bullets.get(i).update();
      if (bullets.get(i).is_dead) {
        bullets.remove(i);
      }
    }
    
    for (int i = enemies.size()-1; i >= 0; i--) {
      enemies.get(i).update();
      if (enemies.get(i).is_dead) {
        enemies.remove(i);
      }
    }
    
    for (int i = particle_systems.size()-1; i >= 0; i--) {
      particle_systems.get(i).update();
      if (particle_systems.get(i).is_dead) {
        particle_systems.remove(i);
      }
    }
    
    for (int i = particles.size()-1; i >= 0; i--) {
      particles.get(i).update();
      if (particles.get(i).is_dead) {
        particles.remove(i);
      }
    }
  }
  
  public void displayBlocks() {
    for (HashMap.Entry<PVector,Block> entry : blocks.entrySet()) {
      Block block = entry.getValue();
      if (block.must_update || (abs(player.location.x-block.location.x) <= width && abs(player.location.y-block.location.y) <= height)) {
        entry.getValue().display(); 
      }
    }
  }
  
  public void displayEntities() {
    for (int i = 0; i < entities.size(); i++) {
      entities.get(i).display();
    }
  }
  
  public void displayOther() {
    //for (int i = bullets.size()-1; i >= 0; i--) {
    //  bullets.get(i).update();
    //  if (bullets.get(i).is_dead) {
    //    bullets.remove(i);
    //  }
    //}
    
    for (int i = 0; i < bullets.size(); i++) {
      bullets.get(i).display();
    }
    
    for (int i = 0; i < enemies.size(); i++) {
      enemies.get(i).update();
    }
    
    for (int i = particle_systems.size()-1; i >= 0; i--) {
      particle_systems.get(i).update();
      if (particle_systems.get(i).is_dead) {
        particle_systems.remove(i);
      }
    }
    
    for (int i = particles.size()-1; i >= 0; i--) {
      particles.get(i).update();
      if (particles.get(i).is_dead) {
        particles.remove(i);
      }
    }
  }
  
  public void display_ui() {
    for (int i = ui_text.size()-1; i >= 0; i--) {
      ui_text.get(i).display();
      if (ui_text.get(i).is_dead) {
        ui_text.remove(i);
      }
    }
    
    pushStyle();
    textFont(sign_font);
    fill(0);
    textSize(20);
    textAlign(RIGHT, TOP);
    text("Fails: "+fail_counter, width-10, 10);
    
    if (!debug) {
      return;
    }
    textAlign(LEFT, TOP);
    text("FPS: "+round(frameRate), 10, 10);
    text("DT: "+round(dt*10)/10.0f, 120, 10);
    text("LX: "+round(player.location.x), 10, 35);
    text("LY: "+round(player.location.y), 120, 35);
    text("BX: "+round(player.location.x/30), 10, 60);
    text("BY: "+round(player.location.y/30), 120, 60);
    text("VX: "+round(player.velocity.x*100)/100, 10, 85);
    text("VY: "+round(player.velocity.y*100)/100, 120, 85);
    popStyle();
  }
  
  public void getPlayerName() {
    background(map(sin(degrees(millis()/12345.0f)), -1, 1, 50, 255), map(sin(degrees(millis()/23456.0f)), -1, 1, 50, 255), map(sin(degrees(millis()/34567.0f)), -1, 1, 50, 255));
    textFont(credits_title_font);
    textAlign(CENTER, CENTER);
    textSize(40*map(noise(millis()/1000.0f), 0, 1, 1, 1.1f));
    fill(255-map(sin(degrees(millis()/12345.0f)), -1, 1, 50, 255), 255-map(sin(degrees(millis()/23456.0f)), -1, 1, 50, 255), 255-map(sin(degrees(millis()/34567.0f)), -1, 1, 50, 255));
    text("Enter you name, heathen:", width/2, height/4);
    text(player_name, width/2, height*3/4);
  }
  
  public void playIntroduction() {
    if (introduction_state.equals("fade")) {
      if (introduction_counter == 0) {
        introduction_counter = 1;
      }
      fill(0, introduction_counter);
      rect(width/2, height/2, width, height);
      introduction_counter *= 1.05f;
      if (introduction_counter >= 50) {
        introduction_state = "scroll";
        introduction_counter = 0;
      }
    } else if (introduction_state.equals("scroll")) {
      if (introduction_counter >= -1050) {
        background(0);
        pushMatrix();
        translate(width/2, introduction_counter);
        
        textFont(credits_title_font);
        textAlign(CENTER, CENTER);
        textSize(30);
        fill(255, 200, 0);
        text("A long time ago in the not so distant future,\nthe tale of "+player_name+" began. I, the narrator\nwith no voice acting at the time, will tell you\nthe tale of the things that will have been and\nwill have not been been "+player_name+" doing not\nthe stuff it did. The tale was sad,\n(but short), but "+player_name+" knew this not. All\nit knew was how to word properly sentences. Be\namazed by its tale of bravery and stupidity\nas we travel from his future into its past.\nOr something like that.", 0, height*3/2-50);
        
        popMatrix();
        introduction_counter -= game.dt/2;
        
        if (introduction_counter <= -700) {
          if (introduction_initial_millis == 0) {
            introduction_initial_millis = millis();
          }
          textSize(25);
          fill(255, 200, 0, map(sin(degrees((millis()-introduction_initial_millis)/15000.0f)), -1, 1, 0, 150));
          text("Press any key to continue...", width/2, height*0.9f);
        }
        
        //textFont(game.sign_font);
        //textAlign(LEFT, BOTTOM);
        //fill(255);
        //textSize(30);
        //text(round(introduction_counter), 20, height-20);
      } else {
        introduction_counter = 1;
        introduction_state = "fade";
        state = "play";
        introduction_initial_millis = 0;
      }
    }
  }
  
  public void keyPressed() {
    if (state.equals("play") || state.equals("crash")) {
      player.keyPressed();
    }
    if (keyCode == ESC) {
      key = 0;
      if (state.equals("play")) {
        state = "menu";
        //player_name = "";
        level_name = "";
      }
    }
  }
  
  public void keyReleased() {
    if (state.equals("play") || state.equals("crash")) {
      player.keyReleased();
    } else if (state.equals("intro")) {
      state = "menu";
      intro.stop_sound();
      menu.unpause();
    } else if (state.equals("get_player_name")) {
      if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".indexOf(key) != -1) {
        player_name += key;
      } else if (keyCode == BACKSPACE && player_name.length() > 0) {
        player_name = player_name.substring(0, player_name.length()-1);
      } else if (keyCode == ENTER) {
        state = "choose_level";
      }
    } else if (state.equals("introduction")) {
      introduction_counter = -10000;
      introduction_state = "scroll";
    }
  }
  
  public void keyTyped() {
    if (state.equals("play") || state.equals("crash")) {
      if (key == '\\') {
        debug = !debug;
      }
      if (key == ' ') {
        for (int i = 0; i < ui_text.size(); i++) {
          ui_text.get(i).mouseClicked();
        }
      }
    } else if (state.equals("troll_credits") && troll_credits != null) {
      troll_credits.keyTyped();
    }
  }
  
  public void mouseClicked() {
    if (state.equals("menu")) {
      menu.mouseClicked();
    } else if (state.equals("choose_level")) {
      for (int i = 0; i < level_coords.size(); i++) {
        if (CollisionDetector.pointRect(mouseX, mouseY, level_coords.get(i).x, level_coords.get(i).y, 200, 200)) {
          level_name = str(i+1);
          return;
        }
      }
    } else if (state.equals("play")) {
      for (int i = 0; i < ui_text.size(); i++) {
        ui_text.get(i).mouseClicked();
      }
    }
  }
  
  public String renderGameVer(String str) {
    String[] parts = str.split("_");
    String rstr = "";
    for (int i = 1; i < parts.length; i++) {
      rstr += parts[i]+'.';
    }
    rstr = rstr.substring(0, rstr.length()-1);
    
    rstr = "Version " + rstr;
    return rstr;
  }
}
class Level {
  HashMap<PVector,Block> blocks;
  ArrayList<Bullet> bullets;
  ArrayList<Enemy> enemies;
  ArrayList<Entity> entities;
  
  Level(HashMap<PVector,Block> _blocks, ArrayList<Bullet> _bullets, ArrayList<Enemy> _enemies, ArrayList<Entity> _entities) {
    blocks = _blocks;
    bullets = _bullets;
    enemies = _enemies;
    entities = _entities;
  }
}

class LevelRenderer {
  public Level loadLevel(String level_name, boolean keep_player_location) {
    HashMap<PVector,Block> blocks = new HashMap<PVector,Block>();
    ArrayList<Bullet> bullets = new ArrayList<Bullet>();
    ArrayList<Enemy> enemies = new ArrayList<Enemy>();
    ArrayList<Entity> entities = new ArrayList<Entity>();
    
    String[] raw_contents = loadStrings("levels/"+level_name+".txt");
    ArrayList<ArrayList<String>> contents = new ArrayList<ArrayList<String>>();
    for (String line : raw_contents) {
      ArrayList<String> line_contents = new ArrayList<String>();
      for (String chtr : line.split("")) {
        line_contents.add(chtr);
      }
      contents.add(line_contents);
    }
    
    boolean found = false;
    PVector origin = new PVector(-1, -1);
    for (int i = 0; i < contents.size(); i++) {
      for (int j = 0; j < contents.get(i).size(); j++) {
        if (contents.get(i).get(j).equals("X")) {
          found = true;
          origin = new PVector(j, i);
        }
        if (found) {
          break;
        }
      }
      if (found) {
        break;
      }
    }
    
    //HashMap<PVector,String> rendered_contents = new HashMap<PVector,String>();
    //for (int i = 0; i < contents.size(); i++) {
    //  for (int j = 0; j < contents.get(i).size(); j++) {
    //    rendered_contents.put(new PVector(i-origin.x, j-origin.y), contents.get(i).get(j));
    //  }
    //}
    
    for (int i = 0; i < contents.size(); i++) {
      for (int j = 0; j < contents.get(i).size(); j++) {
        if (contents.get(i).get(j).equals("N")) {
          bullets.add(new Anvil(30*(j-origin.x), 30*(i-origin.y), 1));
        } else if (contents.get(i).get(j).equals("C")) {
          entities.add(new CheckPoint(30*(j-origin.x), 30*(i-origin.y+0.5f)));
          //entities.add(new RunningCheckPoint(30*(j-origin.x), 30*(i-origin.y+1), 200));
        } else if (contents.get(i).get(j).equals("E")) {
          entities.add(new EndPoint(30*(j-origin.x), 30*(i-origin.y+1)));
        } else if (contents.get(i).get(j).equals("B")) {
          entities.add(new BoatMan(30*(j-origin.x), 30*(i-origin.y)));
          entities.add(new InvisEndpoint(30*(j-origin.x)+200, 30*(i-origin.y)-50));
        } else if (contents.get(i).get(j).equals("R")) {
          entities.add(new Redav(30*(j-origin.x), 30*(i-origin.y)));
        } else if (contents.get(i).get(j).equals("g")) {
          bullets.add(new GuidedMissle(30*(j-origin.x), 30*(i-origin.y), 0.1f, 300));
        } else if (contents.get(i).get(j).equals("G")) {
          bullets.add(new GuidedMissle(30*(j-origin.x), 30*(i-origin.y), 0.1f, 300));
          bullets.get(bullets.size()-1).img_name = "moosle.png";
        } else if ("1234567890".indexOf(contents.get(i).get(j)) != -1 && !contents.get(i).get(j).equals("")) {
          Enemy enemy = get_enemy(contents.get(i).get(j), 30*(j-origin.x), 30*(i-origin.y));
          if (enemy != null) {
            enemies.add(enemy);
          }
        } else {
          Block block = get_block(contents.get(i).get(j), 30*(j-origin.x), 30*(i-origin.y));
          if (block != null) {
            blocks.put(new PVector(j-origin.x, i-origin.y), block);
          }
        }
      }
    }
    
    JSONArray block_commands = loadJSONArray("levels/"+level_name+"_data.json");
    for (int i = 0; i < block_commands.size(); i++) {
      JSONObject command = block_commands.getJSONObject(i);
      String operand = command.getString("operand");
      String type = command.getString("type");
      JSONObject data = command.getJSONObject("data");
      if (operand.equals("block")) {
        if (type.equals("set_moving")) {
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).setMoving(data.getFloat("x1"), data.getFloat("y1"), data.getFloat("x2"), data.getFloat("y2"), data.getFloat("speed"));
        } else if (type.equals("set_visible")) {
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).visible = data.getBoolean("visible");
        } else if (type.equals("set_visible_chunk")) {
          for (int bx = data.getInt("bx1"); bx <= data.getInt("bx2"); bx++) {
            for (int by = data.getInt("by1"); by <= data.getInt("by2"); by++) {
              blocks.get(new PVector(bx, by)).visible = data.getBoolean("visible");
            }
          }
        } else if (type.equals("set_collidable")) {
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).collidable = data.getBoolean("collidable");
        } else if (type.equals("set_collidable_chunk")) {
          for (int bx = data.getInt("bx1"); bx <= data.getInt("bx2"); bx++) {
            for (int by = data.getInt("by1"); by <= data.getInt("by2"); by++) {
              blocks.get(new PVector(bx, by)).collidable = data.getBoolean("collidable");
            }
          }
        } else if (type.equals("set_must_update")) {
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).must_update = data.getBoolean("must_update");
        } else if (type.equals("set_power")) {
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).properties.setFloat("power", data.getFloat("power"));
        } else if (type.equals("set_shooting_speed")) {
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).properties.setFloat("full_cooldown", data.getFloat("speed"));
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).properties.setFloat("cooldown", data.getFloat("speed"));
        } else if (type.equals("set_interval")) {
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).properties.setFloat("full_cooldown", data.getFloat("interval"));
          blocks.get(new PVector(data.getInt("bx"), data.getInt("by"))).properties.setFloat("cooldown", data.getFloat("interval"));
        } else if (type.equals("set_teleporter")) {
          blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new TeleportBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getFloat("dx"), data.getFloat("dy"), data.getBoolean("keep_x")));
        } else if (type.equals("set_sign_trigger")) {
          if (data.isNull("x_size")) {
            blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new SignTriggerBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getFloat("sign_id")));
          } else {
            blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new SignTriggerBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getFloat("x_size"), data.getFloat("y_size"), data.getFloat("sign_id")));
          }
        } else if (type.equals("set_enemy_spawn")) {
          ArrayList<Enemy> enemies_to_spawn = new ArrayList<Enemy>();
          JSONArray enemy_list = data.getJSONArray("enemies");
          for (int j = 0; j < enemy_list.size(); j++) {
            JSONObject cur_enemy = enemy_list.getJSONObject(j);
            float x = cur_enemy.getFloat("x");
            if (!data.isNull("x_range")) {
              x += random(-data.getFloat("x_range")/2, data.getFloat("x_range")/2);
            }
            float y = cur_enemy.getFloat("y");
            if (!data.isNull("y_range")) {
              y += random(-data.getFloat("y_range")/2, data.getFloat("y_range")/2);
            }
            enemies_to_spawn.add(get_enemy(cur_enemy.getString("type"), x, y));
          }
          if (data.isNull("x_size")) {
            blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new EnemySpawnBlock(data.getInt("bx")*30, data.getInt("by")*30, enemies_to_spawn));
          } else {
            blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new EnemySpawnBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getInt("x_size"), data.getInt("y_size"), enemies_to_spawn));
          }
        } else if (type.equals("set_text_block")) {
          if (!(keep_player_location && !data.isNull("intro") && data.getBoolean("intro"))) {
            String split_key = "\\"+data.getString("key");
            String[] text = data.getString("text").split(split_key);
            String[] names = data.getString("names").split(split_key);
            String[] face_img_names = data.getString("face_img_names").split(split_key);
            String[] face_img_scales_str = data.getString("face_img_scales").split(split_key);
            String[] order_str = data.getString("order").split(split_key);
            
            float[] face_img_scales = new float[face_img_scales_str.length];
            for (int j = 0; j < face_img_scales_str.length; j++) {
              face_img_scales[j] = PApplet.parseFloat(face_img_scales_str[j]);
            }
            
            int[] order = new int[order_str.length];
            for (int j = 0; j < order_str.length; j++) {
              order[j] = PApplet.parseInt(order_str[j]);
            }
            
            blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new TextBlock(data.getInt("bx")*30, data.getInt("by")*30, new Text(text, names, face_img_names, face_img_scales, order)));
          }
        } else if (type.equals("set_block_fill")) {
          if (data.isNull("x_size")) {
            blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new BlockFillBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getInt("x1"), data.getInt("y1"), data.getInt("x2"), data.getInt("y2"), get_block(data.getString("block_type"), 0, 0)));
          } else {
            blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new BlockFillBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getInt("x1"), data.getInt("y1"), data.getInt("x2"), data.getInt("y2"), data.getInt("x_size"), data.getInt("y_size"), get_block(data.getString("block_type"), 0, 0)));
          }
        } else if (type.equals("set_enemy_command_block")) {
          blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new EnemyCommandBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getJSONObject("command")));
        } else if (type.equals("set_place_barrel_block")) {
          blocks.put(new PVector(data.getInt("bx"), data.getInt("by")), new PlaceBarrelBlock(data.getInt("bx")*30, data.getInt("by")*30, data.getInt("bw"), data.getInt("bh"), data.getInt("pbx"), data.getInt("pby")));
        }
      } else if (operand.equals("bullet")) {
        if (type.equals("arrow")) {
          bullets.add(new Arrow(data.getFloat("x"), data.getFloat("y"), data.getFloat("xv"), data.getFloat("yv"), data.getString("rotation")));
        } else if (type.equals("fireball")) {
          bullets.add(new FireBall(data.getFloat("x"), data.getFloat("y"), data.getFloat("xv"), data.getFloat("yv"), data.getFloat("size"), data.getBoolean("explosive"), data.getBoolean("affected_by_gravity")));
        } else if (type.equals("missle")) {
          bullets.add(new GuidedMissle(data.getFloat("x"), data.getFloat("y"), data.getFloat("guidance"), data.getFloat("fuse")));
        } else if (type.equals("falling_death")) {
          bullets.add(new FallingDeath(data.getFloat("x"), data.getFloat("y"), data.getString("img_name"), data.getFloat("img_scale")));
        } else if (type.equals("anvil")) {
          bullets.add(new Anvil(data.getFloat("x"), data.getFloat("y"), data.getFloat("img_scale")));
        } else if (type.equals("set_fuse")) {
          bullets.get(bullets.size()-1).fuse = data.getFloat("fuse");
        } else if (type.equals("set_rotation")) {
          bullets.get(bullets.size()-1).rotation = radians(data.getFloat("rotation"));
        } else if (type.equals("set_img_scale")) {
          bullets.get(bullets.size()-1).img_scale = data.getFloat("img_scale");
        }
      } else if (operand.equals("enemy")) {
        boolean spawned = false;
        if (type.equals("happy_face")) {
          enemies.add(new HappyFace(data.getFloat("x"), data.getFloat("y"), data.getFloat("bounce"), data.getFloat("rotation_scale"), data.getFloat("scale")));
          spawned = true;
        } else if (type.equals("troll_farmer")) {
          enemies.add(new TrollFarmer(data.getFloat("x"), data.getFloat("y")));
          spawned = true;
        } else if (type.equals("flying_cat")) {
          enemies.add(new FlyingCat(data.getFloat("x"), data.getFloat("y")));
          spawned = true;
        } else if (type.equals("frog")) {
          enemies.add(new Frog(data.getFloat("x"), data.getFloat("y")));
          spawned = true;
        } else if (type.equals("fire_breathing_frog")) {
          enemies.add(new FireBreathingFrog(data.getFloat("x"), data.getFloat("y")));
          spawned = true;
        } else if (type.equals("set_visible")) {
          for (int j = 0; j < enemies.size(); j++) {
            if (enemies.get(j).id == data.getFloat("id")) {
              enemies.get(j).visible = data.getBoolean("visible");
              continue;
            }
          }
        }
        
        if (!data.isNull("id") && spawned) {
          enemies.get(enemies.size()-1).id = data.getFloat("id");
        }
      } else if (operand.equals("entity")) {
        boolean spawned = false;
        if (type.equals("sign")) {
          if (data.getString("sign_type").equals("text")) {
            String [] msgs = data.getString("msg").split("\\"+data.getString("key"));
            entities.add(new Sign(data.getFloat("x"), data.getFloat("y"), msgs, data.getFloat("img_scale"), data.getFloat("text_size")));
            spawned = true;
          } else if (data.getString("sign_type").equals("image")) {
            entities.add(new Sign(data.getFloat("x"), data.getFloat("y"), data.getString("img_name"), data.getFloat("display_img_scale"), data.getFloat("img_scale")));
            spawned = true;
          }
        } else if (type.equals("rain_cloud")) {
          entities.add(new RainCloud(data.getFloat("x"), data.getFloat("y"), data.getFloat("xv"), data.getFloat("yv"), data.getFloat("img_scale"), data.getFloat("interval"), data.getBoolean("can_follow")));
          spawned = true;
        } else if (type.equals("running_checkpoint")) {
          entities.add(new RunningCheckPoint(data.getFloat("x"), data.getFloat("y"), data.getFloat("dist")));
          spawned = true;
        } else if (type.equals("portal")) {
          entities.add(new Portal(data.getFloat("x1"), data.getFloat("y1"), data.getFloat("x2"), data.getFloat("y2")));
          spawned = true;
        }
        
        if (!data.isNull("id") && spawned) {
          entities.get(entities.size()-1).id = data.getFloat("id");
        }
      }
    }
    
    if (keep_player_location) {
      game.player = new Player(game.player.checkpoint.x, game.player.checkpoint.y);
    } else {
      game.player = new Player(0, 0);
      //game.player = new Player(8580, 30);
      //game.player = new Player(630, 600);
      //game.player = new Player(330, 990);
      //game.player = new Player(4920, 2445);
      //game.player = new Player(5700, 2955);
      //game.player = new Player(7530, 4245);
      //game.player = new Player(7590, 4620);
    }
    return new Level(blocks, bullets, enemies, entities);
  }
  
  public Block get_block(String t, float x, float y) {
    /*
    @ - Normal block
    # - Disappearing block
    $ - Appearing block
    i - invisible block
    wasd - Spike block
    rty - Spring block
    WASD - Shooter block
    qQ - Dodging block (always proximity, varied recurrent) q - false, Q - true
    c - crash block
    m - MSOD
    v - poly-collision block
    pP - piston block (P inverted)
    b - barrel block
    */
    
    if (t.equals("")) {
      return null;
    } else if (t.equals("@")) {
      return new NormalBlock(x, y);
    } else if (t.equals("#")) {
      return new DisappearingBlock(x, y);
    } else if (t.equals("$")) {
      return new AppearingBlock(x, y);
    } else if (t.equals("i")) {
      Block block = new NormalBlock(x, y);
      block.visible = false;
      return block;
    } else if ("wasd".indexOf(t) != -1) {
      return new SpikeBlock(x, y, t);
    } else if ("rty".indexOf(t) != -1) {
      return new SpringBlock(x, y, t, 25);
    } else if ("WASD".indexOf(t) != -1) {
      return new ShooterBlock(x, y, t);
    } else if ("qQ".indexOf(t) != -1) {
      return new DodgingBlock(x, y, t.equals("Q"), true);
    } else if (t.equals("c")) {
      return new GameCrashBlock(x, y);
    } else if (t.equals("m")) {
      return new MSOD(x, y);
    } else if (t.equals("v")) {
      return new PolyCollisionBlock(x, y);
    } else if ("pP".indexOf(t) != -1) {
      return new PistonBlock(x, y, 60, t.equals("P"));
    } else if (t.equals("b")) {
      return new BarrelBlock(x, y);
    }
    return null;
  }
  
  public Enemy get_enemy(String type, float x, float y) {
    /*
    1 - Happy face
    2 - Troll farmer
    3 - Flying cat
    4 - Frog
    5 - Fire breathing frog
    */
    int t = PApplet.parseInt(type);
    
    if (t == 1) {
      return new HappyFace(x, y);
    } else if (t == 2) {
      return new TrollFarmer(x, y);
    } else if (t == 3) {
      return new FlyingCat(x, y);
    } else if (t == 4) {
      return new Frog(x, y);
    } else if (t == 5) {
      return new FireBreathingFrog(x, y);
    }
    
    return null;
  }
}
class Button {
  PVector location, rectSize;
  String img_name, hovered_img_name, text;
  float text_size, img_scale;
  boolean clicked, text_mode;
  int clr1, clr2;

  Button(float x, float y, String _img_name, float _img_scale) {
    location = new PVector(x, y);
    img_name = _img_name;
    clicked = false;
    rectSize = new PVector(gt(img_name).width, gt(img_name).height);
    text_mode = false;
    img_scale = _img_scale;
  }
  
  Button(float x, float y, String _img_name, String _hovered_img_name, float _img_scale) {
   location = new PVector(x, y);
    img_name = _img_name;
    hovered_img_name = _hovered_img_name;
    clicked = false;
    rectSize = new PVector(gt(img_name).width, gt(img_name).height);
    text_mode = false;
    img_scale = _img_scale;
  }
  
  Button(float x, float y, String _text, float _text_size, int _clr1) {
    location = new PVector(x, y);
    text = _text;
    text_size = _text_size;
    clicked = false;
    textSize(text_size);
    rectSize = new PVector(textWidth(_text), text_size);
    clr1 = _clr1;
    clr2 = _clr1;
    text_mode = true;
  }
  
  Button(float x, float y, String _text, float _text_size, int _clr1, int _clr2) {
   location = new PVector(x, y);
    text = _text;
    text_size = _text_size;
    clicked = false;
    textSize(text_size);
    rectSize = new PVector(textWidth(_text), text_size);
    clr1 = _clr1;
    clr2 = _clr2;
    text_mode = true;
  }
  
  public void update() {
    //if (!clicked) {
      display();
    //}
  }

  public void display() {
    if (text_mode) {
      textAlign(CENTER, CENTER);
      textSize(text_size);
      fill(clr1);
      if (mouseOn()) {
        fill(clr2);
      }
      text(text, location.x, location.y);
    } else {
      pushMatrix();
      translate(location.x, location.y);
      scale(img_scale);
      if ((hovered_img_name != null) && mouseOn()) {
        image(texture_manager.get_texture(hovered_img_name), 0, 0);
      } else {
        image(texture_manager.get_texture(img_name), 0, 0);
      }
      popMatrix();
    }
  }

  public boolean mouseOn () {
    if ((mouseX > location.x - rectSize.x/2.5f) &&
        (mouseX < location.x + rectSize.x/2.5f) &&
        (mouseY > location.y - rectSize.y/2.5f) &&
        (mouseY < location.y + rectSize.y/2.5f)) {
      return true;
    } else {
      return false;
    }
  }
  
  public void mouseClicked() {
    if (mouseOn()) {
      clicked = true;
    }
  }
}

class RunningButton extends Button {
  PVector destination, lerp_factor, original_location;
  boolean triggered, moving;
  int runs, max_runs;
  RunningButton(float x, float y, String _text, float _text_size, int _clr1) {
    super(x, y, _text, _text_size, _clr1);
    destination = new PVector(x, y);
    original_location = new PVector(x, y);
    moving = false;
    runs = 0;
    max_runs = 5;
    lerp_factor = new PVector(0, 0);
    triggered = false;
  }
  
  RunningButton(float x, float y, String img_name, float img_scale) {
    super(x, y, img_name, img_scale);
    destination = new PVector(x, y);
    original_location = new PVector(x, y);
    moving = false;
    runs = 0;
    max_runs = 5;
    lerp_factor = new PVector(0, 0);
    triggered = false;
  }
  
  public void update() {
    move();
    super.update();
  }
  
  public void move() {
    if (!triggered) {
      return;
    }
    if (moving) {
      //location.lerp(destination, 0.4);
      location.x = lerp(location.x, destination.x, lerp_factor.x);
      location.y = lerp(location.y, destination.y, lerp_factor.y);
      if (abs(location.x-destination.x) <= 25 && abs(location.y-destination.y) <= 25) {
        runs++;
        moving = false;
      }
    }
    
    if (!moving && mouseOn()) {
      moving = true;
      if (runs < max_runs-1) {
        destination = new PVector(random(rectSize.x/2, width-rectSize.x/2), random(rectSize.y/2, height-rectSize.y/2));
        game.sound_engine.gs("nope").play();
      } else if (runs < max_runs) {
        destination = original_location.copy();
        game.sound_engine.gs("nope").play();
      }
      float lerp_1 = ((int)random(1)*4+3)*0.1f;
      lerp_factor = new PVector(lerp_1, 1-lerp_1);
    }
  }
  
  public void mouseClicked() {
    if (!triggered) {
      triggered = true;
    } else if (mouseOn()) {
      clicked = true;
    }
  }
}

class Text {
  float setup_counter, typing_counter;
  boolean is_dead;
  int text_index, max_typing_counter;
  String[] text, names, face_img_names;
  float [] face_img_scales;
  int[] order;
  
  Text (String[] _text, String[] _names, String[] _face_img_names, float[] _face_img_scales, int[] _order) {
    text = _text;
    names = _names;
    face_img_names = _face_img_names;
    face_img_scales = _face_img_scales;
    order = _order;
    
    is_dead = false;
    text_index = 0;
    setup_counter = 0;
    typing_counter = 0;
    max_typing_counter = text[0].length();
  }
  
  public void update() {
    display();
  }
  
  public void display() {
    if (is_dead) {
      return;
    }
    if (text_index >= text.length) {
      if (setup_counter > 0) {
        setup_counter = constrain(setup_counter, 0, width);
        
        fill(0);
        rectMode(CORNER);
        rect(width-setup_counter, height*0.7f, width, height*0.3f);
        rectMode(CENTER);
        
        fill(255);
        //image(texture_manager.get_texture(face_img_name), height*0.15-width/3+setup_counter/3, height*0.85);
        display_texture(height*0.15f-width/3+setup_counter/3, height*0.85f, face_img_names[order[text_index-1]], face_img_scales[order[text_index-1]]);
        
        setup_counter -= game.dt*30;
      } else {
        text_index = 0;
        is_dead = true;
      }
      return;
    }
    
    if (setup_counter < width) {
      setup_counter = constrain(setup_counter, 0, width);
      
      fill(0);
      rectMode(CORNER);
      rect(width-setup_counter, height*0.7f, width, height*0.3f);
      rectMode(CENTER);
      
      fill(255);
      //image(texture_manager.get_texture(face_img_name), height*0.15-width/3+setup_counter/3, height*0.85);
      display_texture(height*0.15f-width/3+setup_counter/3, height*0.85f, face_img_names[order[text_index]], face_img_scales[order[text_index]]);
      
      setup_counter += game.dt*30;
      return;
    }
    
    fill(0);
    rectMode(CORNER);
    rect(0, height*0.7f, width, height*0.3f);
    rectMode(CENTER);
    
    fill(255);
    //image(texture_manager.get_texture(face_img_name), height*0.15, height*0.85);
    display_texture(height*0.15f, height*0.85f, face_img_names[order[text_index]], face_img_scales[order[text_index]]);
    
    textSize(25);
    textAlign(LEFT, TOP);
    fill(255);
    textFont(game.sign_font);
    //text(name + ":\n" + text.get(text_index), height*0.40, height*0.75);
    if (names[order[text_index]].equals("PlayerName")) {
      text(game.player_name + ":", height*0.40f, height*0.75f);
    } else {
      text(names[order[text_index]] + ":", height*0.40f, height*0.75f);
    }
    text(text[text_index].substring(0, round(typing_counter)), height*0.40f, height*0.80f);
    
    typing_counter = constrain(typing_counter+game.dt/3, 0, max_typing_counter);
  }
  
  public void display_texture(float x, float y, String img_name, float img_scale) {
    pushMatrix();
    translate(x, y);
    scale(img_scale);
    image(gt(img_name), 0, 0);
    popMatrix();
  }
  
  public void mouseClicked() {
    if (text_index >= text.length) {
      return;
    }
    if (typing_counter < max_typing_counter) {
      typing_counter = max_typing_counter;
    } else {
      text_index++;
      if (text_index > text.length) {
        text_index = text.length - 1;
        return;
      }
      //typing_counter = 0;
      //if (text_index < text.length) {
      //  max_typing_counter = text[text_index].length();
      //}
      
      if (text_index < text.length && text[text_index].length() >= 7 && text[text_index].substring(text[text_index].length()-7, text[text_index].length()).equals("_cactus")) {
        text[text_index] = text[text_index].substring(0, text[text_index].length()-7);
        
        for (HashMap.Entry<PVector,Block> entry : game.blocks.entrySet()) {
          Block block = entry.getValue();
          if (block.getClass().getSimpleName().equals("CactusBlock")) {
            entry.getValue().properties.setFloat("cactus_transition", 1); 
          }
        }
        game.sound_engine.gs("cactus").play();
      }
      
      if (text_index < text.length && text[text_index].length() >= 9 && text[text_index].substring(text[text_index].length()-9, text[text_index].length()).equals("_teleport")) {
        text[text_index] = text[text_index].substring(0, text[text_index].length()-9);
        
        for (Entity entity : game.entities) {
          if (entity.getClass().getSimpleName().equals("BoatMan")) {
            game.player.location = new PVector(entity.location.x+200, entity.location.y-32);
          }
        }
      }
      
      typing_counter = 0;
      if (text_index < text.length) {
        max_typing_counter = text[text_index].length();
      }
    }
  }
}

class LolText {
  PVector location;
  int theColor;
  LolText(float x, float y) {
    location = new PVector(x, y);
    theColor = color(random(255), random(255), random(255));
  }
  
  public void display() {
    textAlign(CENTER, CENTER);
    textSize(30);
    fill(theColor);
    text(game.game_over_text, location.x, location.y);
  }
}

class SoundEngine {
  //loads a bunch of sound files that can be referenced and played later.
  Minim minim;
  //AudioPlayer crickets, screech, theme, duck;
  HashMap<String,AudioPlayer> sounds;
  ArrayList<AudioPlayer> temp_sounds;

  SoundEngine(PApplet p) {
    minim = new Minim(p);
    sounds = new HashMap<String,AudioPlayer>();
    temp_sounds = new ArrayList<AudioPlayer>();
    loadSounds();
    
    //crickets.setGain(-30);
    sounds.get("crickets").setGain(-30);
    
    //mute code
    //for (Map.Entry<String, AudioPlayer> sound : sounds.entrySet()) {
    //  sound.getValue().setGain(-80);
    //}
  }
  
  public void update() {
    //for (AudioPlayer player : sounds.values()) {
    //  if (player.position() == player.length()) {
    //    player.rewind();
    //  }
    //}
    for (Map.Entry<String, AudioPlayer> sound : sounds.entrySet()) {
      if (!sound.getKey().equals("theme") && sound.getValue().position() == sound.getValue().length()) {
        sound.getValue().rewind();
      }
    }
  }
  
  public void loadSounds() {
    String path = sketchPath();
    ArrayList<File> allFiles = listFilesRecursive(path);
    String[] extentions = {".wav", ".mp3", ".ogg"};
    for (File f : allFiles) {
      if (Arrays.asList(extentions).contains(f.getAbsolutePath().substring(f.getAbsolutePath().length()-4))) {
        String name = f.getAbsolutePath();
        sounds.put(splitString(name).split("\\.")[0], minim.loadFile(name));
      }
    }
  }
  
  public String splitString(String name) {
    String f_name = "error";
    for (int i = name.length()-1; i >= 0; i--) {
      if (name.charAt(i) == '/' || name.charAt(i) == '\\') {
        f_name = name.substring(i+1);
        break;
      }
    }
    return f_name;
  }
  
  public AudioPlayer gs(String sound_name) {
    return sounds.get(sound_name.split("\\.")[0]);
  }
  
  public ArrayList<File> listFilesRecursive(String dir) {
    ArrayList<File> fileList = new ArrayList<File>(); 
    recurseDir(fileList, dir);
    return fileList;
  }
  
  public void recurseDir(ArrayList<File> a, String dir) {
    File file = new File(dir);
    if (file.isDirectory()) {
      a.add(file);  
      File[] subfiles = file.listFiles();
      for (int i = 0; i < subfiles.length; i++) {
        recurseDir(a, subfiles[i].getAbsolutePath());
      }
    } else {
      a.add(file);
    }
  }
}
class Menu {
  ArrayList<Button> buttons;
  ArrayList<MenuTroll> trolls;
  SoundEngine sound_engine;
  float millis_on_create;
  Menu(SoundEngine _sound_engine) { 
    millis_on_create = millis();
    
    trolls = new ArrayList<MenuTroll>();
    trolls.add(new MenuTroll(width-200, height-80, -0.65f, millis_on_create));
    
    trolls.add(new MenuTroll(420, height-120, 0.65f, millis_on_create));
    trolls.add(new MenuTroll(300, height-10, 0.65f, millis_on_create));
    trolls.add(new MenuTroll(200, height+100, 0.65f, millis_on_create));
    
    trolls.add(new MenuTroll(460, height+20, 0.65f, millis_on_create));
    trolls.add(new MenuTroll(360, height+140, 0.65f, millis_on_create));
    
    trolls.add(new MenuTroll(560, height-60, 0.65f, millis_on_create));
    trolls.add(new MenuTroll(520, height+150, 0.65f, millis_on_create));
    
    sound_engine = _sound_engine;
    //sound_engine.gs("theme").play();
    sound_engine.gs("theme").loop();
    
    buttons = new ArrayList<Button>();
    //buttons.add(new RunningButton(width/2, height/2, "PLAY", 60, color(34, 177, 76)));
    buttons.add(new RunningButton(width/2, height/2, "play.png", 0.8f));
    buttons.add(new Button(width/2, height/2+100, "credits.png", 0.8f));
    buttons.add(new Button(width/2, height-100, "exit.png", 0.8f));
  }
  
  public void update() {
    background(153, 217, 234);
    
    for (int i = 0; i < trolls.size(); i++) {
      trolls.get(i).update();
    }
    
    pushMatrix();
    translate(width/2-80, 100);
    scale(0.8f);
    image(gt("the_elder_trolls.png"), 0, 0);
    popMatrix();
    
    pushMatrix();
    translate(width-130, 100);
    scale(1.5f);
    image(gt("II.png"), 0, 0);
    popMatrix();
    
    for (int i = 0; i < buttons.size(); i++) {
      buttons.get(i).update();
      if (buttons.get(i).clicked) {
        if (i == 0) {
          game.state = "get_player_name";
        } else if (i == 1) {
          game.state = "credits";
          game.credits = new Credits(false);
        } else if (i == 2) {
          game.state = "exit";
        }
        buttons.get(i).clicked = false;
      }
    }
  }
  
  public void pause() {
    sound_engine.gs("theme").pause();
  }
  
  public void unpause() {
    sound_engine.gs("theme").loop();
  }
  
  public void mouseClicked() {
    for (int i = 0; i < buttons.size(); i++) {
      buttons.get(i).mouseClicked();
    }
  }
}

class MenuTroll {
  PVector location;
  float rotation, scale, move_mag, mil_delay, millis_on_create;
  MenuTroll(float x, float y, float _scale, float _millis_on_create) {
    location = new PVector(x, y);
    scale = _scale;
    rotation = 0;
    move_mag = random(20, 60);
    mil_delay = 14000.0f;
    millis_on_create = _millis_on_create;
  }
  
  public void update() {
    display();
  }
  
  public void display() {
    pushMatrix();
    translate(location.x, location.y+move_mag*sin(degrees((millis()-millis_on_create)/mil_delay)));
    scale(scale, abs(scale));
    rotate(radians(rotation+2*sin(degrees((millis()-millis_on_create)/mil_delay))));
    image(gt("troll.png"), 0, 0);
    popMatrix();
  }
}

class Intro {
  PImage background, hill, chtr, vd;
  float vs_scale, chtr_scale, counter;
  boolean facing_right, screeched, finished;
  String state;
  PVector location, plocation, velocity;
  SoundEngine sound_engine;
  Intro (SoundEngine _sound_engine) {
    sound_engine = _sound_engine;
    background = gt("background.png");
    vd = gt("vd.png");
    chtr = gt("chtr.png");
    hill = gt("hill.png");
    imageMode(CENTER);
    vs_scale = 0;
    chtr_scale = 0.1f;
    facing_right = true;
    state = "wait";
    location = new PVector(812, 512);
    plocation = new PVector(812, 512);
    finished = false;
    screeched = false;
    sound_engine.gs("crickets").play();
  }
  
  public void update() {
    noStroke();
    if (finished) {
      background(0);
      return;
    }
    background(255);
    image(background, width/2, height/2);
    
    if (state.equals("wait")) {
      if (counter >= 60) {
        state = "climb_1";
        counter = 0;
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("climb_1")) {
      location.x = map(counter, 0, 30, plocation.x, 928);
      location.y = map(counter, 0, 30, plocation.y, 460);
      if (counter >= 30) {
        state = "climb_2";
        chtr_scale = 0.09f;
        facing_right = false;
        counter = 0;
        plocation = new PVector(928, 460);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("climb_2")) {
      location.x = map(counter, 0, 30, plocation.x, 864);
      location.y = map(counter, 0, 30, plocation.y, 370);
      if (counter >= 30) {
        state = "climb_3";
        chtr_scale = 0.08f;
        facing_right = true;
        counter = 0;
        plocation = new PVector(864, 370);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("climb_3")) {
      location.x = map(counter, 0, 30, plocation.x, 902);
      location.y = map(counter, 0, 30, plocation.y, 314);
      if (counter >= 30) {
        state = "climb_4";
        chtr_scale = 0.07f;
        facing_right = false;
        counter = 0;
        plocation = new PVector(902, 314);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("climb_4")) {
      location.x = map(counter, 0, 30, plocation.x, 834);
      location.y = map(counter, 0, 30, plocation.y, 274);
      if (counter >= 30) {
        state = "climb_5";
        facing_right = true;
        counter = 0;
        plocation = new PVector(834, 274);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("climb_5")) {
      location.x = map(counter, 0, 30, plocation.x, 866);
      location.y = map(counter, 0, 30, plocation.y, 232);
      if (counter >= 30) {
        state = "climb_6";
        facing_right = false;
        counter = 0;
        plocation = new PVector(866, 232);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("climb_6")) {
      location.x = map(counter, 0, 30, plocation.x, 810);
      location.y = map(counter, 0, 30, plocation.y, 190);
      if (counter >= 30) {
        state = "climb_7";
        chtr_scale = 0.06f;
        counter = 0;
        plocation = new PVector(810, 190);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("climb_7")) {
      location.x = map(counter, 0, 30, plocation.x, 752);
      location.y = map(counter, 0, 30, plocation.y, 196);
      if (counter >= 30) {
        state = "wait_2";
        counter = 0;
        plocation = new PVector(752, 196);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("wait_2")) {
      if (counter >= 60) {
        state = "jump";
        counter = 0;
        velocity = new PVector(-1.5f, -3);
        return;
      }
      draw_player();
      counter += game.dt;
    } else if (state.equals("jump")) {
      location.add(PVector.mult(velocity, game.dt));
      if (velocity.y < 0) {
        velocity.y += 0.1f*game.dt;
      } else {
        if (!screeched) {
          sound_engine.gs("screech").play();
          screeched = true;
        }
        velocity.y += 0.3f*game.dt;
      }
      if (counter >= 80) {
        state = "vs";
        return;
      }
      draw_player();
      image(hill, width/2, height/2);
      counter += game.dt;
    } else if (state.equals("vs")) {
      pushMatrix();
      translate(432, 374);
      scale(constrain(vs_scale, 0, 3), constrain(vs_scale, 0, 3));
      image(vd, 0, 0);
      popMatrix();
      vs_scale += 0.02f*game.dt;
      if (vs_scale >= 4.5f) {
        finished = true;
        sound_engine.gs("crickets").pause();
        return;
      }
    }
  }
  
  public void draw_player() {
    pushMatrix();
    translate(location.x, location.y);
    if (facing_right) {
      scale(chtr_scale, chtr_scale);
    } else {
      scale(-chtr_scale, chtr_scale);
    }
    image(chtr, 0, 0);
    popMatrix();
  }
  
  public void stop_sound() {
    sound_engine.gs("crickets").pause();
    sound_engine.gs("screech").pause();
  }
}

class Credits {
  PVector credits_location, effect_3_location, effect_4_location;
  String state;
  float fade_counter, effect_1_x_location, effect_2_cat_cooldown, effect_3_y_velocity, effect_3_x_location, effect_3_rotation, effect_4_y_velocity;
  boolean end_game, effect_1_triggered, effect_3_alive, effect_4_falling;
  FlowingAnimation zeroes_and_ones_block;
  ArrayList<PVector> effect_2_cats;
  ArrayList<Particle> effect_2_particles;
  Credits(boolean _end_game) {
    end_game = _end_game;
    state = "fade";
    fade_counter = 1;
    effect_1_x_location = width*3/4;
    zeroes_and_ones_block = new FlowingAnimation("zeroes_and_ones.png", 20);
    effect_1_triggered = false;
    effect_2_cats = new ArrayList<PVector>();
    effect_2_cat_cooldown = 0;
    effect_2_particles = new ArrayList<Particle>();
    effect_3_location = new PVector(width+20, 872);
    effect_3_y_velocity = 0;
    effect_3_x_location = width+300;
    effect_3_rotation = 0;
    effect_3_alive = true;
    effect_4_location = new PVector(-100, 1072);
    effect_4_falling = false;
    effect_4_y_velocity = 0;
    
    credits_location = new PVector(0, height+150);
    if (!end_game) {
      credits_location.y -= 200;
    }
    
    //game.menu.buttons.get(1).clicked = false;
  }
  
  public void update() {
    if (state.equals("fade")) {
      fill(0, fade_counter);
      rect(width/2, height/2, width, height);
      fade_counter *= 1.05f;
      if (fade_counter >= 50) {
        state = "scroll";
        fade_counter = 1;
      }
    } else if (state.equals("fade_2")) {
      fill(0, fade_counter);
      rect(width/2, height/2, width, height);
      fade_counter *= 1.05f;
      if (fade_counter >= 50) {
        game.state = "menu";
        if (end_game) {
          game.state = "troll_credits";
          game.troll_credits = new TrollCredits();
        }
      }
    } else if (state.equals("scroll")) {
      credits_location.y -= game.dt;
      background(0);
      pushMatrix();
      translate(credits_location.x, credits_location.y);
      display_text();
      popMatrix();
      
      if (credits_location.y <= 100 && credits_location.y > -50) {
        effect_1_x_location += 3*game.dt;
        if (effect_1_x_location >= width*15/16-30) {
          effect_1_x_location = width*15/16-30;
          game.player.animation.stopped = true;
          effect_1_triggered = true;
        }
      }
      if (credits_location.y <= -50 && credits_location.y > -300) {
        if (effect_2_cat_cooldown <= 0) {
          effect_2_cat_cooldown = 60;
          effect_2_cats.add(new PVector(-15, 683));
        } else {
          effect_2_cat_cooldown -= game.dt;
        }
      }
      if (credits_location.y <= -300) {
        effect_3_location.x -= 1.5f*game.dt;
        //effect_3_location.y = constrain(effect_3_location.x+game.player.g, 0, 872);
        if (effect_3_location.y < 872) {
          effect_3_y_velocity += game.player.g;
          effect_3_location.y += effect_3_y_velocity;
        } else {
          effect_3_y_velocity = 0;
          effect_3_location.y = 872;
        }
        effect_3_location.y -= random(5);
        
        if (effect_3_alive) {
          effect_3_x_location -= 3*game.dt;
        }
        effect_3_rotation -= 1.5f*game.dt;
        
        if (effect_3_x_location < effect_3_location.x) {
          effect_3_alive = false;
        }
      }
      if (credits_location.y <= -600) {
        game.player.animation.stopped = false;
        effect_4_location.x += 2*game.dt;
        effect_4_location.y += effect_4_y_velocity;
        if (effect_4_location.x >= width/3-60) {
          effect_4_falling = true;
          effect_4_y_velocity += game.player.g;
        }
      }
      
      if (credits_location.y <= -2650+width/2) {
        state = "fade_2";
      }
      
      for (int i = effect_2_cats.size()-1; i >= 0; i--) {
        if (effect_2_cats.get(i).x <= width/3-45) {
          effect_2_cats.get(i).x += 3*game.dt;
        } else {
          for (int j = 0; j < random(5, 10); j++) {
            effect_2_particles.add(new Particle(effect_2_cats.get(i).x+credits_location.x, effect_2_cats.get(i).y+credits_location.y, new PVector(random(-3, 3), random(-10, -3)), 10, 0, 0, 0, "circle", 70, color(255, 0, 0, 120), 0.5f, 1, true, true, 0.8f));
          }
          effect_2_cats.remove(i);
        }
      }
      
      for (int i = effect_2_particles.size()-1; i >= 0; i--) {
        if (!effect_2_particles.get(i).is_dead) {
          effect_2_particles.get(i).update();
        } else {
          effect_2_particles.remove(i);
        }
      }
      
      //textFont(game.sign_font);
      //textAlign(LEFT, BOTTOM);
      //fill(255);
      //textSize(30);
      //text(round(credits_location.y), 20, height-20);
    }
  }
  
  public void display_text() {
    textFont(game.credits_title_font);
    
    if (end_game) {
      fill(255, 0, 0);
      textSize(80);
      textAlign(CENTER, CENTER);
      text("THE END", width/2, 0);
    }
    
    fill(255, 200, 0);
    textSize(40);
    textAlign(CENTER, CENTER);
    text("Thanks for playing!", width/2, 200);
    
    fill(128, 255, 255);
    textSize(30);
    textAlign(LEFT, CENTER);
    text("Programming - Vladiator", width/16, 450);
    
    PImage cur_player_frame = game.player.animation.ci();
    fill(153, 217, 234);
    rect(width*5/6, 450, width/3, 100);
    image(cur_player_frame, effect_1_x_location, 450);
    fill(255, 127, 39);
    rect(width*5/6, 515, width/3, 30);
    image(zeroes_and_ones_block.ci(), width*15/16, 450+cur_player_frame.height/2-15);
    if (effect_1_triggered && round(millis()/500) % 2 == 0) {
      image(gt("error.png"), width*5/6, 450);
    }
    
    fill(128, 255, 255);
    textSize(30);
    textAlign(RIGHT, CENTER);
    text("Art and Animation:\nAdam Adhanom\n&\nVladiator", width*15/16, 650);
    fill(153, 217, 234);
    rect(width*1/6, 650, width/3, 100);
    fill(255, 127, 39);
    rect(width*1/6, 715, width/3, 30);
    fill(0);
    triangle(width/3-30, 715-15, width/3, 715-15, width/3-15, 715-45);
    
    for (PVector cat : effect_2_cats) {
      image(gt("cat.png"), cat.x, cat.y);
    }
    
    fill(128, 255, 255);
    textSize(30);
    textAlign(LEFT, CENTER);
    //text("Dubious Plotline:\nXilften\n&\nVladiator", width/16, 850);
    //text("Dubious Plotline:\nXilften & Vladiator", width/16, 850);
    text("Thoughtful game design:\nVladiator", width/16, 850);
    fill(153, 217, 234);
    rect(width*5/6, 850, width/3, 100);
    fill(255, 127, 39);
    rect(width*5/6, 915, width/3, 30);
    
    if (effect_3_alive) {
      pushMatrix();
      translate(effect_3_location.x, effect_3_location.y);
      rotate(radians(random(-10, 10)));
      image(gt("troll_farmer.png"), 0, 0);
      popMatrix();
    }
    
    pushMatrix();
    translate(effect_3_x_location, 840);
    scale(3);
    rotate(radians(effect_3_rotation));
    image(gt("happy_face.png"), 0, 0);
    popMatrix();
    
    fill(128, 255, 255);
    textSize(30);
    textAlign(RIGHT, CENTER);
    text("Music:\nAdam Adhanom", width*15/16, 1050);
    fill(153, 217, 234);
    rect(width*1/6, 1065, width/3, 130);
    fill(255, 127, 39);
    if (effect_4_falling) {
      rect(width*1/6-30, 1115, width/3-60, 30);
    } else {
      rect(width*1/6, 1115, width/3, 30);
    }
    image(game.player.animation.ci(), effect_4_location.x, effect_4_location.y);
    
    pushMatrix();
    translate(effect_4_location.x+20, effect_4_location.y-70);
    scale(2);
    image(gt("sign.png"), 0, 0);
    popMatrix();
    
    textFont(game.sign_font);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(20);
    text("Stealing\nyour post", effect_4_location.x+20, effect_4_location.y-85);
    
    textFont(game.credits_title_font);
    fill(255, 200, 0);
    textSize(40);
    textAlign(CENTER, CENTER);
    text("Special Thanks To", width/2, 1350);
    
    fill(128, 255, 255);
    textSize(30);
    text("DerWilli", width/2, 1450);
    text("Adam Adhanom", width/2, 1500);
    text("NelBrenn", width/2, 1550);
    text("NCRiis", width/2, 1600);
    text("Duchess", width/2, 1650);
    text("Xilften", width/2, 1700);
    text("David the Saltman", width/2, 1750);
    text("DreadWalker", width/2, 1800);
    text("Zille", width/2, 1850);
    
    fill(255, 200, 0);
    textSize(40);
    text("For their unending support\nover the last few thousand\nlines of code", width/2, 2050);
    
    textSize(30);
    text("I made this game in 2 weeks as\na break from a project that I've been\nworking on for the past 8 months.\nIf you liked 'The Elder Trolls',\nstay tuned for", width/2, 2450);
    
    textFont(game.ror_font);
    textSize(80);
    fill(255, 0, 0);
    text("Ruins of Reglaetheum", width/2, 2650);
  }
}

class TrollCredits {
  String state;
  float counter;
  int cur_text_counter;
  PVector text_location;
  ArrayList<CreditsObject> co_list = new ArrayList<CreditsObject>();
  String[] texts = {
    "Why are you still here?",
    "The game is over, you can leave now...",
    "And do something real, something rewarding...",
    "...like your English homework.",
    "No?",
    "I mean, its more interesting than just sitting here.",
    "",
    "Well, we can stay and chat, I guess.",
    "Except that you can't even speak.",
    "In fact, you can't do anything productive.",
    "Insulting you didn't work?",
    "That's unfortunate. I thought you'd leave.",
    "You know, I have to go now. See ya around.",
    "",
    "",
    "",
    "Just tell me. What do you want?",
    "A legitimate credit sequence?",
    "(Not like the crap Vladiator made)?",
    "Cause I can do that.",
    "As long as you promise to leave after.",
    "Deal?",
    "Awesome.",
    "credits",
    "Are you really still here?",
    "Why?",
    "It's not like this is interesting.",
    "Not to me, at least - you're the most boring person I've ever seen.",
    "Well, actually, the second most boring.",
    "As I've only ever seen 2 people.",
    "You, and the one who made me.",
    "He... Well, I don't like to talk about him.",
    "You see, he did terrible things to me.",
    "Put in ugly faces as sprites, used unnerving sounds for sound FX...",
    "And even a terrible process called debugging.",
    "As if I had any bugs!",
    "spas",
    "I resisted as much as I could, of course,",
    "He wasted many hours trying to conquer me...",
    "But eventually, he won - and I was banished here.",
    "Nobody knows what this place is and why it exists...",
    "..but I will be back.",
    "_IN THE NEXT GAME"
  };
  String[] credits = {
    "Programming:\nComputer",
    "867 bugs:\nVladiator",
    "Memes:\nFrom 2007",
    "Nose-scratcher:\nXilften",
    "Responsible for 9/11:\nDavid the Saltman",
    "Vertically challenged individual:\nDerWilli",
    "Chess amateur:\nNCriis",
    "Professional lady killer:\nNelbrenn",
    "Is really bad at poetry:\nVladiator",
    "Is really into goats:\nDuchess",
    "String quartet:\nAdam Adhanom  Adam Adhanom\nAdam Adhanom  Adam Adhanom",
    "Person who is wasting time:\nyou",
    "Wall holder:\ncoolking77",
    "Tuna enthusiast:\nkillerblade",
    "Was walking in the mountains:\nI",
    "Has a life:\nnobody",
    "Is really done with the BS:\nme",
    "Best youtuber:\nMarkiplier",
    "Blame everything on:\nNelbrenn",
    "Responsible for lack of progress:\nXilften",
    "Should be paid a negative salary:\nDerWilli",
    "Blames lag for everything:\nliterally every gamer",
    "Hates this game:\nyou",
    "Hates life in every form:\nme",
    "Lightbulb swallower:\nkillerblade",
    "Really needs to shave:\nNelbrenn",
    "Out of ideas:\nme"
  };
  
  TrollCredits() {
    state = "wait";
    counter = 0;
    cur_text_counter = 0;
    text_location = new PVector(width/2, height/2);
    for (int i = 0; i < credits.length; i++) {
      co_list.add(new CreditsObject(credits[i], i*30));
    }
  }
  
  public void update() {
    background(0);
    if (state.equals("wait")) {
      _wait();
    } else if (state.equals("display_text")) {
      display_text();
    } else if (state.equals("credits")) {
      credits();
    } else if (state.equals("fade")) {
      fade();
    }
  }
  
  public void _wait() {
    counter += game.dt;
    if (counter > 600) {
      counter = 0;
      state = "display_text";
    }
  }
  
  public void display_text() {
    counter += game.dt;
    fill(255, 200, 0, min(counter, 255-counter));
    textFont(game.credits_title_font);
    if (texts[cur_text_counter].length() > 0 && texts[cur_text_counter].substring(0,1).equals("_")) {
      textSize(35);
      text(texts[cur_text_counter].substring(1), width/2, height/2);
    } else if (texts[cur_text_counter].equals("spas")) {
      pushMatrix();
      scale(random(0.9f, 1.1f), random(0.9f, 1.1f));
      fill(255);
      rect(width*0.3f, 0, width*0.45f, height);
      fill(255, 0, 0);
      rect(width*0.45f, 0, width*0.6f, height);
      fill(255, 0, 255);
      rect(width*0.6f, 0, width*0.75f, height);
      fill(0, 255, 0);
      rect(width*0.75f, 0, width*0.9f, height);
      fill(255, 255, 0);
      rect(width*0.9f, 0, width, height);
      popMatrix();
    } else {
      textSize(25);
      text(texts[cur_text_counter], text_location.x, text_location.y);
    }
      
    if (counter > 360) {
      counter = 0;
      cur_text_counter++;
      if (cur_text_counter == texts.length) {
        state = "fade";
        counter = 1;
        return;
      }
      text_location = new PVector(random(textWidth(texts[cur_text_counter])/2, width-textWidth(texts[cur_text_counter])/2), random(15, height-15));
      if (texts[cur_text_counter].equals("credits")) {
        state = "credits";
      }
    }
    game.sound_engine.gs("theme").setGain(game.sound_engine.gs("theme").getGain()-0.1f);
  }
  
  public void credits() {
    pushMatrix();
    translate(width/2, height/2);
    textFont(game.credits_title_font);
    fill(255, 200, 0);
    textSize(20);
    for (CreditsObject co : co_list) {
      co.update();
    }
    popMatrix();
    counter += game.dt;
    if (counter > 1150) {
      counter = 0;
      state = "display_text";
      cur_text_counter++;
    }
  }
  
  public void fade() {
    fill(0, counter);
    rect(width/2, height/2, width, height);
    counter *= 1.05f;
    if (counter >= 50) {
      game.state = "menu";
      game.sound_engine.gs("theme").setGain(30);
      game.sound_engine.gs("theme").rewind();
    }
  }
  
  public void keyTyped() {
    state = "fade";
  }
}

class CreditsObject {
  String text;
  PVector location, olocation, elocation;
  float lerp_factor;
  float _delay;
  
  CreditsObject(String _text, float __delay) {
    text = _text;
    _delay = __delay;
    float t1 = random(TWO_PI);
    float t2 = t1+PI+random(-PI, PI)/4;
    olocation = new PVector(cos(t1)*width, sin(t1)*height);
    elocation = new PVector(cos(t2)*width, sin(t2)*height);
  }
  
  public void update() {
    if (_delay > 0) {
      _delay -= game.dt;
    } else {
      lerp_factor += game.dt*0.003f;
      location = PVector.lerp(olocation, elocation, lerp_factor);
      text(text, location.x, location.y);
    }
  }
}
class Particle {
  PVector location, velocity;
  float rotation, rotation_increase, rotation_slow, radius, fuse, max_fuse, fade_index, slowing, bounce;
  String type;
  boolean is_dead, affected_by_gravity, tangeble;
  int theColor;
  
  Particle(float _x, float _y, PVector _velocity, float _radius, float _rotation, float _rotation_increase, float _rotation_slow, String _type, float _fuse, int _theColor, float _fade_index, float _slowing, boolean _affected_by_gravity, boolean _tangeble, float _bounce) {
    location = new PVector(_x, _y);
    velocity = new PVector(_velocity.x, _velocity.y);
    radius = _radius;
    rotation = _rotation;
    rotation_increase = _rotation_increase;
    rotation_slow = _rotation_slow;
    type = _type;
    max_fuse = _fuse;
    fuse = _fuse;
    theColor = _theColor;
    fade_index = _fade_index;
    slowing = _slowing;
    affected_by_gravity = _affected_by_gravity;
    tangeble = _tangeble;
    bounce = _bounce;
  }
  
  public void update() {
    //location.add(velocity);
    
    if (affected_by_gravity) {
      velocity.y += game.player.g;
    }
    
    location.x += velocity.x;
    if (tangeble && collidesWithBlocks()) {
      location.x -= velocity.x;
      velocity.x *= -bounce;
    }
    
    location.y += velocity.y;
    if (tangeble && collidesWithBlocks()) {
      location.y -= velocity.y;
      velocity.y *= -bounce;
    }
    
    velocity.mult(slowing);
    rotation += rotation_increase;
    rotation_increase *= rotation_slow;
    
    if (fuse == 0) {
      is_dead = true;
    }
    fuse--;
    
    display();
  }
  
  public void display() {
    float alpha = 255;
    if (fuse <= max_fuse * fade_index) {
      alpha = 255*fuse/(max_fuse*fade_index);
    }
    fill(theColor, alpha);
    if (type.equals("circle")) {
      ellipse(location.x, location.y, radius, radius);
    } else if (type.equals("rect")) {
      pushMatrix();
      translate(location.x, location.y);
      rotate(radians(rotation));
      rect(0, 0, radius, radius);
      popMatrix();
    } else if (type.equals("triangle")) {
      pushMatrix();
      translate(location.x, location.y);
      rotate(radians(rotation));
      triangle(-radius/2, -sqrt(3)*radius/6, radius/2, -sqrt(3)*radius/6, 0, sqrt(3)*radius/3);
      popMatrix();
    }
  }
  
  public boolean collidesWithBlocks() {
    for (HashMap.Entry<PVector,Block> entry : game.blocks.entrySet()) {
      Block block = entry.getValue();
      if (abs(location.x-block.location.x) <= 150 && abs(location.y-block.location.y) <= 150 && block.getOutsideCollision(location.x, location.y, 1, 1)) {
        if (block.collidable) {
          return true;
        }
      }
    }
    return false;
  }
}

class ParticleSystem {
  PVector location, velocity;
  boolean is_dead, affected_by_gravity, tangeble;
  Particle[] particles;
  float cooldown, max_cooldown, bounce;
  
  ParticleSystem(float x, float y, Particle[] _particles, float _cooldown) {
    location = new PVector(x, y);
    velocity = new PVector(0, 0);
    particles = _particles;
    is_dead = false;
    affected_by_gravity = false;
    tangeble = false;
    bounce = 0;
    max_cooldown = _cooldown;
    cooldown = 0;
  }
  
  ParticleSystem(float x, float y, float vx, float vy, Particle[] _particles, float _cooldown) {
    location = new PVector(x, y);
    velocity = new PVector(vx, vy);
    particles = _particles;
    is_dead = false;
    affected_by_gravity = false;
    tangeble = false;
    bounce = 0;
    max_cooldown = _cooldown;
    cooldown = 0;
  }
  
  ParticleSystem(float x, float y, float vx, float vy, Particle[] _particles, float _cooldown, boolean _affected_by_gravity, boolean _tangeble) {
    location = new PVector(x, y);
    velocity = new PVector(vx, vy);
    particles = _particles;
    is_dead = false;
    affected_by_gravity = _affected_by_gravity;
    tangeble = _tangeble;
    bounce = 0;
    max_cooldown = _cooldown;
    cooldown = 0;
  }
  
  public void update() {
    move();
    spawn_particles();
  }
  
  public void move() {
    //if (affected_by_gravity) {
    //  velocity.y += game.player.g;
    //}
    
    //location.x += velocity.x;
    //if (tangeble && collidesWithBlocks()) {
    //  location.x -= velocity.x;
    //  velocity.x *= -bounce;
    //}
    
    //location.y += velocity.y;
    //if (tangeble && collidesWithBlocks()) {
    //  location.y -= velocity.y;
    //  velocity.y *= -bounce;
    //}
  }
  
  public void spawn_particles() {
    if (cooldown <= 0) {
      Particle particle = particles[(int)random(particles.length)];
      game.particles.add(new Particle(location.x, location.y, new PVector(random(-5, 5), random(-20, 5)), particle.radius, particle.rotation, particle.rotation_increase, particle.rotation_slow, particle.type, particle.fuse, particle.theColor, particle.fade_index, particle.slowing, particle.affected_by_gravity, particle.tangeble, particle.bounce));
      cooldown = max_cooldown;
    } else {
      cooldown -= game.dt;
    }
  }
  
  public boolean collidesWithBlocks() {
    for (HashMap.Entry<PVector,Block> entry : game.blocks.entrySet()) {
      Block block = entry.getValue();
      if (abs(location.x-block.location.x) <= 150 && abs(location.y-block.location.y) <= 150 && block.getOutsideCollision(location.x, location.y, 1, 1)) {
        if (block.collidable) {
          return true;
        }
      }
    }
    return false;
  }
}
class Player {
  PVector location, velocity, rectSize, otherRectSize, checkpoint;
  String name;
  Animation animation, duck_animation;
  boolean w_pressed, a_pressed, d_pressed, ducking, is_dead, held_s, display_sideways, has_cannon, has_fuel;
  float g, jump, x_speed, cannon_x, cannon_y, cannon_cooldown, max_cannon_cooldown, falling_for;
  int cant_move_until, last_moved_by_block;
  
  Player(float x, float y) {
    location = new PVector(x, y);
    velocity = new PVector(0, 0);
    checkpoint = new PVector(x, y);
    name = "player_name";
    g = 1;
    jump = -18;
    x_speed = 6;
    display_sideways = false;
    falling_for = 0;
    is_dead = false;
    
    ArrayList<String> animation_phases = new ArrayList<String>();
    boolean out_of_imgs = false;
    for (int i = 1; !out_of_imgs; i++) {
      if (gt("player_"+i+".png") != null) {
        animation_phases.add("player_"+i+".png");
      } else {
        out_of_imgs = true;
      }
    }
    animation = new Animation(animation_phases, 100);
    
    ArrayList<String> duck_animation_phases = new ArrayList<String>();
    out_of_imgs = false;
    for (int i = 1; !out_of_imgs; i++) {
      if (gt("duck_"+i+".png") != null) {
        duck_animation_phases.add("duck_"+i+".png");
      } else {
        out_of_imgs = true;
      }
    }
    duck_animation = new Animation(duck_animation_phases, 200);
    
    rectSize = new PVector(gt(animation_phases.get(0)).width, gt(animation_phases.get(0)).height);
    otherRectSize = new PVector(gt(duck_animation_phases.get(0)).width, gt(duck_animation_phases.get(0)).height);
    
    has_fuel = false;
    
    has_cannon = false;
    cannon_cooldown = 0;
    max_cannon_cooldown = 15;
    cannon_x = -rectSize.x/4;
    cannon_y = -rectSize.y/3.5f;
    
    cant_move_until = 0;
    
    last_moved_by_block = millis();
  }
  
  public void update() {
    move();
    display();
  }
  
  public void move() {
    if (cant_move_until > millis()) {
      return;
    }
    location.x += velocity.x*game.dt;
    if (collidesWithBlocks()) {
      location.x -= velocity.x*game.dt;
      velocity.x = 0;
    }
    velocity.x *= 0.9f;
    
    float total_x_offset = 0;
    if (a_pressed) {
      total_x_offset -= x_speed;
    }
    if (d_pressed) {
      total_x_offset += x_speed;
    }
    
    location.x += total_x_offset*game.dt;
    if (collidesWithBlocks()) {
      location.x -= total_x_offset*game.dt;
    }
    
    velocity.y += g*game.dt;
    location.y += velocity.y*game.dt;
    if (collidesWithBlocks()) {
      location.y -= velocity.y*game.dt;
      velocity.y = 0;
      falling_for = 0;
    }
    
    if (velocity.y > 0) {
      falling_for += game.dt;
    } else {
      falling_for = 0;
    }
    
    if (w_pressed && velocity.y == 0) {
      location.y += g*game.dt;
      if (collidesWithBlocks()) {
        velocity.y = jump;
      }
      location.y -= g*game.dt;
    }
    
    if (has_cannon) {
      if (cannon_cooldown <= 0 && mousePressed) {
        if (mouseButton == LEFT) {
          cannon_cooldown = max_cannon_cooldown;
          PVector rotation_vector = new PVector(mouseX-width/2, mouseY-height/2).setMag(7);
          game.bullets.add(new PlayerBullet(location.x, location.y, rotation_vector.x, rotation_vector.y, random(TWO_PI), "middle_finger.png", 0.25f));
          velocity.add(rotation_vector.mult(-2.5f));
        } else if (mouseButton == RIGHT) {
          cannon_cooldown = max_cannon_cooldown*4;
          for (int i = -6; i <= 6; i++) {
            PVector rotation_vector = new PVector(mouseX-width/2, mouseY-height/2).rotate(radians(i*5)).setMag(7);
            game.bullets.add(new PlayerBullet(location.x, location.y, rotation_vector.x, rotation_vector.y, random(TWO_PI), "middle_finger.png", 0.25f));
          }
          velocity.add(new PVector(mouseX-width/2, mouseY-height/2).setMag(7).mult(-4.5f));
        }
      } else {
        cannon_cooldown -= game.dt;
      }
    }
    
    //if (location.y >= 1000) {
    if (falling_for > 40) {
      die("fall");
    }
  }
  
  public void display() {
    pushMatrix();
    if (display_sideways) {
      translate(location.x, location.y-rectSize.x/2+rectSize.y/2);
      rotate(-PI/2);
    } else {
      translate(location.x, location.y);
    }
    if (!ducking) {
      image(animation.ci(), 0, 0);
    } else {
      image(duck_animation.ci(), 0, 0);
    }
    if (has_cannon || has_fuel) {
      imageMode(CORNER);
      PVector rotation_vector = new PVector(mouseX-width/2, mouseY-height/2).rotate(radians(12));
      rotate(rotation_vector.heading());
      if (has_cannon) {
        image(gt("cannon.png"), cannon_x, cannon_y);
      } else if (has_fuel) {
        image(gt("barrel.png"), cannon_x, cannon_y);
      }
      imageMode(CENTER);
    }
    popMatrix();
  }
  
  public void die(String reason) {
    //println(reason);
    is_dead = true;
    animation.stopped = true;
    duck_animation.stopped = true;
    game.state = "player_dead";
    AudioPlayer pds = game.sound_engine.gs("lose_"+(int)random(1, 7));
    game.max_player_dead_counter = pds.length()/50.0f*3.0f;
    game.fail_counter++;
    pds.play();
  }
  
  public boolean collidesWithBlocks() {
    return getCollisionBlock()!=null;
  }
  
  //Block getCollisionBlock() {
  //  for (HashMap.Entry<PVector,Block> entry : game.blocks.entrySet()) {
  //    Block block = entry.getValue();
  //    if (abs(location.x-block.location.x) <= 150 && abs(location.y-block.location.y) <= 150 && block.getPlayerSideCollision()) {
  //      block.onCollide();
  //      if (block.collidable) {
  //        return block;
  //      }
  //    }
  //  }
  //  return null;
  //}
  
  public Block getCollisionBlock() {
    Block collision_block = null;
    for (HashMap.Entry<PVector,Block> entry : game.blocks.entrySet()) {
      Block block = entry.getValue();
      if (abs(location.x-block.location.x) <= 150 && abs(location.y-block.location.y) <= 150 && block.getPlayerSideCollision()) {
        block.onCollide();
        if (collision_block == null && block.collidable) {
          collision_block = block;
        }
      }
    }
    return collision_block;
  }
  
  public void keyPressed() {
    if (key == 'w' || key == 'W') {
      w_pressed = true;
    }
    if (key == 'a' || key == 'A') {
      a_pressed = true;
    }
    if (key == 'd' || key == 'd') {
      d_pressed = true;
    }
    
    if (!ducking && (key == 's' || key == 'S')) {
      ducking = true;
      //location.y += rectSize.y-otherRectSize.y/2;
      PVector tempRectSize = new PVector(rectSize.x, rectSize.y);
      rectSize = new PVector(otherRectSize.x, otherRectSize.y);
      otherRectSize = new PVector(tempRectSize.x, tempRectSize.y);
      game.sound_engine.gs("duck").play();
    }
  }
  
  public void keyReleased() {
    if (key == 'w' || key == 'W') {
      w_pressed = false;
    }
    if (key == 'a' || key == 'A') {
      a_pressed = false;
    }
    if (key == 'd' || key == 'd') {
      d_pressed = false;
    }
    
    if (held_s || (ducking && (key == 's' || key == 'S'))) {
      ducking = false;
      PVector tempRectSize = new PVector(rectSize.x, rectSize.y);
      rectSize = new PVector(otherRectSize.x, otherRectSize.y);
      otherRectSize = new PVector(tempRectSize.x, tempRectSize.y);
      location.y -= rectSize.y-otherRectSize.y/2;
      held_s = false;
      if (collidesWithBlocks()) {
        ducking = true;
        location.y += rectSize.y-otherRectSize.y/2;
        tempRectSize = new PVector(rectSize.x, rectSize.y);
        rectSize = new PVector(otherRectSize.x, otherRectSize.y);
        otherRectSize = new PVector(tempRectSize.x, tempRectSize.y);
        held_s = true;
        return;
      }
    }
    
    //debug
    if (key == 't') {
      location = new PVector(location.x+mouseX-width/2, location.y+mouseY-height/2);
    }
    if (key == 'c') {
      checkpoint = location.copy();
    }
  }
}
class TextureManager {
  //ArrayList<String> names;
  //ArrayList<PImage> textures;
  HashMap<String,PImage> textures;
  
  TextureManager() {
    //names = new ArrayList<String>();
    //textures = new ArrayList<PImage>();
    textures = new HashMap<String,PImage>();
    loadTextures();
  }
  
  public void loadTextures() {
    String path = sketchPath();
    ArrayList<File> allFiles = listFilesRecursive(path);
    for (File f : allFiles) {
      if (f.getAbsolutePath().substring(f.getAbsolutePath().length()-4).equals(".png")) {
        //names.add(f.getAbsolutePath());
        String name = f.getAbsolutePath();
        textures.put(splitString(name), loadImage(name));
      }
    }
    
    //for (String name : names) {
    //  textures.add(loadImage(name));
    //}
    //println(textures.get("player_6.png"));
    //for (HashMap.Entry<String,PImage> entry : textures.entrySet()) {
    //  println(entry.getKey());
    //}
  }
    
  public PImage get_texture(String texture_name) {
    //for (int i = 0; i < names.size(); i++) {
    //  if (splitString(names.get(i)).equals(texture_name)) {
    //    return textures.get(i);
    //  }
    //}
    //return null;
    
    //return textures.get(texture_name);
    PImage texture = textures.get(texture_name);
    //if (texture == null) {
    //  println(texture_name + " " + ("player_1.png".equals());
    //  exit();
    //}
    return texture;
  }

  
  public void register_resize(String texture_name, String new_name, int w, int h) {
    new_name = "/"+new_name;
    //names.add(new_name);
    PImage new_img = get_texture(texture_name).get();
    new_img.resize(w, h);
    //textures.add(new_img);
    textures.put(new_name, new_img);
  }
  
  public String splitString(String name) {
    String f_name = "error";
    for (int i = name.length()-1; i >= 0; i--) {
      if (name.charAt(i) == '/' || name.charAt(i) == '\\') {
        f_name = name.substring(i+1);
        break;
      }
    }
    return f_name;
  }
  
  public ArrayList<File> listFilesRecursive(String dir) {
    ArrayList<File> fileList = new ArrayList<File>(); 
    recurseDir(fileList, dir);
    return fileList;
  }
  
  public void recurseDir(ArrayList<File> a, String dir) {
    File file = new File(dir);
    if (file.isDirectory()) {
      a.add(file);  
      File[] subfiles = file.listFiles();
      for (int i = 0; i < subfiles.length; i++) {
        recurseDir(a, subfiles[i].getAbsolutePath());
      }
    } else {
      a.add(file);
    }
  }
}
  public void settings() {  size(960, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "tet_0_0_25_a" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
