The Summary-*.txt files are used to display in the gvr dialog when the user
hits the help-reference menu item.
When you translate this file you MUST make sure you save it using a utf-8
encoding.
The easiest way of doing this is by using gedit to save the file and choose
utf-8 as the encoding.
 