import pygame, sys, os, math, time, random
from PIL import Image
pygame.init()

class Goblin():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "goblin"
        self.ATK = 1
        self.health = 3
        self.speed = 3
        self.bullet_speed = 7
        self.bullet_life = 25
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//goblin_shot.png'))
        self.agro_range = 300
        self.fire_range = 100

class Orc():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "orc"
        self.ATK = 5
        self.health = 10
        self.speed = 1
        self.bullet_speed = 7
        self.bullet_life = 30
        self.fire_rate = 30
        self.bullet = (pygame.image.load(assets_dir+'shots//orc_shot.png'))
        self.agro_range = 500
        self.fire_range = 80

class DarkWizard():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "dark_wizard"
        self.ATK = 2
        self.health = 10
        self.speed = 0 #2
        self.bullet_speed = 10
        self.bullet_life = 90
        self.fire_rate = 40
        self.bullet = (pygame.image.load(assets_dir+'shots//dark_wizard_shot.png'))
        self.agro_range = 900
        self.fire_range = 900

class Cyclops():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "cyclops"
        self.ATK = 10
        self.health = 80
        self.speed = 0
        self.bullet_speed = 7
        self.bullet_life = 200
        self.fire_rate = 8
        self.bullet = (pygame.image.load(assets_dir+'shots//cyclops_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000

class Skeleton():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "skeleton"
        self.ATK = 1
        self.health = 2
        self.speed = 2
        self.bullet_speed = 5
        self.bullet_life = 20
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//skeleton_shot.png'))
        self.agro_range = 400
        self.fire_range = 80
        
class SkeletonKnight():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "skeleton_knight"
        self.ATK = 3
        self.health = 10
        self.speed = 2
        self.bullet_speed = 5
        self.bullet_life = 40
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//skeleton_knight_shot.png'))
        self.agro_range = 500
        self.fire_range = 120

class SkeletonTrap():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "skeleton_trap"
        self.ATK = 0
        self.health = 10
        self.speed = 0
        self.bullet_speed = 0
        self.bullet_life = 1
        self.fire_rate = 9999999
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1
        self.fire_range = 1

class Necromancer():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "necromancer"
        self.ATK = None
        self.health = 15
        self.speed = 1
        self.bullet_speed = None
        self.bullet_life = None
        self.fire_rate = 120
        self.bullet = None
        self.agro_range = 500
        self.fire_range = 500

class Skull():
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    def __init__(self):
        self.name = "skull"
        self.ATK = 5
        self.health = 50
        self.speed = 10
        self.bullet_speed = 5
        self.bullet_life = 100
        self.fire_rate = 70
        self.bullet = (pygame.image.load(assets_dir+'shots//skull_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000

def text (string, screen, color, position, size, topRight=False, update=False):
    font = pygame.font.Font(None, size)
    text = font.render(string, 1, (color[0], color[1], color[2]))
    if topRight:
        textpos = text.get_rect(right=position[0], top=position[1])
    screen.blit(text, textpos)
    if update:
        pygame.display.flip()

def intro (screen):
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    pygame.mixer.quit()
    video = pygame.movie.Movie(assets_dir+'intro.mpg')
    #video.set_volume(1)
    video_screen = pygame.Surface(video.get_size())

    video.set_display(video_screen)
    video.play()
    
    while video.get_busy():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
               sys.exit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
                return None
    
        screen.blit(video_screen,(0,0))
        pygame.display.update()

def render_level (wall_positions, assets_dir):
    walls = []
    wall_stats = []
    player = None
    player_rect = None
    enemies = []
    enemy_rects = []
    wall_row_index = 0
    wall_column_index = 0
    for wall_row in wall_positions:
        temp_wall_row = []
        temp_wall_stats_row = []
        for wall_column in wall_row:
            if wall_column == ' ':
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '@':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == '#':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//cave_wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == 'q':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_lt.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'w':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_rt.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'e':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_lb.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'r':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_rb.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'c':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//column_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == 't':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//tile_1.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'E':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//exit.png'))
                temp_wall_stats_row.append('exit')
            if wall_column == 'P':
                player = [(pygame.image.load(assets_dir+'sprites//player.png')), True]
                temp_wall_row.append(player)
                temp_wall_stats_row.append('player')
            if wall_column == '1':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//goblin.png'), wall_column_index, wall_row_index, Goblin(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '2':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//orc.png'), wall_column_index, wall_row_index, Orc(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '3':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//dark_wizard.png'), wall_column_index, wall_row_index, DarkWizard(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '4':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), wall_column_index, wall_row_index, Skeleton(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '5':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton_knight.png'), wall_column_index, wall_row_index, SkeletonKnight(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '6':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//necromancer.png'), wall_column_index, wall_row_index, Necromancer(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '7':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skull.png'), wall_column_index, wall_row_index, Skull(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'S':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton_trap.png'), wall_column_index, wall_row_index, SkeletonTrap(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            wall_column_index += 1
        wall_column_index = 0
        wall_row_index += 1
        walls.append(temp_wall_row)
        wall_stats.append(temp_wall_stats_row)
    wall_rects = []
    for wall_row in walls:
        temp_wall_row = []
        for wall_column in wall_row:
            try:
                temp_wall_row.append(wall_column.get_rect())
            except:
                try:
                    if wall_column[1]:
                        try:
                            player_rect = [(wall_column[0]).get_rect(), True]
                        except:
                            useless = None
                        temp_wall_row.append(player_rect)
                except:
                    temp_wall_row.append('')
        wall_rects.append(temp_wall_row)
    wall_row_x, wall_row_y = 0, 0
    for wall_row in wall_rects:
        for wall_column in wall_row:
            try:
                wall_column[0] += wall_row_x
                wall_column[1] += wall_row_y
            except:
                try:
                    wall_column[0][0] += wall_row_x
                    wall_column[0][1] += wall_row_y
                except:
                    useless = None
            wall_row_x += 20
        wall_row_x = 0
        wall_row_y += 20
    for enemy in enemies:
        enemy_rect = (enemy[0]).get_rect()
        enemy_rect[0] += (20*enemy[1])
        enemy_rect[1] += (20*enemy[2])
        enemy_rects.append(enemy_rect)
    return [walls, wall_rects, player, player_rect, wall_stats, enemies, enemy_rects]

def play (screen):
    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
    sprites_dir = assets_dir + 'sprites//'
    shots_dir = assets_dir + 'shots//'
    
    #48 x 36
    # P - Player
    # @ - Mountain
    # # - Cave wall
    # E - Exit
    # qwer - pentagram
    # c - column 1
    # t - tile 1
    # 1 - Goblin
    # 2 - Orc
    # 3 - Dark Wizard
    # 4 - Skeleton
    # 5 - Skeleton Knight
    # S - Skeleton trap
    # 6 - Necromancer
    # 7 - Skull (boss)
    levels =[['P  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '     @@@@@@@@@@@@@@@@@                @@@@@@@@@@',
              '     @@@@@@@@@@@@@@@@                  @@@@@@@@@',
              '      @@@@@@@@@@@@@@@          1      @@@@@@@@@@',
              '      @@@@@@@@@@@@@@                 @@@@@@@@@@@',
              '       @@@@@@@@@@@@@        @@      @@@@@@@@@@@@',
              '       @@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@',
              '        @@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@@',
              '        @@@@@@@@@@     @@@@@@@@@@@@@@@@@@@@@@@@@',
              '                         @@@@@@@@@@@@@@@@@@@@@@@',
              '                          @@@@@@@@@@@@@@@@@@@@@@',
              '                           @@@@@@@@@@@@@@@@@@@@@',
              '                            @@@@@@@@@@@@@@@@@@@@',
              '                             @@@@@@@@@@@@@@@@@@@',
              '      @@@@@@@@@@@             @@@@@@@@@@@@@@@@@@',
              '     @@@@@@@@@@@@@             @@@@@@@@@@@@@@@@@',
              '    @       @@@@@               @@@@@@@@@@@@@@@@',
              '             @@@@@       1       @@@@@@@@@@@@@@@',
              '                @@@               @@@@@@@@@@@@@@',
              '           1     @@@               @@@@@@@@@@@@@',
              '                 @@@@@@             @@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@         @@         @@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@         @@@         @@@@@@@@@',
              '@@@@@@@      @@@@@    @@    @@@         @@@@@@@@',
              '@@@@@          @@@@    @@    @@@         @@@@@@@',
              '@@@@            @@@@    @@    @@@         @@@@@@',
              '@@@@      1      @@    @@@@    @@@         @@@@@',
              '@@@@             @@    @@@@@    @@@         @@@@',
              '@@@@@           @@@    @@@@@@    @@@         @@@',
              '@@@@@@           @@@    @@@@@@    @@@         @@',
              '@@@@@@@@@@               @@@@@@                @',
              '@@@@@@@@@@@@@            @@@@@@@                ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    EEEE'],
             ['P  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                    @@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                       @@@@@@@@@@@@@@@@@@@@@@@@',
              '@                      1   @@@@@@@@@@@@@@@@@@@@@',
              '@                             @@@@@@@@@@@@@@@@@@',
              '@         1                      @@@@@@@@@@@@@@@',
              '@                                   @@@@@@@@@@@@',
              '@                                      @@@@@@@@@',
              '@                      1                  @@@@@@',
              '@                                            @@@',
              '@         1                          1         @',
              '@                                              @',
              '@                      1                       @',
              '@                                              @',
              '@                                    1         @',
              '@                                              @',
              '@@@       1            1                       @',
              '@@@@@@                                         @',
              '@@@@@@@@@                            1         @',
              '@@@@@@@@@@@@                                   @',
              '@@@@@@@@@@@@@@@        1                       @',
              '@@@@@@@@@@@@@@@@@@                             @',
              '@@@@@@@@@@@@@@@@@@@@@                          @',
              '@@@@@@@@@@@@@@@@@@@@@@@@                       @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@                    @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                 @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@              @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@         ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@      ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  E'],
             ['@@@@@@@@@@@@@@@@@@@@@  P   @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@         @@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@                     @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@                      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@            @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@          @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@      1      @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@           @@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@            @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@            @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@    1      @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@             @@@@      @@@@@@@@@@@  @@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@      @@@@@@',
              '@@@@@           @@@@@      @@@@@@@          @@@@',
              '@@@@@@         @@@@@@      @@@@@@     1    @@@@@',
              '@@@@@@          @@@@@      @@@@@@           @@@@',
              '@@@@@    1     @@@@@@      @@@@@@@           @@@',
              '@@@@@@       @@@@@@@@      @@@@@@@          @@@@',
              '@@@@@@@@   @@@@@@@@@@      @@@@@@          @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@            @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@      1     @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@          @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@           @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@ 222  @@@@           @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@            @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@            @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@     1    @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@            @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@                      @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@                     @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@         @@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@EEEEEE@@@@@@@@@@@@@@@@@@@@@'],
             ['@@@@@@@@@@@@@@@@@@@@@  P   @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@                                        @@@',
              '@@                                          @@@@',
              '@                                            @@@',
              '@                                             @@',
              '@                                              @',
              '@                                              @',
              '@           @@@                                @',
              '@           @ @                                @',
              '@            @                   @@            @',
              '@                               @@@@           @',
              '@                                @@@           @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                   1      1                   @',
              '@                                              @',
              '@                     3qw3                     @',
              '@                     3er3                     @',
              '@                                              @',
              '@                   1      1                   @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                  @           @',
              '@         @@                      @@           @',
              '@       @@@                        @@          @',
              '@        @                         @           @',
              '@                                              @',
              '@                                              @',
              '@                                            @@@',
              '@   @@                                       @@@',
              '@@@@@@@@@                                  @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@EEEEEE@@@@@@@@@@@@@@@@@@@@@'],
             ['@@@@@@@@@@@@@@@@@@@@@@ P  @@@@@@@@@@@@@@@@@@@@@@',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                   3      3                   @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@              3tttttttttttttttt3              @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@              3tttttttttttttttt3              @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@                   3      3                   @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@@@@@@@@@@@@@@@@@@@@@@@EE@@@@@@@@@@@@@@@@@@@@@@@'],
	        ['###################### P  ######################',
              '#                                              #',
              '#                                     #        #',
              '#           #      ########      4    #        #',
              '#    4     #               ##        #         #',
              '#         #                  ##      #         #',
              '#        #                     #               #',
              '#       #                     #           4    #',
              '#       #           ###            #           #',
              '#      #          ##   ##          #           #',
              '#     #          #       #                     #',
              '#               #    4    #             ###    #',
              '#     4         #         #              ##    #',
              '#     #          #       #              ##     #',
              '#     #           ##   ##       ###            #',
              '#      #                           ##          #',
              '#      #                             #         #',
              '#       #                     #       #        #',
              '#        #          ##        #        #   4   #',
              '##        ##          #      #        #        #',
              '####  4     ###        ######         #        #',
              '##        ##          #      #       #         #',
              '#        #         ###              #     #    #',
              '#       #                         ##       #   #',
              '#      #                       ###         #   #',
              '#      #                                   #   #',
              '#     #                  5                #    #',
              '#     #                          #      ##     #',
              '#              ###              #      #       #',
              '#            ##   ##          ##      #        #',
              '#    4     ##       ###    ###        #        #',
              '#         #            ####          #     4   #',
              '#        #                           #         #',
              '#                      5                       #',
              '#                                              #',
              '#######################EE#######################'],
             ['###################### P  ######################',
              '#          #                   #          #    #',
              '#     #    #                              #    #',
              '#     #          4        ####    ####    #    #',
              '#     #    #                  ####             #',
              '#       #  #                     4     ###   ###',
              '#              ######         ##               #',
              '#                             ##    #      #   #',
              '#     4                             #      #   #',
              '#             4        #######     ##    4 #   #',
              '#                                   #      #   #',
              '#       #                     #     #     #    #',
              '#                             #          #     #',
              '#          # #  #             #         #      #',
              '#               #     4       #     ####       #',
              '#   #           #              #          #    #',
              '#   #4        #######                  ####    #',
              '#    #                                     #####',
              '#     #                           #    4  #    #',
              '#          #                       #      #    #',
              '#                                   #     #    #',
              '#                   tttcctttttc      #         #',
              '#       4       cctttttcctttttcc      #        #',
              '#    #          ttttttttttttt tt          ######',
              '#     #         ttttttttttttttt                #',
              '#      #        tttSttttt5tttttt               #',
              '#       #       ttttttttttttt tt               #',
              '#    #######    tttttttttttttttt        ###    #',
              '#               cctttttcctttttcc          #    #',
              '#               c  ttttc  ttttcc               #',
              '#       #                          4   #       #',
              '#       #   4                          #       #',
              '#       #              4               #       #',
              '#      #                                #      #',
              '#     #                                  #     #',
              '#######################EE#######################'],
             ['################################################',
              '#E     #         4            4         #     E#',
              '# 4     #                              #     4 #',
              '#        #       ##          ##       #        #',
              '#         #        ##      ##        #         #',
              '#                    ##  ##                    #',
              '#           #          ##          #           #',
              '#            #                    #            #',
              '#             #                  #             #',
              '#                       5                      #',
              '#        #  4   #              #   4  #        #',
              '#   4     #      #            #      #     4   #',
              '#          #      #    ##    #      #          #',
              '#        ####      #        #      ####        #',
              '#                   #      #                   #',
              '#                                              #',
              '#                                              #',
              '#     #           #          #     #           #',
              '#       5   #     #    P     #       5   #     #',
              '#                                              #',
              '#                                              #',
              '#                   #      #                   #',
              '#        ####      #        #      ####        #',
              '#          #      #    ##    #      #          #',
              '#   4     #      #            #      #     4   #',
              '#        #  4   #              #   4  #        #',
              '#                      5                       #',
              '#             #                  #             #',
              '#            #                    #            #',
              '#           #          ##          #           #',
              '#                    ##  ##                    #',
              '#         #        ##      ##        #         #',
              '#        #       ##          ##       #        #',
              '# 4     #                              #     4 #',
              '#E     #         4            4         #     E#',
              '################################################'],
             ['###################### P  ######################',
              '#                                              #',
              '#                   ########                   #',
              '#                 ############                 #',
              '#               ################               #',
              '#              ##################              #',
              '#             ####################             #',
              '#            ######################            #',
              '#            ######################            #',
              '#           ########################           #',
              '#           ########################           #',
              '#           ########################           #',
              '#           ## ################## ##           #',
              '#           ## ####   ####   #### ##           #',
              '#           ### ###### ## ###### ###           #',
              '#           ### ################ ###           #',
              '#            ## #    ##  ##    # ##            #',
              '#            # #       ##       # #            #',
              '#             #   4   ####   4   #             #',
              '#             #       ####       #             #',
              '#            ##      ##          ##            #',
              '#            ###   ###    ###   ###            #',
              '#            ## ##     4  #  ### ##            #',
              '#            ###   ###    ###   ###            #',
              '#             #### ### #  ### ####             #',
              '#              ## #####  ##### ##              #',
              '#                  #### #####                  #',
              '#               #  # ##  ## #  #               #',
              '#               #  # ##  ## #  #               #',
              '#               #      4       #               #',
              '#       6       #  # ##  ## #  #       6       #',
              '#                # # ##  ## # #                #',
              '#                 ###### #####                 #',
              '#                 #####  #####                 #',
              '#                   ### ####                   #',
              '#######################EE#######################'],
             ['#######################P #######################',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                        7                     #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#######################EE#######################']]
    
    levels_won = 0    
    
    walls = render_level(levels[0], assets_dir)[0]
    wall_rects = render_level(levels[0], assets_dir)[1]
    player = render_level(levels[0], assets_dir)[2][0]
    player.set_alpha(None)
    player.set_colorkey((255, 255, 255))
    player_rect = render_level(levels[0], assets_dir)[3][0]
    wall_stats = render_level(levels[0], assets_dir)[4]
    enemies = render_level(levels[0], assets_dir)[5]
    for enemy_counter in range(len(enemies)):
        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
    enemy_rects = render_level(levels[0], assets_dir)[6] 
    
    exit_blocks = []
    for wall_row_index in range(len(wall_rects)):
        for wall_column_index in range(len(wall_rects[wall_row_index])):
            if wall_stats[wall_row_index][wall_column_index] == 'exit':
                exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
    
    background = pygame.image.load(assets_dir+'walls//background1.png')    
    
    player_shot_image = pygame.image.load(shots_dir+'player_shot_1.png')
    player_shot_image.set_colorkey((255, 255, 255))
    player_speed = 5
    player_health = 30
    max_player_health = 30
    player_dmg = 1
    
    player_shots = []
    bullet_speed = 10
    bullet_delay = 0
    
    enemy_shots = []
    enemy_fire_rate = []
    for enemy in enemies:
        enemy_fire_rate.append(enemy[3].fire_rate)
    enemy_bullet_delay = [0]*len(enemies)
    explosions = []
    
    enemies_alive = [True]*len(enemies)
    
    oTimer = 0
    pTimer = 0
    iTimer = 0
    kTimer = 0
    godmode = False
    l5_boss_not_summoned = True
    clock = pygame.time.Clock()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_ESCAPE:
                return None
            elif event.type == pygame.KEYUP and event.key == pygame.K_o:
                oTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_l:
                if oTimer > 0:
                    enemies_alive = [False]*len(enemies)
                    player_rect[0] = exit_blocks[0][0]
                    player_rect[1] = exit_blocks[0][1]
            elif event.type == pygame.KEYUP and event.key == pygame.K_p:
                pTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_u:
                if pTimer > 0:
                    player_health = max_player_health
            elif event.type == pygame.KEYUP and event.key == pygame.K_i:
                iTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_j:
                if iTimer > 0:
                    if godmode == False:
                        godmode = True
                    else:
                        godmode = False
                    iTimer = 0
            elif event.type == pygame.KEYUP and event.key == pygame.K_k:
                kTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_m:
                if kTimer > 0:
                    player_dmg *= 2
        keys = pygame.key.get_pressed()
        mouse_pos = pygame.mouse.get_pos()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=(player_rect.centerx-1), centery=player_rect.centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.left > 0 and notTouchingWall:
                player_rect[0] -= player_speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=(player_rect.centerx+1), centery=player_rect.centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.right < screenWidth and notTouchingWall:
                player_rect[0] += player_speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=player_rect.centerx, centery=(player_rect.centery-1))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.top > 0 and notTouchingWall:
                player_rect[1] -= player_speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=player_rect.centerx, centery=(player_rect.centery+1))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.bottom < screenHeight and notTouchingWall:
                player_rect[1] += player_speed
        
        if pygame.mouse.get_pressed()[0] and (bullet_delay == 0):
            try:
                dx = mouse_pos[0]-player_rect.centerx
                dy = mouse_pos[1]-player_rect.centery
                x_speed = bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                y_speed = bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                if dx < 0:
                    x_speed *= -1
                if dy < 0:
                    y_speed *= -1
                #surface, rect, x-speed, y-speed
                player_shots.append([player_shot_image, player_shot_image.get_rect(centerx=player_rect.centerx, centery=player_rect.centery), x_speed, y_speed])
                bullet_delay += 40
            except:
                useless = None
        
        for player_shot_counter in range(len(player_shots)):
            if player_shots[player_shot_counter][1] != None:
                player_shots[player_shot_counter][1][0] += player_shots[player_shot_counter][2]
                player_shots[player_shot_counter][1][1] += player_shots[player_shot_counter][3]
                if (player_shots[player_shot_counter][1][0] < 1) or (player_shots[player_shot_counter][1][0] >= screenWidth) or (player_shots[player_shot_counter][1][1] < 1) or (player_shots[player_shot_counter][1][1] >= screenHeight):
                    player_shots[player_shot_counter][1] = None
                for wall_row_index in range(len(wall_rects)):
                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                            try:
                                if player_shots[player_shot_counter][1].colliderect(wall_rects[wall_row_index][wall_column_index]):
                                    player_shots[player_shot_counter][1] = None
                            except:
                                useless = None
                for enemy_counter in range(len(enemies)):
                    try:
                        if player_shots[player_shot_counter][1].colliderect(enemy_rects[enemy_counter]):
                            player_shots[player_shot_counter][1] = None
                            enemies[enemy_counter][3].health -= player_dmg
                            enemies[enemy_counter][4] = True
                    except:
                        useless = None
        
        for enemy_counter in range(len(enemies)):
            if enemy_rects[enemy_counter] != None:
                if enemies[enemy_counter][0].get_colorkey() != (255, 255, 255):
                    enemies[enemy_counter][0].set_alpha(None)
                    enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                if (math.sqrt((abs(player_rect.centerx - enemy_rects[enemy_counter].centerx)**2) + (abs(player_rect.centery - enemy_rects[enemy_counter].centery)**2)) < enemies[enemy_counter][3].fire_range) and (enemy_bullet_delay[enemy_counter] == 0):
                    if enemies[enemy_counter][3].name == 'necromancer':
                        enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), None, None, Skeleton(), True])
                        enemy_rects.append(pygame.image.load(assets_dir+'sprites//skeleton.png').get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=enemy_rects[enemy_counter].centery))
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                        enemy_bullet_delay.append(0)
                    else:
                        #surface, rect, x-speed, y-speed, life, damage, type
                        try:
                            dx = player_rect.centerx - enemy_rects[enemy_counter].centerx
                            dy = player_rect.centery - enemy_rects[enemy_counter].centery
                            x_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                            y_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                            if dx < 0:
                                x_speed *= -1
                            if dy < 0:
                                y_speed *= -1
                        except ZeroDivisionError:
                            if (player_rect.centerx - enemy_rects[enemy_counter].centerx) > 0:
                                x_speed = enemies[enemy_counter][3].bullet_speed
                                y_speed = 0
                            elif (player_rect.centerx - enemy_rects[enemy_counter].centerx) < 0:
                                x_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                y_speed = 0
                            else:
                                if (player_rect.centery - enemy_rects[enemy_counter].centery) > 0:
                                    x_speed = 0
                                    y_speed = enemies[enemy_counter][3].bullet_speed
                                else:
                                    x_speed = 0
                                    y_speed = -1 * enemies[enemy_counter][3].bullet_speed
                        if enemies[enemy_counter][3].name == 'skull':
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'explosive'])
                        else:
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                if (math.sqrt((abs(player_rect.centerx - enemy_rects[enemy_counter].centerx)**2) + (abs(player_rect.centery - enemy_rects[enemy_counter].centery)**2)) < enemies[enemy_counter][3].agro_range) or enemies[enemy_counter][4]:
                    enemies[enemy_counter][4] = True
                    if enemies[enemy_counter][3].name == 'skull':
                        try:
                            skull_x_direction = skull_x_direction
                            skull_y_direction = skull_y_direction
                        except:
                            skull_x_direction = [-1, 1][random.randint(0, 1)]
                            skull_y_direction = [-1, 1][random.randint(0, 1)]
                        if True:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx+enemies[enemy_counter][3].speed*skull_x_direction), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].right < screenWidth and notTouchingWall:
                                enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed * skull_x_direction
                            else:
                                skull_x_direction = [-1, 1][random.randint(0, 1)]
                        
                        if True:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery+enemies[enemy_counter][3].speed*skull_y_direction))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].bottom < screenHeight and notTouchingWall:
                                enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed * skull_y_direction
                            else:
                                skull_y_direction = [-1, 1][random.randint(0, 1)]
                        
                    else:
                        if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx+enemies[enemy_counter][3].speed), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].right < screenWidth and notTouchingWall:
                                enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx-enemies[enemy_counter][3].speed), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].left > 0 and notTouchingWall:
                                enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                        
                        if player_rect.centery > enemy_rects[enemy_counter].centery:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery+enemies[enemy_counter][3].speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].bottom < screenHeight and notTouchingWall:
                                enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery-enemies[enemy_counter][3].speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].top > 0 and notTouchingWall:
                                enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
        
        for enemy_shots_counter in range(len(enemy_shots)):
            if enemy_shots[enemy_shots_counter][1] != None:
                if enemy_shots[enemy_shots_counter][0].get_colorkey() != (255, 255, 255):
                    enemy_shots[enemy_shots_counter][0].set_alpha(None)
                    enemy_shots[enemy_shots_counter][0].set_colorkey((0, 0, 0, 0))
                enemy_shots[enemy_shots_counter][1][0] += enemy_shots[enemy_shots_counter][2]
                enemy_shots[enemy_shots_counter][1][1] += enemy_shots[enemy_shots_counter][3]
                if (enemy_shots[enemy_shots_counter][1][0] < 1) or (enemy_shots[enemy_shots_counter][1][0] >= screenWidth) or (enemy_shots[enemy_shots_counter][1][1] < 1) or (enemy_shots[enemy_shots_counter][1][1] >= screenHeight):
                    enemy_shots[enemy_shots_counter][1] = None
                for wall_row_index in range(len(wall_rects)):
                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                            try:
                                if enemy_shots[enemy_shots_counter][1].colliderect(wall_rects[wall_row_index][wall_column_index]):
                                    if enemy_shots[enemy_shots_counter][6] == 'explosive':
                                        explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                                    enemy_shots[enemy_shots_counter][1] = None
                            except:
                                useless = None
                try:
                    if enemy_shots[enemy_shots_counter][1].colliderect(player_rect):
                        if godmode == False:
                            player_health -= enemy_shots[enemy_shots_counter][5]
                        if enemy_shots[enemy_shots_counter][6] == 'explosive':
                            explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                        enemy_shots[enemy_shots_counter][1] = None
                except:
                    useless = None
                
        screen.fill((0, 255, 0))
        screen.blit(background, (0, 0))
        
        for wall_row_counter in range(len(walls)):
            for wall_column_counter in range(len(walls[wall_row_counter])):
                try:
                    screen.blit(walls[wall_row_counter][wall_column_counter], wall_rects[wall_row_counter][wall_column_counter])
                except:
                    useless = None        
        
        screen.blit(player, player_rect)
        
        for enemy_counter in range(len(enemies)):
            try:
                if enemies[enemy_counter][3].health > 0:
                    screen.blit(enemies[enemy_counter][0], enemy_rects[enemy_counter])
                else:
                    if enemies[enemy_counter][3].name == 'skeleton_trap' and enemy_rects[enemy_counter] != None:
                        for summon_counter in range(20):                        
                            enemies_alive.append(True)
                            enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), None, None, Skeleton(), True])
                            enemy_rects.append(pygame.image.load(assets_dir+'sprites//skeleton.png').get_rect(centerx=(enemy_rects[enemy_counter].centerx+random.randint(-100, 100)), centery=(enemy_rects[enemy_counter].centery+random.randint(-100, 100))))
                        enemy_shots = []
                        enemy_fire_rate = []
                        for enemy in enemies:
                            enemy_fire_rate.append(enemy[3].fire_rate)
                        enemy_bullet_delay = [0]*len(enemies)
                        pygame.mixer.init()
                        pygame.mixer.music.load(assets_dir+'sounds//spooky_scary_skeletons.wav')
                        pygame.mixer.music.play()
                    enemy_rects[enemy_counter] = None
                    enemies_alive[enemy_counter] = False
            except:
                useless = None
            

        for player_shot in player_shots:
            try:
                screen.blit(player_shot[0], player_shot[1])
            except:
                useless = None
        
        for enemy_shots_counter in range(len(enemy_shots)):
            try:
                enemy_shots[enemy_shots_counter][4] -= 1
            except:
                useless = None
            if enemy_shots[enemy_shots_counter][4] > 0:
                try:
                    screen.blit(enemy_shots[enemy_shots_counter][0], enemy_shots[enemy_shots_counter][1])
                except:
                    useless = None
            if (enemy_shots[enemy_shots_counter][6] == 'explosive') and (enemy_shots[enemy_shots_counter][4] == 0):
                try:
                    explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                except:
                    useless = None
            if enemy_shots[enemy_shots_counter][4] < 1:
                enemy_shots[enemy_shots_counter][1] = None
        
        for explosion in explosions:
            if explosion[2] > 0:
                explosion[2] -= 1
                explosion[0].set_colorkey((255, 255, 255))
                screen.blit(explosion[0], explosion[1])
                if explosion[1].colliderect(player_rect) and godmode == False:
                    player_health -= 1
        
        if (enemies_alive == [False]*len(enemies)) and levels_won == 4 and l5_boss_not_summoned:           
            cyclops_particles_image = Image.open(assets_dir+'animations//cyclops//particles.png')
            cyclops_particles_pil = Image.fromstring('RGBA', cyclops_particles_image.size, cyclops_particles_image.tostring())
            for counter in range(0, 30):
                cyclops_particles_pil = cyclops_particles_pil.rotate(36, Image.BICUBIC)
                cyclops_particles_pil = cyclops_particles_pil.resize((int(10*1.1**counter), int(10*1.1**counter)), Image.BICUBIC)
                cyclops_particles_frame = pygame.image.fromstring(cyclops_particles_pil.tostring(), cyclops_particles_pil.size, "RGBA")
                cyclops_particles_frame.set_alpha(None)                
                cyclops_particles_frame.set_colorkey((0, 0, 0, 0))
                screen.blit(cyclops_particles_frame, cyclops_particles_frame.get_rect(centerx=480, centery=100))
                pygame.display.flip()                
                time.sleep(0.05)
            enemies_alive.append(True)
            enemies.append([pygame.image.load(assets_dir+'sprites//cyclops.png'), None, None, Cyclops(), True])
            enemy_rects.append(pygame.image.load(assets_dir+'sprites//cyclops.png').get_rect(centerx=480, centery=100))
            enemy_shots = []
            enemy_fire_rate = []
            for enemy in enemies:
                enemy_fire_rate.append(enemy[3].fire_rate)
            enemy_bullet_delay = [0]*len(enemies)
            l5_boss_not_summoned = False
        
        for exit_block in exit_blocks:
            if player_rect.colliderect(exit_block) and (enemies_alive == [False]*len(enemies)):
                try:
                    levels_won += 1
                    walls = render_level(levels[levels_won], assets_dir)[0]
                    wall_rects = render_level(levels[levels_won], assets_dir)[1]
                    player = render_level(levels[levels_won], assets_dir)[2][0]
                    player.set_alpha(None)
                    player.set_colorkey((255, 255, 255))
                    player_rect = render_level(levels[levels_won], assets_dir)[3][0]
                    wall_stats = render_level(levels[levels_won], assets_dir)[4]
                    enemies = render_level(levels[levels_won], assets_dir)[5]
                    for enemy_counter in range(len(enemies)):
                        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                    enemy_rects = render_level(levels[levels_won], assets_dir)[6] 
                    
                    exit_blocks = []
                    for wall_row_index in range(len(wall_rects)):
                        for wall_column_index in range(len(wall_rects[wall_row_index])):
                            if wall_stats[wall_row_index][wall_column_index] == 'exit':
                                exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
    
                    player_shots = []
                    bullet_speed = 10
                    bullet_delay = 0
                    
                    enemy_shots = []
                    enemy_fire_rate = []
                    for enemy in enemies:
                        enemy_fire_rate.append(enemy[3].fire_rate)
                    enemy_bullet_delay = [0]*len(enemies)
                    enemies_alive = [True]*len(enemies)
                    explosions = []
                    
                    player_health = max_player_health
                    
                    if levels_won > 4:
                        background = pygame.image.load(assets_dir+'walls//background2.png')
                except:
                    return None
        
        if godmode:
            text('HP: '+str(player_health)+'/'+str(max_player_health), screen, [255, 0, 0], [screenWidth, 0], 30, topRight=True)
        else:
            text('HP: '+str(player_health)+'/'+str(max_player_health), screen, [0, 0, 0], [screenWidth, 0], 30, topRight=True)
        if player_health <= 0:
            return None
        
        pygame.display.flip()
        if bullet_delay > 0:
            bullet_delay -= 1
        for enemy_bullet_delay_counter in range(len(enemy_bullet_delay)):
            if enemy_bullet_delay[enemy_bullet_delay_counter] > 0:
                enemy_bullet_delay[enemy_bullet_delay_counter] -= 1
        
        if oTimer > 0:
            oTimer -= 1
        if pTimer > 0:
            pTimer -= 1
        if kTimer > 0:
            kTimer -= 1
        clock.tick(200)

assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
screens_dir = assets_dir + 'screens//'
screenSize = screenWidth, screenHeight = 960, 720
screen = pygame.display.set_mode(screenSize)
pygame.display.set_caption('Legend of Xathoebar')
icon = pygame.image.load(assets_dir+"icon.png")
pygame.display.set_icon(icon)
intro(screen)
menu_screen_list = [pygame.image.load(screens_dir+'menu_screen_play.png'), pygame.image.load(screens_dir+'menu_screen_exit.png')]
menu_screen_index = 0
menu_screen = menu_screen_list[menu_screen_index]
menu_screen_rect = menu_screen.get_rect()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN:
            if menu_screen_index < (len(menu_screen_list)-1):
                menu_screen_index += 1
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_UP:
            if menu_screen_index > 0:
                menu_screen_index -= 1
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
            if menu_screen_index == 0:
                play(screen)
                pygame.key.set_repeat()
            elif menu_screen_index == 1:
                sys.exit()
    menu_screen = menu_screen_list[menu_screen_index]
    screen.blit(menu_screen, menu_screen_rect)
    pygame.display.flip()