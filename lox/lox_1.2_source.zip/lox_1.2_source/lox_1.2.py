import pygame, sys, os, math, time, random
from PIL import Image
pygame.init()

class Goblin():
    global assets_dir
    def __init__(self):
        self.name = "goblin"
        self.ATK = 1
        self.health = 12
        self.speed = 3
        self.bullet_speed = 7
        self.bullet_life = 35
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//goblin_shot.png'))
        self.agro_range = 300
        self.fire_range = 100

class Orc():
    global assets_dir
    def __init__(self):
        self.name = "orc"
        self.ATK = 5
        self.health = 40
        self.speed = 2
        self.bullet_speed = 7
        self.bullet_life = 30
        self.fire_rate = 30
        self.bullet = (pygame.image.load(assets_dir+'shots//orc_shot.png'))
        self.agro_range = 500
        self.fire_range = 80

class DarkWizard():
    global assets_dir
    def __init__(self):
        self.name = "dark_wizard"
        self.ATK = 2
        self.health = 20
        self.speed = 0 #2
        self.bullet_speed = 10
        self.bullet_life = 90
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//dark_wizard_shot.png'))
        self.agro_range = 900
        self.fire_range = 900

class Cyclops():
    global assets_dir
    def __init__(self):
        self.name = "cyclops"
        self.ATK = 3
        self.health = 160
        self.speed = 0
        self.bullet_speed = 14
        self.bullet_life = 200
        self.fire_rate = 10
        self.bullet = (pygame.image.load(assets_dir+'shots//cyclops_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000

class Skeleton():
    global assets_dir
    def __init__(self):
        self.name = "skeleton"
        self.ATK = 1
        self.health = 8
        self.speed = 2
        self.bullet_speed = 7
        self.bullet_life = 30
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//skeleton_shot.png'))
        self.agro_range = 400
        self.fire_range = 100
        
class SkeletonKnight():
    global assets_dir
    def __init__(self):
        self.name = "skeleton_knight"
        self.ATK = 3
        self.health = 40
        self.speed = 2
        self.bullet_speed = 5
        self.bullet_life = 40
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//skeleton_knight_shot.png'))
        self.agro_range = 500
        self.fire_range = 120

class SkeletonTrap():
    global assets_dir
    def __init__(self):
        self.name = "skeleton_trap"
        self.ATK = 0
        self.health = 20
        self.speed = 0
        self.bullet_speed = 0
        self.bullet_life = 1
        self.fire_rate = 9999999
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1
        self.fire_range = 1

class Necromancer():
    global assets_dir
    def __init__(self):
        self.name = "necromancer"
        self.ATK = None
        self.health = 60
        self.speed = 1
        self.bullet_speed = None
        self.bullet_life = None
        self.fire_rate = 120
        self.bullet = None
        self.agro_range = 500
        self.fire_range = 500

class Skull():
    global assets_dir
    def __init__(self):
        self.name = "skull"
        self.ATK = 5
        self.health = 200
        self.speed = 10
        self.bullet_speed = 5
        self.bullet_life = 100
        self.fire_rate = 30
        self.bullet = (pygame.image.load(assets_dir+'shots//skull_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000

class SandWraith():
    global assets_dir
    def __init__(self):
        self.name = "sand_wraith"
        self.ATK = 1
        self.health = 40
        self.speed = 2
        self.bullet_speed = 7
        self.bullet_life = 14
        self.fire_rate = 3
        self.bullet = (pygame.image.load(assets_dir+'shots//sand_wraith_shot.png'))
        self.agro_range = 500
        self.fire_range = 100

class AngryCactus():
    global assets_dir
    def __init__(self):
        self.name = "angry_cactus"
        self.ATK = 5
        self.health = 40
        self.speed = 2
        self.bullet_speed = 14
        self.bullet_life = 30
        self.fire_rate = 40
        self.bullet = (pygame.image.load(assets_dir+'shots//angry_cactus_shot.png'))
        self.agro_range = 500
        self.fire_range = 200

class SandSnake():
    global assets_dir
    def __init__(self):
        self.name = "sand_snake"
        self.ATK = 2
        self.health = 15
        self.speed = 3
        self.bullet_speed = 7
        self.bullet_life = 14
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//sand_snake_shot.png'))
        self.agro_range = 1000
        self.fire_range = 150

class SandSnakeNest():
    global assets_dir
    def __init__(self):
        self.name = "sand_snake_nest"
        self.ATK = None
        self.health = 120
        self.speed = 0
        self.bullet_speed = None
        self.bullet_life = None
        self.fire_rate = 120
        self.bullet = None
        self.agro_range = 600
        self.fire_range = 600

class DesertWormHead():
    global assets_dir
    def __init__(self):
        self.name = "desert_worm_head"
        self.ATK = 1
        self.health = 200
        self.speed = 2
        self.bullet_speed = 14
        self.bullet_life = 8
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//desert_worm_shot.png'))
        self.agro_range = 1000
        self.fire_range = 80

class DesertWormSegment():
    global assets_dir
    def __init__(self):
        self.name = "desert_worm_segment"
        self.ATK = 1
        self.health = 9999999999999999999
        self.speed = 2
        self.bullet_speed = 2
        self.bullet_life = 5
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1000
        self.fire_range = 80

class DesertWormTail():
    global assets_dir
    def __init__(self):
        self.name = "desert_worm_tail"
        self.ATK = 1
        self.health = 9999999999999999999
        self.speed = 2
        self.bullet_speed = 2
        self.bullet_life = 5
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1000
        self.fire_range = 80

class SandPit():
    global assets_dir
    def __init__(self):
        self.name = "sand_pit"
        self.ATK = 1
        self.health = 9999999999999999999
        self.speed = 0
        self.bullet_speed = 2
        self.bullet_life = 5
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1000
        self.fire_range = 20
    
class CyclopsTurret():
    global assets_dir
    def __init__(self):
        self.name = "cyclops_turret"
        self.ATK = 5
        self.health = 9999999999999999999
        self.speed = 0
        self.bullet_speed = 10
        self.bullet_life = 100
        self.fire_rate = 25
        self.bullet = (pygame.image.load(assets_dir+'shots//cyclops_turret_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000

def text (string, screen, color, position, size, topRight=False, update=False):
    font = pygame.font.Font(None, size)
    text = font.render(string, 1, (color[0], color[1], color[2]))
    if topRight:
        textpos = text.get_rect(right=position[0], top=position[1])
    screen.blit(text, textpos)
    if update:
        pygame.display.flip()

def intro (screen):
    global assets_dir
    pygame.mixer.quit()
    video = pygame.movie.Movie(assets_dir+'intro.mpg')
    #video.set_volume(1)
    video_screen = pygame.Surface(video.get_size())

    video.set_display(video_screen)
    video.play()
    
    while video.get_busy():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
               sys.exit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
                return None
    
        screen.blit(video_screen,(0,0))
        pygame.display.update()

def render_level (wall_positions, assets_dir):
    walls = []
    wall_stats = []
    player = None
    player_rect = None
    enemies = []
    enemy_rects = []
    wall_row_index = 0
    wall_column_index = 0
    for wall_row in wall_positions:
        temp_wall_row = []
        temp_wall_stats_row = []
        for wall_column in wall_row:
            if wall_column == ' ':
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '@':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == '#':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//cave_wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == '$':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//desert_wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == 'q':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_lt.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'w':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_rt.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'e':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_lb.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'r':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_rb.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'c':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//column_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == 't':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//tile_1.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'E':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//exit.png'))
                temp_wall_stats_row.append('exit')
            if wall_column == 'P':
                player = [(pygame.image.load(assets_dir+'sprites//player.png')), True]
                temp_wall_row.append(player)
                temp_wall_stats_row.append('player')
            if wall_column == '1':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//goblin.png'), wall_column_index, wall_row_index, Goblin(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '2':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//orc.png'), wall_column_index, wall_row_index, Orc(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '3':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//dark_wizard.png'), wall_column_index, wall_row_index, DarkWizard(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '4':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), wall_column_index, wall_row_index, Skeleton(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '5':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton_knight.png'), wall_column_index, wall_row_index, SkeletonKnight(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '6':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//necromancer.png'), wall_column_index, wall_row_index, Necromancer(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '7':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skull.png'), wall_column_index, wall_row_index, Skull(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '8':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_wraith.png'), wall_column_index, wall_row_index, SandWraith(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '9':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//angry_cactus.png'), wall_column_index, wall_row_index, AngryCactus(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '0':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_snake.png'), wall_column_index, wall_row_index, SandSnake(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'Q':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_snake_nest.png'), wall_column_index, wall_row_index, SandSnakeNest(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'W':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//desert_worm_head_1.png'), wall_column_index, wall_row_index, DesertWormHead(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'R':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//desert_worm_segment.png'), wall_column_index, wall_row_index, DesertWormSegment(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'T':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//desert_worm_tail_1.png'), wall_column_index, wall_row_index, DesertWormTail(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'Y':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_pit.png'), wall_column_index, wall_row_index, SandPit(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'U':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//cyclops_turret.png'), wall_column_index, wall_row_index, CyclopsTurret(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'S':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton_trap.png'), wall_column_index, wall_row_index, SkeletonTrap(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            wall_column_index += 1
        wall_column_index = 0
        wall_row_index += 1
        walls.append(temp_wall_row)
        wall_stats.append(temp_wall_stats_row)
    wall_rects = []
    for wall_row in walls:
        temp_wall_row = []
        for wall_column in wall_row:
            try:
                temp_wall_row.append(wall_column.get_rect())
            except:
                try:
                    if wall_column[1]:
                        try:
                            player_rect = [(wall_column[0]).get_rect(), True]
                        except:
                            useless = None
                        temp_wall_row.append(player_rect)
                except:
                    temp_wall_row.append('')
        wall_rects.append(temp_wall_row)
    wall_row_x, wall_row_y = 0, 0
    for wall_row in wall_rects:
        for wall_column in wall_row:
            try:
                wall_column[0] += wall_row_x
                wall_column[1] += wall_row_y
            except:
                try:
                    wall_column[0][0] += wall_row_x
                    wall_column[0][1] += wall_row_y
                except:
                    useless = None
            wall_row_x += 20
        wall_row_x = 0
        wall_row_y += 20
    for enemy in enemies:
        enemy_rect = (enemy[0]).get_rect()
        enemy_rect[0] += (20*enemy[1])
        enemy_rect[1] += (20*enemy[2])
        enemy_rects.append(enemy_rect)
    return [walls, wall_rects, player, player_rect, wall_stats, enemies, enemy_rects]

def play (screen):
    global assets_dir
    sprites_dir = assets_dir + 'sprites//'
    shots_dir = assets_dir + 'shots//'
    
    #48 x 36
    # P - Player
    # @ - Mountain
    # # - Cave wall
    # $ - Desert Wall
    # E - Exit
    # qwer - pentagram
    # c - column 1
    # t - tile 1
    # 1 - Goblin
    # 2 - Orc
    # 3 - Dark Wizard
    # 4 - Skeleton
    # 5 - Skeleton Knight
    # S - Skeleton trap
    # 6 - Necromancer
    # 7 - Skull (boss)
    # 8 - Sand Wraith
    # 9 - Angry Cactus
    # 0 - Sand Snake
    # Q - Sand Snake Nest
    # Y - Sand Pit
    # WRT - Desert Worm
    # U - Cyclops Turret
    levels =[['P  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '     @@@@@@@@@@@@@@@@@                @@@@@@@@@@',
              '     @@@@@@@@@@@@@@@@                  @@@@@@@@@',
              '      @@@@@@@@@@@@@@@          1      @@@@@@@@@@',
              '      @@@@@@@@@@@@@@                 @@@@@@@@@@@',
              '       @@@@@@@@@@@@@        @@      @@@@@@@@@@@@',
              '       @@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@',
              '        @@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@@',
              '        @@@@@@@@@@     @@@@@@@@@@@@@@@@@@@@@@@@@',
              '                         @@@@@@@@@@@@@@@@@@@@@@@',
              '                          @@@@@@@@@@@@@@@@@@@@@@',
              '                           @@@@@@@@@@@@@@@@@@@@@',
              '                            @@@@@@@@@@@@@@@@@@@@',
              '                             @@@@@@@@@@@@@@@@@@@',
              '      @@@@@@@@@@@             @@@@@@@@@@@@@@@@@@',
              '     @@@@@@@@@@@@@             @@@@@@@@@@@@@@@@@',
              '    @       @@@@@               @@@@@@@@@@@@@@@@',
              '             @@@@@       1       @@@@@@@@@@@@@@@',
              '                @@@               @@@@@@@@@@@@@@',
              '           1     @@@               @@@@@@@@@@@@@',
              '                 @@@@@@             @@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@         @@         @@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@         @@@         @@@@@@@@@',
              '@@@@@@@      @@@@@    @@    @@@         @@@@@@@@',
              '@@@@@          @@@@    @@    @@@         @@@@@@@',
              '@@@@            @@@@    @@    @@@         @@@@@@',
              '@@@@      1      @@    @@@@    @@@         @@@@@',
              '@@@@             @@    @@@@@    @@@         @@@@',
              '@@@@@           @@@    @@@@@@    @@@         @@@',
              '@@@@@@           @@@    @@@@@@    @@@         @@',
              '@@@@@@@@@@               @@@@@@                @',
              '@@@@@@@@@@@@@            @@@@@@@                ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    EEEE'],
             ['P  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                    @@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                       @@@@@@@@@@@@@@@@@@@@@@@@',
              '@                      1   @@@@@@@@@@@@@@@@@@@@@',
              '@                             @@@@@@@@@@@@@@@@@@',
              '@         1                      @@@@@@@@@@@@@@@',
              '@                                   @@@@@@@@@@@@',
              '@                                      @@@@@@@@@',
              '@                      1                  @@@@@@',
              '@                                            @@@',
              '@         1                          1         @',
              '@                                              @',
              '@                      1                       @',
              '@                                              @',
              '@                                    1         @',
              '@                                              @',
              '@@@       1            1                       @',
              '@@@@@@                                         @',
              '@@@@@@@@@                            1         @',
              '@@@@@@@@@@@@                                   @',
              '@@@@@@@@@@@@@@@        1                       @',
              '@@@@@@@@@@@@@@@@@@                             @',
              '@@@@@@@@@@@@@@@@@@@@@                          @',
              '@@@@@@@@@@@@@@@@@@@@@@@@                       @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@                    @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                 @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@              @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@         ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@      ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  E'],
             ['@@@@@@@@@@@@@@@@@@@@@  P   @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@                  @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@           2         @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@                      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@            @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@          @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@      1      @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@           @@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@            @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@            @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@    1      @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@             @@@@      @@@@@@@@@@@  @@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@      @@@@@@',
              '@@@@@           @@@@@      @@@@@@@          @@@@',
              '@@@@@@         @@@@@@      @@@@@@     1    @@@@@',
              '@@@@@@          @@@@@      @@@@@@           @@@@',
              '@@@@@    1     @@@@@@      @@@@@@@           @@@',
              '@@@@@@       @@@@@@@@      @@@@@@@          @@@@',
              '@@@@@@@@   @@@@@@@@@@      @@@@@@          @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@            @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@      1     @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@          @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@           @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@ 222  @@@@           @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@            @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@            @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@     1    @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@            @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@                      @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@                     @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@         @@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@EEEEEE@@@@@@@@@@@@@@@@@@@@@'],
             ['@@@@@@@@@@@@@@@@@@@@@  P   @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@                                        @@@',
              '@@                                          @@@@',
              '@                                            @@@',
              '@                                             @@',
              '@                                              @',
              '@                                              @',
              '@           @@@                                @',
              '@           @ @                                @',
              '@            @                   @@            @',
              '@                               @@@@           @',
              '@                                @@@           @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                   1      1                   @',
              '@                                              @',
              '@             2       3qw3                     @',
              '@                     3er3       2             @',
              '@                                              @',
              '@                   1      1                   @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                  @           @',
              '@         @@                      @@           @',
              '@       @@@                        @@          @',
              '@        @                         @           @',
              '@                                              @',
              '@                                              @',
              '@                                            @@@',
              '@   @@                                       @@@',
              '@@@@@@@@@                                  @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@EEEEEE@@@@@@@@@@@@@@@@@@@@@'],
             ['@@@@@@@@@@@@@@@@@@@@@@ P  @@@@@@@@@@@@@@@@@@@@@@',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                   3      3                   @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@              3tttttttttttttttt3              @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@              3tttttttttttttttt3              @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@                   3      3                   @',
              '@                                              @',
              '@U                                            U@',
              '@                                              @',
              '@                                              @',
              '@@@@@@@@@@@@@@@@@@@@@@@EE@@@@@@@@@@@@@@@@@@@@@@@'],
	        ['###################### P  ######################',
              '#                                              #',
              '#                                     #        #',
              '#           #      ########      4    #        #',
              '#    4     #               ##        #         #',
              '#         #                  ##      #         #',
              '#        #                     #               #',
              '#       #                     #           4    #',
              '#       #           ###            #           #',
              '#      #          ##   ##          #           #',
              '#     #          #       #                     #',
              '#               #    4    #             ###    #',
              '#     4         #         #              ##    #',
              '#     #          #       #              ##     #',
              '#     #           ##   ##       ###            #',
              '#      #                           ##          #',
              '#      #                             #         #',
              '#       #                     #       #        #',
              '#        #          ##        #        #   4   #',
              '##        ##          #      #        #        #',
              '####  4     ###        ######         #        #',
              '##        ##          #      #       #         #',
              '#        #         ###              #     #    #',
              '#       #                         ##       #   #',
              '#      #                       ###         #   #',
              '#      #                                   #   #',
              '#     #                  5                #    #',
              '#     #                          #      ##     #',
              '#              ###              #      #       #',
              '#            ##   ##          ##      #        #',
              '#    4     ##       ###    ###        #        #',
              '#         #            ####          #     4   #',
              '#        #                           #         #',
              '#                      5                       #',
              '#                                              #',
              '#######################EE#######################'],
             ['###################### P  ######################',
              '#          #                   #          #    #',
              '#     #    #                              #    #',
              '#     #          4        ####    ####    #    #',
              '#     #    #                  ####             #',
              '#       #  #                     4     ###   ###',
              '#              ######         ##               #',
              '#                             ##    #      #   #',
              '#     4                             #      #   #',
              '#             4        #######     ##    4 #   #',
              '#                                   #      #   #',
              '#       #                     #     #     #    #',
              '#                             #          #     #',
              '#          # #  #             #         #      #',
              '#               #     4       #     ####       #',
              '#   #           #              #          #    #',
              '#   #4        #######                  ####    #',
              '#    #                                     #####',
              '#     #                           #    4  #    #',
              '#          #                       #      #    #',
              '#                                   #     #    #',
              '#                   tttcctttttc      #         #',
              '#       4       cctttttcctttttcc      #        #',
              '#    #          ttttttttttttt tt          ######',
              '#     #         ttttttttttttttt                #',
              '#      #        tttSttttt5tttttt               #',
              '#       #       ttttttttttttt tt               #',
              '#    #######    tttttttttttttttt        ###    #',
              '#               cctttttcctttttcc          #    #',
              '#               c  ttttc  ttttcc               #',
              '#       #                          4   #       #',
              '#       #   4                          #       #',
              '#       #              4               #       #',
              '#      #                                #      #',
              '#     #                                  #     #',
              '#######################EE#######################'],
             ['################################################',
              '#E     #         4            4         #     E#',
              '# 4     #                              #     4 #',
              '#        #       ##          ##       #        #',
              '#         #        ##      ##        #         #',
              '#                    ##  ##                    #',
              '#           #          ##          #           #',
              '#            #                    #            #',
              '#             #                  #             #',
              '#                       5                      #',
              '#        #  4   #              #   4  #        #',
              '#   4     #      #            #      #     4   #',
              '#          #      #    ##    #      #          #',
              '#        ####      #        #      ####        #',
              '#                   #      #                   #',
              '#                                              #',
              '#                                              #',
              '#     #           #          #     #           #',
              '#       5   #     #    P     #       5   #     #',
              '#                                              #',
              '#                                              #',
              '#                   #      #                   #',
              '#        ####      #        #      ####        #',
              '#          #      #    ##    #      #          #',
              '#   4     #      #            #      #     4   #',
              '#        #  4   #              #   4  #        #',
              '#                      5                       #',
              '#             #                  #             #',
              '#            #                    #            #',
              '#           #          ##          #           #',
              '#                    ##  ##                    #',
              '#         #        ##      ##        #         #',
              '#        #       ##          ##       #        #',
              '# 4     #                              #     4 #',
              '#E     #         4            4         #     E#',
              '################################################'],
             ['###################### P  ######################',
              '#                                              #',
              '#                   ########                   #',
              '#                 ############                 #',
              '#               ################               #',
              '#              ##################              #',
              '#             ####################             #',
              '#            ######################            #',
              '#            ######################            #',
              '#           ########################           #',
              '#           ########################           #',
              '#           ########################           #',
              '#           ## ################## ##           #',
              '#           ## ####   ####   #### ##           #',
              '#           ### ###### ## ###### ###           #',
              '#           ### ################ ###           #',
              '#            ## #    ##  ##    # ##            #',
              '#            # #       ##       # #            #',
              '#             #   4   ####   4   #             #',
              '#             #       ####       #             #',
              '#            ##      ##          ##            #',
              '#            ###   ###    ###   ###            #',
              '#            ## ##     4  #  ### ##            #',
              '#            ###   ###    ###   ###            #',
              '#             #### ### #  ### ####             #',
              '#              ## #####  ##### ##              #',
              '#                  #### #####                  #',
              '#               #  # ##  ## #  #               #',
              '#               #  # ##  ## #  #               #',
              '#               #      4       #               #',
              '#       6       #  # ##  ## #  #       6       #',
              '#                # # ##  ## # #                #',
              '#                 ###### #####                 #',
              '#                 #####  #####                 #',
              '#                   ### ####                   #',
              '#######################EE#######################'],
             ['#######################P #######################',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                        7                     #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#######################EE#######################'],
             ['$$$$$$$$$$$$$$$$$$$$$$ P  $$$$$$$$$$$$$$$$$$$$$$',
              '$                                              $',
              '$                                              $',
              '$$$$$                                          $',
              '$    $$$$                                      $',
              '$        $$$$                                  $',
              '$            $$$$                              $',
              '$                $$$$                          $',
              '$                    $$$$                      $',
              '$                        $$$$                  $',
              '$                            $$$$              $',
              '$           $                    $$$$          $',
              '$                                    $$$$      $',
              '$                                        $$$$  $',
              '$                             $                $',
              '$      $                                       $',
              '$                     9                        $',
              '$                           $                  $',
              '$                                              $',
              '$              $                               $',
              '$  $$$$                            $           $',
              '$      $$$$                                    $',
              '$          $$$$            $                   $',
              '$              $$$$                            $',
              '$                  $$$$                  $     $',
              '$                      $$$$                    $',
              '$                          $$$$                $',
              '$                              $$$$            $',
              '$                                  $$$$        $',
              '$                                      $$$$    $',
              '$               9                          $$$$$',
              '$                                              $',
              '$                                              $',
              '$$$$$$$$$$$$$$$$$$$$$$$EE$$$$$$$$$$$$$$$$$$$$$$$'],
             ['$$$$$$$$$$$$$$$$$$$$$$ P  $$$$$$$$$$$$$$$$$$$$$$',
              '$                                              $',
              '$                                              $',
              '$$$$$                                          $',
              '$    $$$$                                      $',
              '$        $$$$                                  $',
              '$            $$$$                              $',
              '$                $$$$                          $',
              '$                    $$$$                      $',
              '$                        $$$$                  $',
              '$                            $$$$              $',
              '$           $$$$$                $$$$          $',
              '$                $                   $$$$      $',
              '$        $         $                       $$$$$',
              '$       $           $           $$$            $',
              '$      $                        $              $',
              '$       $              8       $               $',
              '$        $          $         $                $',
              '$         $        $                     8     $',
              '$          $$$$$$$$                            $',
              '$  $$$$                            $           $',
              '$      $$$$                                    $',
              '$          $$$$            $                   $',
              '$              $$$$                            $',
              '$           8                            $     $',
              '$              $$$$                            $',
              '$             $            $$$$                $',
              '$              $$$$            $$$$            $',
              '$ $$$$$$$$$$       $$$$            $$$$        $',
              '$           $          $$$$            $$$$    $',
              '$            $             $$$$            $$$$$',
              '$             $                $$$$            $',
              '$                                              $',
              '$$$$$$$$$$$$$$$$$$$$$$$EE$$$$$$$$$$$$$$$$$$$$$$$'],
             ['$$$$$$$$$$$$$$$$$$$$$$$P $$$$$$$$$$$$$$$$$$$$$$$',
              '$                                              $',
              '$                                              $',
              '$                                              $',
              '$                                              $',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $                                        $',
              '$     $                                        $',
              '$      $                                       $',
              '$      $                                       $',
              '$      $                                       $',
              '$     $                                        $',
              '$     $                                        $',
              '$     $                                        $',
              '$      $                     Q                 $',
              '$      $                                       $',
              '$      $                                       $',
              '$     $                                        $',
              '$     $                                        $',
              '$     $                                        $',
              '$     $                                        $',
              '$                                              $',
              '$$$$$$$$$$$$$$$$$$$$$$$EE$$$$$$$$$$$$$$$$$$$$$$$'],
             ['#######################P #######################',
              '#                                      Y       #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#            Y                                 #',
              '#                               Y              #',
              '#                                              #',
              '#                                              #',
              '#8              9               9             8#',
              '#  Y                                           #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                   Y          #',
              '#                                              #',
              '#            Y            Y                    #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#8              9               9             8#',
              '#                            Y                 #',
              '#Y                                             #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#######################EE#######################'],
             ['#######################P #######################',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#   W                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R  R  R  R  R  R  R  R  R  R  R  R  T      #',
              '#                                              #',
              '#                                              #',
              '#######################EE#######################']]
    
    levels_won = 0    
    
    walls = render_level(levels[0], assets_dir)[0]
    wall_rects = render_level(levels[0], assets_dir)[1]
    player = render_level(levels[0], assets_dir)[2][0]
    player.set_alpha(None)
    player.set_colorkey((255, 255, 255))
    player_rect = render_level(levels[0], assets_dir)[3][0]
    wall_stats = render_level(levels[0], assets_dir)[4]
    enemies = render_level(levels[0], assets_dir)[5]
    for enemy_counter in range(len(enemies)):
        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
    enemy_rects = render_level(levels[0], assets_dir)[6] 
    
    exit_blocks = []
    for wall_row_index in range(len(wall_rects)):
        for wall_column_index in range(len(wall_rects[wall_row_index])):
            if wall_stats[wall_row_index][wall_column_index] == 'exit':
                exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
    
    background = pygame.image.load(assets_dir+'walls//background1.png')    
    
    player_shot_image = pygame.image.load(shots_dir+'player_shot_1.png')
    player_shot_image.set_colorkey((255, 255, 255))
    player_speed = 5
    player_health = 30
    max_player_health = 30
    player_dmg = 1
    
    fire_spell_used = False
    fire_spell_img = pygame.image.load(shots_dir+'player_fire_spell.png')
    fire_spell_img.set_alpha(None)
    fire_spell_img.set_colorkey((0, 0, 0))
    
    player_shots = []
    bullet_speed = 10
    bullet_delay = 0
    special_delay = 0
    uSpecials = False
    
    enemy_shots = []
    enemy_fire_rate = []
    for enemy in enemies:
        enemy_fire_rate.append(enemy[3].fire_rate)
    enemy_bullet_delay = [0]*len(enemies)
    explosions = []
    
    enemies_alive = [True]*len(enemies)
    
    pause = pygame.image.load(assets_dir+'//animations//game//pause.png')
    pause.set_alpha(None)
    pause.set_colorkey((255, 255, 255))
    pause_rect = pause.get_rect(centerx=480, centery=360)
    oTimer = 0
    pTimer = 0
    iTimer = 0
    kTimer = 0
    nTimer = 0
    godmode = False
    l5_boss_not_summoned = True
    l15_init = False
    desert_worm_ai = 'a'*360+'w'*250
    #desert_worm_ai_counter = [120, 90, 60, 30, 0]
    desert_worm_ai_counter = [600, 570, 540, 510, 480, 450, 420, 390, 360, 330, 300, 270, 240, 210, 180, 150, 120, 90, 60, 30, 0]
    clock = pygame.time.Clock()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_ESCAPE:
                return None
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_q:
                if fire_spell_used == False or uSpecials:
                    mouse_pos = pygame.mouse.get_pos()
                    dx = mouse_pos[0]-player_rect.centerx
                    dy = mouse_pos[1]-player_rect.centery
                    x_speed = bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                    y_speed = bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                    if dx < 0:
                        x_speed *= -1
                    if dy < 0:
                        y_speed *= -1
                    #surface, rect, x-speed, y-speed
                    player_shots.append([pygame.transform.rotozoom(fire_spell_img, 180 + math.degrees(math.atan2(dx, dy)), 1), fire_spell_img.get_rect(centerx=player_rect.centerx, centery=player_rect.centery), x_speed*2, y_speed*2, 'fire_spell'])
                    player_shots[len(player_shots)-1][0].set_alpha(None)
                    player_shots[len(player_shots)-1][0].set_colorkey((0, 0, 0))
                    if uSpecials == False:
                        fire_spell_used = True
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                screen.blit(pause, pause_rect)
                pygame.display.flip()
                paused = True
                while paused:
                    for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                            paused = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                if special_delay == 0 or uSpecials:
                    player_bullet_angles = [[100, 0], [100, 100], [0, 100], [-100, 100], [-100, 0], [-100, -100], [0, -100], [100, -100],
                                            [241, 100], [100, 241], [-100, 241], [-241, 100], [-100, -241], [-241, -100], [100, -241], [241, -100]]
                    for player_bullet_entry in player_bullet_angles:
                        try:
                            dx = player_bullet_entry[0]
                            dy = player_bullet_entry[1]
                            x_speed = bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                            y_speed = bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                            if dx < 0:
                                x_speed *= -1
                            if dy < 0:
                                y_speed *= -1
                        except ZeroDivisionError:
                            if dx > 0:
                                x_speed = bullet_speed
                                y_speed = 0
                            elif dx < 0:
                                x_speed = -1 * bullet_speed
                                y_speed = 0
                            else:
                                if dy > 0:
                                    x_speed = 0
                                    y_speed = bullet_speed
                                else:
                                    x_speed = 0
                                    y_speed = -1 * bullet_speed
                        player_shots.append([player_shot_image, player_shot_image.get_rect(centerx=player_rect.centerx, centery=player_rect.centery), x_speed, y_speed])
                    if uSpecials == False:
                        special_delay += 400                        
                        #enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
            elif event.type == pygame.KEYUP and event.key == pygame.K_o:
                oTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_l:
                if oTimer > 0:
                    enemies_alive = [False]*len(enemies)
                    player_rect[0] = exit_blocks[0][0]
                    player_rect[1] = exit_blocks[0][1]
            elif event.type == pygame.KEYUP and event.key == pygame.K_p:
                pTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_u:
                if pTimer > 0:
                    player_health = max_player_health
            elif event.type == pygame.KEYUP and event.key == pygame.K_i:
                iTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_j:
                if iTimer > 0:
                    if godmode == False:
                        godmode = True
                    else:
                        godmode = False
                    iTimer = 0
            elif event.type == pygame.KEYUP and event.key == pygame.K_k:
                kTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_m:
                if kTimer > 0:
                    player_dmg *= 2
            elif event.type == pygame.KEYUP and event.key == pygame.K_n:
                nTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_b:
                if nTimer > 0:
                    if uSpecials:
                        uSpecials = False
                    else:
                        uSpecials = True
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                command = input('@: ').split()
                if command[0] == 'tp':
                    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + command[1] + '//'
                elif command[0] == 'lvl':
                    try:
                        levels_won = int(command[1]) - 2
                        enemies_alive = [False]*len(enemies)
                        player_rect[0] = exit_blocks[0][0]
                        player_rect[1] = exit_blocks[0][1]
                    except:
                        print('ERROR: Cannot convert level index to int')
                elif command[0] == 'hp' or command[0] == 'health':
                    try:
                        if command[1] == '*':
                            player_health *= int(command[1])
                        elif command[1] == '+':
                            player_health += int(command[1])
                        else:
                            player_health = int(command[1])
                    except:
                        print('ERROR: Cannot covert health value to int')
                elif command[0] == 'mhp' or command[0] == 'max_health':
                    try:
                        if command[1] == '*':
                            max_player_health *= int(command[1])
                        elif command[1] == '+':
                            max_player_health += int(command[1])
                        else:
                            max_player_health = int(command[1])
                    except:
                        print('ERROR: Cannot covert max health value to int')
                elif command[0] == 'dmg' or command[0] == 'damage':
                    try:
                        if command[1] == '*':
                            player_dmg *= int(command[1])
                        elif command[1] == '+':
                            player_dmg += int(command[1])
                        else:
                            player_dmg = int(command[1])
                    except:
                        print('ERROR: Cannot covert damage value to int')
                elif command[0] == 'spd' or command[0] == 'speed':
                    try:
                        if command[1] == '*':
                            player_speed *= int(command[1])
                        elif command[1] == '+':
                            player_speed += int(command[1])
                        else:
                            player_speed = int(command[1])
                    except:
                        print('ERROR: Cannot covert speed value to int')
                else:
                    print('ERROR: Unkown command')
        keys = pygame.key.get_pressed()
        mouse_pos = pygame.mouse.get_pos()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=(player_rect.centerx-player_speed), centery=player_rect.centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.left > 0 and notTouchingWall:
                player_rect[0] -= player_speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=(player_rect.centerx+player_speed), centery=player_rect.centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.right < screenWidth and notTouchingWall:
                player_rect[0] += player_speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=player_rect.centerx, centery=(player_rect.centery-player_speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.top > 0 and notTouchingWall:
                player_rect[1] -= player_speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=player_rect.centerx, centery=(player_rect.centery+player_speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.bottom < screenHeight and notTouchingWall:
                player_rect[1] += player_speed
        
        if pygame.mouse.get_pressed()[0] and (bullet_delay == 0):
            try:
                dx = mouse_pos[0]-player_rect.centerx
                dy = mouse_pos[1]-player_rect.centery
                x_speed = bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                y_speed = bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                if dx < 0:
                    x_speed *= -1
                if dy < 0:
                    y_speed *= -1
                #surface, rect, x-speed, y-speed
                player_shots.append([player_shot_image, player_shot_image.get_rect(centerx=player_rect.centerx, centery=player_rect.centery), x_speed, y_speed])
                bullet_delay += 10
            except:
                useless = None
        
        for player_shot_counter in range(len(player_shots)):
            if player_shots[player_shot_counter][1] != None:
                player_shots[player_shot_counter][1][0] += player_shots[player_shot_counter][2]
                player_shots[player_shot_counter][1][1] += player_shots[player_shot_counter][3]
#                try:
#                    if player_shots[player_shot_counter][4] == 'fire_spell':
#                except:
#                    useless = None
                if (player_shots[player_shot_counter][1][0] < 1) or (player_shots[player_shot_counter][1][0] >= screenWidth) or (player_shots[player_shot_counter][1][1] < 1) or (player_shots[player_shot_counter][1][1] >= screenHeight):
                    player_shots[player_shot_counter][1] = None
                for wall_row_index in range(len(wall_rects)):
                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                            try:
                                if player_shots[player_shot_counter][1].colliderect(wall_rects[wall_row_index][wall_column_index]):
                                    player_shots[player_shot_counter][1] = None
                            except:
                                useless = None
                for enemy_counter in range(len(enemies)):
                    try:
                        if player_shots[player_shot_counter][1].colliderect(enemy_rects[enemy_counter]):
                            if ((enemies[enemy_counter][3].name == 'sand_snake' and math.sqrt(((enemy_rects[enemy_counter].centerx-player_rect.centerx)**2)+((enemy_rects[enemy_counter].centery-player_rect.centery)**2)) < enemies[enemy_counter][3].fire_range) or enemies[enemy_counter][3].name != 'sand_snake') and enemies[enemy_counter][3].name != 'sand_pit':
                                try:
                                    if player_shots[player_shot_counter][4] == 'fire_spell':
                                        enemies[enemy_counter][3].health -= player_dmg*5
                                except:
                                    enemies[enemy_counter][3].health -= player_dmg
                                    player_shots[player_shot_counter][1] = None
                                enemies[enemy_counter][4] = True
                    except:
                        useless = None
        
        for enemy_counter in range(len(enemies)):
            if enemy_rects[enemy_counter] != None:
                if enemies[enemy_counter][0].get_colorkey() != (255, 255, 255):
                    enemies[enemy_counter][0].set_alpha(None)
                    enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                if (math.sqrt((abs(player_rect.centerx - enemy_rects[enemy_counter].centerx)**2) + (abs(player_rect.centery - enemy_rects[enemy_counter].centery)**2)) < enemies[enemy_counter][3].fire_range) and (enemy_bullet_delay[enemy_counter] == 0):
                    if enemies[enemy_counter][3].name == 'necromancer':
                        enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), None, None, Skeleton(), True])
                        enemy_rects.append(pygame.image.load(assets_dir+'sprites//skeleton.png').get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=enemy_rects[enemy_counter].centery))
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                        enemy_bullet_delay.append(0)
                        enemies_alive.append(True)
                    elif enemies[enemy_counter][3].name == 'sand_snake_nest':
                        enemies.append([pygame.image.load(assets_dir+'sprites//sand_snake.png'), None, None, SandSnake(), True])
                        enemy_rects.append(pygame.image.load(assets_dir+'sprites//sand_snake.png').get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=enemy_rects[enemy_counter].centery))
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                        enemy_bullet_delay.append(0)
                        enemies_alive.append(True)
                    else:
                        #surface, rect, x-speed, y-speed, life, damage, type
                        try:
                            dx = player_rect.centerx - enemy_rects[enemy_counter].centerx
                            dy = player_rect.centery - enemy_rects[enemy_counter].centery
                            x_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                            y_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                            if dx < 0:
                                x_speed *= -1
                            if dy < 0:
                                y_speed *= -1
                        except ZeroDivisionError:
                            if (player_rect.centerx - enemy_rects[enemy_counter].centerx) > 0:
                                x_speed = enemies[enemy_counter][3].bullet_speed
                                y_speed = 0
                            elif (player_rect.centerx - enemy_rects[enemy_counter].centerx) < 0:
                                x_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                y_speed = 0
                            else:
                                if (player_rect.centery - enemy_rects[enemy_counter].centery) > 0:
                                    x_speed = 0
                                    y_speed = enemies[enemy_counter][3].bullet_speed
                                else:
                                    x_speed = 0
                                    y_speed = -1 * enemies[enemy_counter][3].bullet_speed
                        if enemies[enemy_counter][3].name == 'skull':
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'explosive'])
                        elif enemies[enemy_counter][3].name == 'cyclops_turret':
                            cyclops_summoned = False
                            for ct_enemy in enemies:
                                if ct_enemy[3].name == 'cyclops':
                                    cyclops_summoned = True
                            if cyclops_summoned:
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                        else:
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                            if enemies[enemy_counter][3].name == 'cyclops':
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx*0.75, dy*1.5)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed*0.75, y_speed*1.5, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx*1.5, dy*0.75)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed*1.5, y_speed*0.75, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                if (math.sqrt((abs(player_rect.centerx - enemy_rects[enemy_counter].centerx)**2) + (abs(player_rect.centery - enemy_rects[enemy_counter].centery)**2)) < enemies[enemy_counter][3].agro_range) or enemies[enemy_counter][4]:
                    enemies[enemy_counter][4] = True
                    if enemies[enemy_counter][3].name == 'skull':
                        try:
                            skull_x_direction = skull_x_direction
                            skull_y_direction = skull_y_direction
                        except:
                            skull_x_direction = [-1, 1][random.randint(0, 1)]
                            skull_y_direction = [-1, 1][random.randint(0, 1)]
                        if True:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx+enemies[enemy_counter][3].speed*skull_x_direction), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].right < screenWidth and notTouchingWall:
                                enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed * skull_x_direction
                            else:
                                skull_x_direction = [-1, 1][random.randint(0, 1)]
                        
                        if True:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery+enemies[enemy_counter][3].speed*skull_y_direction))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].bottom < screenHeight and notTouchingWall:
                                enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed * skull_y_direction
                            else:
                                skull_y_direction = [-1, 1][random.randint(0, 1)]
                    elif enemies[enemy_counter][3].name == 'cyclops_turret':
                        noneLeft = True
                        for ct_enemy_counter in range(len(enemies)):
                            if enemies[ct_enemy_counter][3].name != 'cyclops_turret' and enemies[ct_enemy_counter][3].health > 0 and enemy_rects[ct_enemy_counter] != None:
                                noneLeft = False
                        if noneLeft and l5_boss_not_summoned == False:
                            enemies[enemy_counter][3].health = 0
                            enemy_rects[enemy_counter] = None
                    elif enemies[enemy_counter][3].name == 'sand_wraith':
                        if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                            enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                        else:
                            enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                        if (player_rect.centery > enemy_rects[enemy_counter].centery):
                            enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                        else:
                            enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
                    elif enemies[enemy_counter][3].name == 'sand_pit':
                        if player_rect.colliderect(enemy_rects[enemy_counter]):
                            if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                                player_rect[0] -= 1
                            else:
                                player_rect[0] += 1
                            if (player_rect.centery > enemy_rects[enemy_counter].centery):
                                player_rect[1] -= 1
                            else:
                                player_rect[1] += 1
                        noneLeft = True
                        for pit_enemy_counter in range(len(enemies)):
                            if enemies[pit_enemy_counter][3].name != 'sand_pit' and enemies[pit_enemy_counter][3].health > 0 and enemy_rects[pit_enemy_counter] != None:
                                noneLeft = False
                        if noneLeft:
                            sand_pits = []
                            for sp_enemy_counter in range(len(enemies)):
                                if enemies[sp_enemy_counter][3].name == 'sand_pit':
                                    sand_pits.append([enemies[sp_enemy_counter], enemy_rects[sp_enemy_counter]])
                            
                            for sand_pit_counter in range(len(sand_pits)):
                                enemies[sand_pit_counter][3].health = 0
                            for _ in range(15):
                                for sand_pit_counter in range(len(sand_pits)):
                                    sand_pits[sand_pit_counter][0][0] = pygame.transform.rotozoom(sand_pits[sand_pit_counter][0][0], 0, (15-_)/15)
                                    sand_pits[sand_pit_counter][0][0].set_alpha(None)
                                    sand_pits[sand_pit_counter][0][0].set_colorkey((255, 255, 255))
                                screen.fill((0, 0, 0))
                                screen.blit(background, (0, 0))
                                for wall_row_counter in range(len(walls)):
                                    for wall_column_counter in range(len(walls[wall_row_counter])):
                                        try:
                                            screen.blit(walls[wall_row_counter][wall_column_counter], wall_rects[wall_row_counter][wall_column_counter])
                                        except:
                                            useless = None
                                screen.blit(player, player_rect)
                                for sand_pit_counter in range(len(sand_pits)):
                                    try:                                    
                                        screen.blit(sand_pits[sand_pit_counter][0][0], enemies[sand_pit_counter][0].get_rect(centerx=sand_pits[sand_pit_counter][1].centerx, centery=sand_pits[sand_pit_counter][1].centery))
                                    except:
                                        useless = None
                                pygame.display.flip()
                                time.sleep(0.1333)
                            for sand_pit_counter in range(len(sand_pits)):
                                enemy_rects[sand_pit_counter] = None
                            levels_won += 1
                            walls = render_level(levels[levels_won], assets_dir)[0]
                            wall_rects = render_level(levels[levels_won], assets_dir)[1]
                            player = render_level(levels[levels_won], assets_dir)[2][0]
                            player.set_alpha(None)
                            player.set_colorkey((255, 255, 255))
                            player_rect = render_level(levels[levels_won], assets_dir)[3][0]
                            wall_stats = render_level(levels[levels_won], assets_dir)[4]
                            enemies = render_level(levels[levels_won], assets_dir)[5]
                            for enemy_counter in range(len(enemies)):
                                enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                            enemy_rects = render_level(levels[levels_won], assets_dir)[6] 
                            
                            exit_blocks = []
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'exit':
                                        exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
            
                            player_shots = []
                            bullet_speed = 10
                            bullet_delay = 0
                            fire_spell_used = False
                            
                            enemy_shots = []
                            enemy_fire_rate = []
                            for enemy in enemies:
                                enemy_fire_rate.append(enemy[3].fire_rate)
                            enemy_bullet_delay = [0]*len(enemies)
                            enemies_alive = [True]*len(enemies)
                            explosions = []
                            
                            player_health = max_player_health
                            
                            if levels_won > 4:
                                background = pygame.image.load(assets_dir+'walls//background2.png')
                            if levels_won > 9:
                                background = pygame.image.load(assets_dir+'walls//background3.png')
                            break
                    elif enemies[enemy_counter][3].name == 'desert_worm_head':
                        if desert_worm_ai[desert_worm_ai_counter[0]] == 'w':
                            enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_1.png')
                        elif desert_worm_ai[desert_worm_ai_counter[0]] == 's':
                            enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_3.png')
                        elif desert_worm_ai[desert_worm_ai_counter[0]] == 'a':
                            enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_4.png')
                        elif desert_worm_ai[desert_worm_ai_counter[0]] == 'd':
                            enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_2.png')
                        enemies[enemy_counter][0].set_alpha(None)
                        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                        desert_worm_ai_counter[0] += 1
                        
                        dx = math.fabs(player_rect.centerx - enemy_rects[enemy_counter].centerx)
                        dy = math.fabs(player_rect.centery - enemy_rects[enemy_counter].centery)
                        if dx > dy:
                            if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                                desert_worm_ai += 'd'
                            else:
                                desert_worm_ai += 'a'
                        else:
                            if (player_rect.centery > enemy_rects[enemy_counter].centery):
                                desert_worm_ai += 's'
                            else:
                                desert_worm_ai += 'w'
                    elif enemies[enemy_counter][3].name == 'desert_worm_segment' or enemies[enemy_counter][3].name == 'desert_worm_tail':
                        if desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 'w':
                            enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_1.png')
                        elif desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 's':
                            enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_3.png')
                        elif desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 'a':
                            enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_4.png')
                        elif desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 'd':
                            enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_2.png')
                        enemies[enemy_counter][0].set_alpha(None)
                        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                        desert_worm_ai_counter[enemy_counter] += 1
                    else:
                        if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx+enemies[enemy_counter][3].speed), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].right < screenWidth and notTouchingWall:
                                enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx-enemies[enemy_counter][3].speed), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].left > 0 and notTouchingWall:
                                enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                        
                        if player_rect.centery > enemy_rects[enemy_counter].centery:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery+enemies[enemy_counter][3].speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].bottom < screenHeight and notTouchingWall:
                                enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery-enemies[enemy_counter][3].speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].top > 0 and notTouchingWall:
                                enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
        
        for enemy_shots_counter in range(len(enemy_shots)):
            if enemy_shots[enemy_shots_counter][1] != None:
                if enemy_shots[enemy_shots_counter][0].get_colorkey() != (255, 255, 255):
                    enemy_shots[enemy_shots_counter][0].set_alpha(None)
                    enemy_shots[enemy_shots_counter][0].set_colorkey((0, 0, 0, 0))
                enemy_shots[enemy_shots_counter][1][0] += enemy_shots[enemy_shots_counter][2]
                enemy_shots[enemy_shots_counter][1][1] += enemy_shots[enemy_shots_counter][3]
                if (enemy_shots[enemy_shots_counter][1][0] < 1) or (enemy_shots[enemy_shots_counter][1][0] >= screenWidth) or (enemy_shots[enemy_shots_counter][1][1] < 1) or (enemy_shots[enemy_shots_counter][1][1] >= screenHeight):
                    enemy_shots[enemy_shots_counter][1] = None
                for wall_row_index in range(len(wall_rects)):
                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                            try:
                                if enemy_shots[enemy_shots_counter][1].colliderect(wall_rects[wall_row_index][wall_column_index]):
                                    if enemy_shots[enemy_shots_counter][6] == 'explosive':
                                        explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                                    enemy_shots[enemy_shots_counter][1] = None
                            except:
                                useless = None
                try:
                    if enemy_shots[enemy_shots_counter][1].colliderect(player_rect):
                        if godmode == False:
                            player_health -= enemy_shots[enemy_shots_counter][5]
                        if enemy_shots[enemy_shots_counter][6] == 'explosive':
                            explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                        enemy_shots[enemy_shots_counter][1] = None
                except:
                    useless = None
                
        screen.fill((0, 255, 0))
        screen.blit(background, (0, 0))
        
        for wall_row_counter in range(len(walls)):
            for wall_column_counter in range(len(walls[wall_row_counter])):
                try:
                    screen.blit(walls[wall_row_counter][wall_column_counter], wall_rects[wall_row_counter][wall_column_counter])
                except:
                    useless = None        
        
#        screen.blit(player, player_rect)
        for enemy_counter in range(len(enemies)):
            if enemies[enemy_counter][3].name == 'sand_pit' and enemies[enemy_counter][3].health > 0 and enemy_rects[enemy_counter] != None:
                screen.blit(enemies[enemy_counter][0], enemy_rects[enemy_counter])
        
        for enemy_counter in range(len(enemies)):
            try:
                if enemies[enemy_counter][3].name == 'sand_snake':
                    if enemy_rects[enemy_counter].centerx > player_rect.centerx:
                        enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//sand_snake.png')
                    else:
                        enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//sand_snake_2.png')
                    enemies[enemy_counter][0].set_alpha(None)
                    enemies[enemy_counter][0].set_colorkey((255, 255, 255))
            except:
                useless = None
            try:
#                if levels_won == 14:
#                    for enemy_counter_2 in range(len(enemies)):
#                        if enemies[enemy_counter_2][3].name == 'sand_pit' and enemies[enemy_counter_2][3].health > 0:
#                            screen.blit(enemies[enemy_counter_2][0], enemy_rects[enemy_counter_2])
#                    for enemy_counter_2 in range(len(enemies)):
#                        if enemies[enemy_counter_2][3].name != 'sand_pit' and enemies[enemy_counter_2][3].health > 0:
#                            screen.blit(enemies[enemy_counter_2][0], enemy_rects[enemy_counter_2])
#                    pygame.display.flip()
                if enemies[enemy_counter][3].name != 'sand_pit':
                    if enemies[enemy_counter][3].health > 0 and enemy_rects[enemy_counter] != None:
                        screen.blit(enemies[enemy_counter][0], enemy_rects[enemy_counter])
                    else:
                        if enemies[enemy_counter][3].name == 'skeleton_trap' and enemy_rects[enemy_counter] != None:
                            for summon_counter in range(20):                        
                                summoned_skeleton_rect = pygame.image.load(assets_dir+'sprites//skeleton.png').get_rect(centerx=(enemy_rects[enemy_counter].centerx+random.randint(-100, 100)), centery=(enemy_rects[enemy_counter].centery+random.randint(-100, 100)))
                                summoned_skeleton_rect_not_touching = True
                                for wall_row_index in range(len(wall_rects)):
                                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                            try:
                                                if summoned_skeleton_rect.colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                    summoned_skeleton_rect_not_touching = False
                                            except:
                                                useless = None
                                if summoned_skeleton_rect_not_touching:
                                    enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), None, None, Skeleton(), True])                            
                                    enemy_rects.append(summoned_skeleton_rect)
                                    enemies_alive.append(True)
                            enemy_shots = []
                            enemy_fire_rate = []
                            for enemy in enemies:
                                enemy_fire_rate.append(enemy[3].fire_rate)
                            enemy_bullet_delay = [0]*len(enemies)
                            pygame.mixer.init()
                            pygame.mixer.music.load(assets_dir+'sounds//spooky_scary_skeletons.wav')
                            pygame.mixer.music.play()
                        if enemies[enemy_counter][3].name == 'angry_cactus' and enemy_rects[enemy_counter] != None:
                            for cactus_bullet_entry in [[100, 0], [100, 100], [0, 100], [-100, 100], [-100, 0], [-100, -100], [0, -100], [100, -100]]:
                                try:
                                    dx = cactus_bullet_entry[0]
                                    dy = cactus_bullet_entry[1]
                                    x_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                                    y_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                                    if dx < 0:
                                        x_speed *= -1
                                    if dy < 0:
                                        y_speed *= -1
                                except ZeroDivisionError:
                                    if dx > 0:
                                        x_speed = enemies[enemy_counter][3].bullet_speed
                                        y_speed = 0
                                    elif dx < 0:
                                        x_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                        y_speed = 0
                                    else:
                                        if dy > 0:
                                            x_speed = 0
                                            y_speed = enemies[enemy_counter][3].bullet_speed
                                        else:
                                            x_speed = 0
                                            y_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                        enemy_rects[enemy_counter] = None
    #                    if enemies[enemy_counter][2] != None:
                        enemies_alive[enemy_counter] = False
            except:
                useless = None
                
        screen.blit(player, player_rect)

        for player_shot in player_shots:
            try:
                screen.blit(player_shot[0], player_shot[1])
            except:
                useless = None
        
        for enemy_shots_counter in range(len(enemy_shots)):
            try:
                enemy_shots[enemy_shots_counter][4] -= 1
            except:
                useless = None
            if enemy_shots[enemy_shots_counter][4] > 0:
                try:
                    screen.blit(enemy_shots[enemy_shots_counter][0], enemy_shots[enemy_shots_counter][1])
                except:
                    useless = None
            if (enemy_shots[enemy_shots_counter][6] == 'explosive') and (enemy_shots[enemy_shots_counter][4] == 0):
                try:
                    explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                except:
                    useless = None
            if enemy_shots[enemy_shots_counter][4] < 1:
                enemy_shots[enemy_shots_counter][1] = None
        
        for explosion in explosions:
            if explosion[2] > 0:
                explosion[2] -= 1
                explosion[0].set_colorkey((255, 255, 255))
                screen.blit(explosion[0], explosion[1])
                if explosion[1].colliderect(player_rect) and godmode == False:
                    player_health -= 1
        
        if (enemies_alive == [False]*(len(enemies)-2) + [True]*(2)) and levels_won == 4 and l5_boss_not_summoned:           
            cyclops_particles_image = Image.open(assets_dir+'animations//cyclops//particles.png')
            cyclops_particles_pil = Image.fromstring('RGBA', cyclops_particles_image.size, cyclops_particles_image.tostring())
            for counter in range(0, 30):
                cyclops_particles_pil = cyclops_particles_pil.rotate(36, Image.BICUBIC)
                cyclops_particles_pil = cyclops_particles_pil.resize((int(10*1.1**counter), int(10*1.1**counter)), Image.BICUBIC)
                cyclops_particles_frame = pygame.image.fromstring(cyclops_particles_pil.tostring(), cyclops_particles_pil.size, "RGBA")
                cyclops_particles_frame.set_alpha(None)                
                cyclops_particles_frame.set_colorkey((0, 0, 0, 0))
                screen.blit(cyclops_particles_frame, cyclops_particles_frame.get_rect(centerx=480, centery=100))
                pygame.display.flip()                
                time.sleep(0.05)
            enemies_alive.append(True)
            enemies.append([pygame.image.load(assets_dir+'sprites//cyclops.png'), None, None, Cyclops(), True])
            enemy_rects.append(pygame.image.load(assets_dir+'sprites//cyclops.png').get_rect(centerx=480, centery=100))
            enemy_shots = []
            enemy_fire_rate = []
            for enemy in enemies:
                enemy_fire_rate.append(enemy[3].fire_rate)
            enemy_bullet_delay = [0]*len(enemies)
            l5_boss_not_summoned = False
        
        if l15_init == False and levels_won == 14:
            l15_init = True
            sand_pit_coords = [(120, 300), (440, 350), (560, 560), (160, 200), (370, 580), (600, 190), (800, 600), (200, 550), (800, 300), (400, 200)]
            for sand_pit_coord in sand_pit_coords:
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_pit.png'), None, None, SandPit(), True])
                enemy_rects.append(pygame.image.load(assets_dir+'sprites//sand_pit.png').get_rect(centerx=sand_pit_coord[0], centery=sand_pit_coord[1]))
                enemy_bullet_delay.append(0)
                enemies_alive.append(True)
        
        for enemy_counter in range(len(enemies)):
            if enemies[enemy_counter][3].name == 'desert_worm_head' and enemies[enemy_counter][3].health < 1:
                enemies_alive = [False]*len(enemies)
                dw_explosion = pygame.image.load(assets_dir+'animations//desert_worm//explosion.png')
                dw_explosion.set_alpha(None)
                dw_explosion.set_colorkey((0, 0, 0))
                for _ in range(30):
#                    r_enemy_rect = None
#                    while r_enemy_rect == None:
#                        r_enemy_rect = random.choice(enemy_rects)
                    r_enemy_rect = None
                    while r_enemy_rect == None:
                        r_enemy_index = random.randint(0, len(enemies)-1)
                        if enemies[r_enemy_index][3].name != 'sand_pit' and enemy_rects[r_enemy_index] != None:
                            r_enemy_rect = enemy_rects[r_enemy_index]
                    screen.blit(dw_explosion, dw_explosion.get_rect(centerx=r_enemy_rect.centerx+random.randint(-15, 15), centery=r_enemy_rect.centery+random.randint(-15, 15)))
                    pygame.display.flip()
                    time.sleep(0.075)
                for enemy_rect_counter in range(len(enemy_rects)):
                    enemy_rects[enemy_rect_counter] = None
                player_rect[0] = exit_blocks[0][0]
                player_rect[1] = exit_blocks[0][1]
                #print('a')
        
        for exit_block in exit_blocks:
            if player_rect.colliderect(exit_block) and (enemies_alive == [False]*len(enemies)):
                print('b')
                try:
                    levels_won += 1
                    walls = render_level(levels[levels_won], assets_dir)[0]
                    wall_rects = render_level(levels[levels_won], assets_dir)[1]
                    player = render_level(levels[levels_won], assets_dir)[2][0]
                    player.set_alpha(None)
                    player.set_colorkey((255, 255, 255))
                    player_rect = render_level(levels[levels_won], assets_dir)[3][0]
                    wall_stats = render_level(levels[levels_won], assets_dir)[4]
                    enemies = render_level(levels[levels_won], assets_dir)[5]
                    for enemy_counter in range(len(enemies)):
                        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                    enemy_rects = render_level(levels[levels_won], assets_dir)[6] 
                    
                    exit_blocks = []
                    for wall_row_index in range(len(wall_rects)):
                        for wall_column_index in range(len(wall_rects[wall_row_index])):
                            if wall_stats[wall_row_index][wall_column_index] == 'exit':
                                exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
    
                    player_shots = []
                    bullet_speed = 10
                    bullet_delay = 0
                    fire_spell_used = False
                    
                    enemy_shots = []
                    enemy_fire_rate = []
                    for enemy in enemies:
                        enemy_fire_rate.append(enemy[3].fire_rate)
                    enemy_bullet_delay = [0]*len(enemies)
                    enemies_alive = [True]*len(enemies)
                    explosions = []
                    
                    player_health = max_player_health
                    
                    if levels_won > 4:
                        background = pygame.image.load(assets_dir+'walls//background2.png')
                    if levels_won > 9:
                        background = pygame.image.load(assets_dir+'walls//background3.png')
                except:
                    return None
        
        if godmode:
            text('HP: '+str(player_health)+'/'+str(max_player_health), screen, [255, 0, 0], [screenWidth, 0], 30, topRight=True)
        else:
            text('HP: '+str(player_health)+'/'+str(max_player_health), screen, [0, 0, 0], [screenWidth, 0], 30, topRight=True)

        if special_delay > 0:
            text('SATK: '+str((400-special_delay)//4)+'%', screen, [0, 0, 0], [screenWidth, 35], 30, topRight=True)
        else:
            text('SATK: 100%', screen, [255, 0, 0], [screenWidth, 35], 30, topRight=True)
        
        if player_dmg > 10:
            text('DMG: x'+str(player_dmg), screen, [255, 0, 0], [screenWidth, 70], 30, topRight=True)
        elif player_dmg > 1:
            text('DMG: x'+str(player_dmg), screen, [0, 0, 0], [screenWidth, 70], 30, topRight=True)
        
        if fire_spell_used == False:
            screen.blit(fire_spell_img, fire_spell_img.get_rect(top=0, right=860))
        if player_health <= 0:
            return None
        
        pygame.display.flip()
        if bullet_delay > 0:
            bullet_delay -= 1
        if special_delay > 0:
            special_delay -= 1
        for enemy_bullet_delay_counter in range(len(enemy_bullet_delay)):
            if enemy_bullet_delay[enemy_bullet_delay_counter] > 0:
                enemy_bullet_delay[enemy_bullet_delay_counter] -= 1
        
        if oTimer > 0:
            oTimer -= 1
        if pTimer > 0:
            pTimer -= 1
        if kTimer > 0:
            kTimer -= 1
        if iTimer > 0:
            iTimer -= 1
        if nTimer > 0:
            nTimer -= 1
        clock.tick(200)

assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
screens_dir = assets_dir + 'screens//'
screenSize = screenWidth, screenHeight = 960, 720
screen = pygame.display.set_mode(screenSize)
pygame.display.set_caption('Legend of Xathoebar')
icon = pygame.image.load(assets_dir+"icon.png")
pygame.display.set_icon(icon)
intro(screen)
menu_screen_list = [pygame.image.load(screens_dir+'menu_screen_play.png'), pygame.image.load(screens_dir+'menu_screen_exit.png')]
menu_screen_index = 0
menu_screen = menu_screen_list[menu_screen_index]
menu_screen_rect = menu_screen.get_rect()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN:
            if menu_screen_index < (len(menu_screen_list)-1):
                menu_screen_index += 1
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_UP:
            if menu_screen_index > 0:
                menu_screen_index -= 1
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
            if menu_screen_index == 0:
                play(screen)
                pygame.key.set_repeat()
            elif menu_screen_index == 1:
                sys.exit()
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
            command = input('@: ').split()
            if command[0] == 'tp':
                assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + command[1] + '//'
            else:
                print('ERROR: Unkown command')
    menu_screen = menu_screen_list[menu_screen_index]
    screen.blit(menu_screen, menu_screen_rect)
    pygame.display.flip()