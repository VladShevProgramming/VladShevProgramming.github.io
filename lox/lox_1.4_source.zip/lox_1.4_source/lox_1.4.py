import pygame, sys, os, math, time, random, glob
from PIL import Image
pygame.init()

class Goblin():
    global assets_dir
    global modEnemyChanges
    def __init__(self):
        self.name = "goblin"
        self.ATK = 1
        self.health = 12
        self.speed = 3
        self.bullet_speed = 7
        self.bullet_life = 35
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//goblin_shot.png'))
        self.agro_range = 300
        self.fire_range = 100
        self.xp = [5, 15]
        self.money = [10, 20]
        
        for mod in modEnemyChanges:
            if mod[0] == 'Goblin':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                        

class Orc():
    global assets_dir
    def __init__(self):
        self.name = "orc"
        self.ATK = 5
        self.health = 40
        self.speed = 2
        self.bullet_speed = 7
        self.bullet_life = 30
        self.fire_rate = 30
        self.bullet = (pygame.image.load(assets_dir+'shots//orc_shot.png'))
        self.agro_range = 500
        self.fire_range = 120
        self.xp = [40, 60]
        self.money = [40, 60]
        
        for mod in modEnemyChanges:
            if mod[0] == 'Orc':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class DarkWizard():
    global assets_dir
    def __init__(self):
        self.name = "dark_wizard"
        self.ATK = 4
        self.health = 30
        self.speed = 0 #2
        self.bullet_speed = 10
        self.bullet_life = 90
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//dark_wizard_shot.png'))
        self.agro_range = 900
        self.fire_range = 900
        self.xp = [80, 120]
        self.money = [80, 120]
        
        for mod in modEnemyChanges:
            if mod[0] == 'DarkWizard':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class Cyclops():
    global assets_dir
    def __init__(self):
        self.name = "cyclops"
        self.ATK = 4
        self.health = 200
        self.speed = 0
        self.bullet_speed = 14
        self.bullet_life = 200
        self.fire_rate = 10
        self.bullet = (pygame.image.load(assets_dir+'shots//cyclops_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000
        self.xp = [400, 400]
        self.money = [400, 400]
        
        for mod in modEnemyChanges:
            if mod[0] == 'Cyclops':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class Skeleton():
    global assets_dir
    def __init__(self):
        self.name = "skeleton"
        self.ATK = 2
        self.health = 15
        self.speed = 2
        self.bullet_speed = 7
        self.bullet_life = 30
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//skeleton_shot.png'))
        self.agro_range = 400
        self.fire_range = 150
        self.xp = [10, 20]
        self.money = [15, 30]
        
        for mod in modEnemyChanges:
            if mod[0] == 'Skeleton':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]
        
class SkeletonKnight():
    global assets_dir
    def __init__(self):
        self.name = "skeleton_knight"
        self.ATK = 8
        self.health = 50
        self.speed = 2
        self.bullet_speed = 6
        self.bullet_life = 40
        self.fire_rate = 50
        self.bullet = (pygame.image.load(assets_dir+'shots//skeleton_knight_shot.png'))
        self.agro_range = 500
        self.fire_range = 120
        self.xp = [50, 90]
        self.money = [50, 90]
        
        for mod in modEnemyChanges:
            if mod[0] == 'SkeletonKnight':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class SkeletonTrap():
    global assets_dir
    def __init__(self):
        self.name = "skeleton_trap"
        self.ATK = 0
        self.health = 20
        self.speed = 0
        self.bullet_speed = 0
        self.bullet_life = 1
        self.fire_rate = 9999999
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1
        self.fire_range = 1
        self.xp = [0, 0]
        self.money = [0, 0]
        
        for mod in modEnemyChanges:
            if mod[0] == 'SkeletonTrap':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class Necromancer():
    global assets_dir
    def __init__(self):
        self.name = "necromancer"
        self.ATK = None
        self.health = 100
        self.speed = 1
        self.bullet_speed = None
        self.bullet_life = None
        self.fire_rate = 80
        self.bullet = None
        self.agro_range = 500
        self.fire_range = 500
        self.xp = [120, 170]
        self.money = [120, 170]
        
        for mod in modEnemyChanges:
            if mod[0] == 'Necromancer':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class Skull():
    global assets_dir
    def __init__(self):
        self.name = "skull"
        self.ATK = 5
        self.health = 300
        self.speed = 10
        self.bullet_speed = 5
        self.bullet_life = 100
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//skull_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000
        self.xp = [2000, 2000]
        self.money = [2000, 2000]
        
        for mod in modEnemyChanges:
            if mod[0] == 'Skull':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class SandWraith():
    global assets_dir
    def __init__(self):
        self.name = "sand_wraith"
        self.ATK = 3
        self.health = 80
        self.speed = 3
        self.bullet_speed = 7
        self.bullet_life = 14
        self.fire_rate = 3
        self.bullet = (pygame.image.load(assets_dir+'shots//sand_wraith_shot.png'))
        self.agro_range = 500
        self.fire_range = 100
        self.xp = [200, 300]
        self.money = [250, 350]
        
        for mod in modEnemyChanges:
            if mod[0] == 'SandWraith':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class AngryCactus():
    global assets_dir
    def __init__(self):
        self.name = "angry_cactus"
        self.ATK = 7
        self.health = 80
        self.speed = 3
        self.bullet_speed = 14
        self.bullet_life = 30
        self.fire_rate = 40
        self.bullet = (pygame.image.load(assets_dir+'shots//angry_cactus_shot.png'))
        self.agro_range = 500
        self.fire_range = 200
        self.xp = [200, 300]
        self.money = [250, 350]
        
        for mod in modEnemyChanges:
            if mod[0] == 'AngryCactus':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class SandSnake():
    global assets_dir
    def __init__(self):
        self.name = "sand_snake"
        self.ATK = 4
        self.health = 20
        self.speed = 4
        self.bullet_speed = 7
        self.bullet_life = 14
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//sand_snake_shot.png'))
        self.agro_range = 1000
        self.fire_range = 150
        self.xp = [15, 25]
        self.money = [20, 30]
        
        for mod in modEnemyChanges:
            if mod[0] == 'SandSnake':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class SandSnakeNest():
    global assets_dir
    def __init__(self):
        self.name = "sand_snake_nest"
        self.ATK = None
        self.health = 200
        self.speed = 0
        self.bullet_speed = None
        self.bullet_life = None
        self.fire_rate = 100
        self.bullet = None
        self.agro_range = 600
        self.fire_range = 600
        self.xp = [400, 400]
        self.money = [500, 500]
        
        for mod in modEnemyChanges:
            if mod[0] == 'SandSnakeNest':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class DesertWormHead():
    global assets_dir
    def __init__(self):
        self.name = "desert_worm_head"
        self.ATK = 0
        self.health = 3000
        self.speed = 2
        self.bullet_speed = 10
        self.bullet_life = 45
        self.fire_rate = 12
        self.bullet = (pygame.image.load(assets_dir+'shots//desert_worm_shot.png'))
        self.agro_range = 1000
        self.fire_range = 350
        self.xp = [5000, 5000]
        self.money = [5000, 5000]
        
        for mod in modEnemyChanges:
            if mod[0] == 'DesertWormHead':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class DesertWormSegment():
    global assets_dir
    def __init__(self):
        self.name = "desert_worm_segment"
        self.ATK = 1
        self.health = 9999999999999999999
        self.speed = 2
        self.bullet_speed = 2
        self.bullet_life = 5
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1000
        self.fire_range = 80
        self.xp = [0, 0]
        self.money = [0, 0]
        
        for mod in modEnemyChanges:
            if mod[0] == 'DesertWormSegment':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class DesertWormTail():
    global assets_dir
    def __init__(self):
        self.name = "desert_worm_tail"
        self.ATK = 1
        self.health = 9999999999999999999
        self.speed = 2
        self.bullet_speed = 2
        self.bullet_life = 5
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1000
        self.fire_range = 80
        self.xp = [0, 0]
        self.money = [0, 0]
        
        for mod in modEnemyChanges:
            if mod[0] == 'DesertWormTail':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class SandPit():
    global assets_dir
    def __init__(self):
        self.name = "sand_pit"
        self.ATK = 2
        self.health = 9999999999999999999
        self.speed = 0
        self.bullet_speed = 2
        self.bullet_life = 5
        self.fire_rate = 4
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1000
        self.fire_range = 20
        self.xp = [0, 0]
        self.money = [0, 0]
        
        for mod in modEnemyChanges:
            if mod[0] == 'SandPit':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]
    
class CyclopsTurret():
    global assets_dir
    def __init__(self):
        self.name = "cyclops_turret"
        self.ATK = 5
        self.health = 9999999999999999999
        self.speed = 0
        self.bullet_speed = 10
        self.bullet_life = 100
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//cyclops_turret_shot.png'))
        self.agro_range = 1000
        self.fire_range = 1000
        self.xp = [0, 0]
        self.money = [0, 0]
        
        for mod in modEnemyChanges:
            if mod[0] == 'CyclopsTurret':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class ShearBackBeetle():
    global assets_dir
    def __init__(self):
        self.name = "shear_back_beetle"
        self.ATK = 20
        self.health = 150
        self.speed = 3
        self.bullet_speed = 7
        self.bullet_life = 14
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//shear_back_beetle_shot.png'))
        self.agro_range = 1000
        self.fire_range = 150
        self.xp = [400, 600]
        self.money = [500, 700]
        
        for mod in modEnemyChanges:
            if mod[0] == 'ShearBackBeetle':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]
        
class LivingBomb():
    global assets_dir
    def __init__(self):
        self.name = "living_bomb"
        self.ATK = 15
        self.health = 15
        self.speed = 3
        self.bullet_speed = 15
        self.bullet_life = 14
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//living_bomb_shot.png'))
        self.agro_range = 1000
        self.fire_range = 30
        self.xp = [600, 800]
        self.money = [700, 900]
        
        for mod in modEnemyChanges:
            if mod[0] == 'LivingBomb':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class LivingBoulder():
    global assets_dir
    def __init__(self):
        self.name = "living_boulder"
        self.ATK = 1000
        self.health = 300
        self.speed = 2
        self.bullet_speed = 5
        self.bullet_life = 3
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//void.png'))
        self.agro_range = 1000
        self.fire_range = 10
        self.xp = [1000, 1400]
        self.money = [1200, 1500]
        
        for mod in modEnemyChanges:
            if mod[0] == 'LivingBoulder':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]

class FireDragon():
    global assets_dir
    def __init__(self):
        self.name = "fire_dragon"
        self.ATK = 20
        self.health = 10000
        self.speed = 0
        self.bullet_speed = 14
        self.bullet_life = 100
        self.fire_rate = 20
        self.bullet = (pygame.image.load(assets_dir+'shots//fire_dragon_bullet.png'))
        self.agro_range = 1000
        self.fire_range = 1000
        self.xp = [40000, 40000]
        self.money = [40000, 40000]
        
        self.special_bullet_speed = 5
        self.special_bullet_life = 200
        self.special_rate = 200
        self.special_rate_rate = 200
        #self.special_bullet = (pygame.image.load(assets_dir+'shots//fire_dragon_breath.png'))
        
        for mod in modEnemyChanges:
            if mod[0] == 'FireDragon':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'health':
                    self.health = int(mod[2])
                elif mod[1] == 'speed':
                    self.speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = int(mod[2])
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'xp':
                    self.xp = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'money':
                    self.money = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                    
                elif mod[1] == 'special_bullet_speed':
                    self.special_bullet_speed = int(mod[2])
                elif mod[1] == 'special_bullet_life':
                    self.special_bullet_life = int(mod[2])
                elif mod[1] == 'special_rate':
                    self.special_rate = int(mod[2])
                elif mod[1] == 'special_rate_rate':
                    self.special_rate_rate = int(mod[2])

class DragonFireball():
    global assets_dir
    def __init__(self):
        self.name = "dragon_fireball"
        self.ATK = 20
        self.init_speed = 4
        self.x_speed = 0
        self.y_speed = 0
        self.bullet_speed = 7
        self.bullet_life = [10, 150]
        self.fire_rate = 13
        self.fire_rate_rate = 13
        self.fire_range = -1
        self.agro_range = -1
        self.bullet = (pygame.image.load(assets_dir+'shots//dragon_fireball_bullet.png'))
        
        for mod in modEnemyChanges:
            if mod[0] == 'DragonFireball':
                if mod[1] == 'name':
                    self.name = mod[2]
                elif mod[1] == 'ATK':
                    self.ATK = int(mod[2])
                elif mod[1] == 'init_speed':
                    self.init_speed = int(mod[2])
                elif mod[1] == 'x_speed':
                    self.x_speed = int(mod[2])
                elif mod[1] == 'y_speed':
                    self.y_speed = int(mod[2])
                elif mod[1] == 'bullet_speed':
                    self.bullet_speed = int(mod[2])
                elif mod[1] == 'bullet_life':
                    self.bullet_life = [int(mod[2].split()[0]), int(mod[2].split()[1])]
                elif mod[1] == 'fire_rate':
                    self.fire_rate = int(mod[2])
                elif mod[1] == 'fire_rate_rate':
                    self.fire_rate_rate = int(mod[2])
                elif mod[1] == 'agro_range':
                    self.agro_range = int(mod[2])
                elif mod[1] == 'fire_range':
                    self.fire_range = int(mod[2])
                elif mod[1] == 'bullet':
                    self.bullet = (pygame.image.load(assets_dir+'shots//mod[2]'))

def rectsCollideSimple (rect1, surf1, rect2, surf2):
    collide = False
    try:
        if surf1.get_at((rect2.left - rect1.left, rect2.top - rect1.top)) != surf1.get_colorkey():
            collide = True
    except IndexError:
        useless = None
    try:
        if surf1.get_at((rect2.right - rect1.left, rect2.top - rect1.top)) != surf1.get_colorkey():
            collide = True
    except IndexError:
        useless = None
    try:
        if surf1.get_at((rect2.left - rect1.left, rect2.bottom - rect1.top)) != surf1.get_colorkey():
            collide = True
    except IndexError:
        useless = None
    try:
        if surf1.get_at((rect2.right - rect1.left, rect2.bottom - rect1.top)) != surf1.get_colorkey():
            collide = True
    except IndexError:
        useless = None
    return collide

def rectsCollide (rect1, surf1, rect2, surf2):
    if rectsCollideSimple(rect1, surf1, rect2, surf2) or rectsCollideSimple(rect2, surf2, rect1, surf1):
        return True
    else:
        return False

def text (string, screen, color, position, size, topRight=False, topLeft=False, update=False):
    font = pygame.font.Font(None, size)
    text = font.render(string, 1, (color[0], color[1], color[2]))
    if topRight:
        textpos = text.get_rect(right=position[0], top=position[1])
    elif topLeft:
        textpos = text.get_rect(left=position[0], top=position[1])
    else:
        textpos = text.get_rect(centerx=position[0], centery=position[1])
    screen.blit(text, textpos)
    if update:
        pygame.display.flip()

def intro (screen):
    global assets_dir
    pygame.mixer.quit()
    video = pygame.movie.Movie(assets_dir+'intro.mpg')
    #video.set_volume(1)
    video_screen = pygame.Surface(video.get_size())

    video.set_display(video_screen)
    video.play()
    
    while video.get_busy():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
               sys.exit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
                return None
    
        screen.blit(video_screen,(0,0))
        pygame.display.update()

def render_level (wall_positions, assets_dir):
    walls = []
    wall_stats = []
    player = None
    player_rect = None
    enemies = []
    enemy_rects = []
    wall_row_index = 0
    wall_column_index = 0
    for wall_row in wall_positions:
        temp_wall_row = []
        temp_wall_stats_row = []
        for wall_column in wall_row:
            if wall_column == ' ':
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '@':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == '#':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//cave_wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == '$':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//desert_wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == '%':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//wasteland_wall_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == 'q':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_lt.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'w':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_rt.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'e':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_lb.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'r':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//pentagram_rb.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'c':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//column_1.png'))
                temp_wall_stats_row.append('wall')
            if wall_column == 't':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//tile_1.png'))
                temp_wall_stats_row.append('background')
            if wall_column == 'E':
                temp_wall_row.append(pygame.image.load(assets_dir+'walls//exit.png'))
                temp_wall_stats_row.append('exit')
            if wall_column == 'P':
                player = [(pygame.image.load(assets_dir+'sprites//player.png')), True]
                temp_wall_row.append(player)
                temp_wall_stats_row.append('player')
            if wall_column == '1':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//goblin.png'), wall_column_index, wall_row_index, Goblin(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '2':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//orc.png'), wall_column_index, wall_row_index, Orc(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '3':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//dark_wizard.png'), wall_column_index, wall_row_index, DarkWizard(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '4':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), wall_column_index, wall_row_index, Skeleton(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '5':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton_knight.png'), wall_column_index, wall_row_index, SkeletonKnight(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '6':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//necromancer.png'), wall_column_index, wall_row_index, Necromancer(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '7':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skull.png'), wall_column_index, wall_row_index, Skull(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '8':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_wraith.png'), wall_column_index, wall_row_index, SandWraith(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '9':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//angry_cactus.png'), wall_column_index, wall_row_index, AngryCactus(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == '0':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_snake.png'), wall_column_index, wall_row_index, SandSnake(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'Q':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_snake_nest.png'), wall_column_index, wall_row_index, SandSnakeNest(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'W':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//desert_worm_head_1.png'), wall_column_index, wall_row_index, DesertWormHead(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'R':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//desert_worm_segment.png'), wall_column_index, wall_row_index, DesertWormSegment(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'T':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//desert_worm_tail_1.png'), wall_column_index, wall_row_index, DesertWormTail(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'Y':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_pit.png'), wall_column_index, wall_row_index, SandPit(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'U':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//cyclops_turret.png'), wall_column_index, wall_row_index, CyclopsTurret(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'I':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//shear_back_beetle.png'), wall_column_index, wall_row_index, ShearBackBeetle(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'O':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//living_bomb.png'), wall_column_index, wall_row_index, LivingBomb(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'A':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//living_boulder.png'), wall_column_index, wall_row_index, LivingBoulder(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'D':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//fire_dragon.png'), wall_column_index, wall_row_index, FireDragon(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            if wall_column == 'S':
                #surface, column, row, class, agroed
                enemies.append([pygame.image.load(assets_dir+'sprites//skeleton_trap.png'), wall_column_index, wall_row_index, SkeletonTrap(), False])
                temp_wall_row.append('')
                temp_wall_stats_row.append('')
            wall_column_index += 1
        wall_column_index = 0
        wall_row_index += 1
        walls.append(temp_wall_row)
        wall_stats.append(temp_wall_stats_row)
    wall_rects = []
    for wall_row in walls:
        temp_wall_row = []
        for wall_column in wall_row:
            try:
                temp_wall_row.append(wall_column.get_rect())
            except:
                try:
                    if wall_column[1]:
                        try:
                            player_rect = [(wall_column[0]).get_rect(), True]
                        except:
                            useless = None
                        temp_wall_row.append(player_rect)
                except:
                    temp_wall_row.append('')
        wall_rects.append(temp_wall_row)
    wall_row_x, wall_row_y = 0, 0
    for wall_row in wall_rects:
        for wall_column in wall_row:
            try:
                wall_column[0] += wall_row_x
                wall_column[1] += wall_row_y
            except:
                try:
                    wall_column[0][0] += wall_row_x
                    wall_column[0][1] += wall_row_y
                except:
                    useless = None
            wall_row_x += 20
        wall_row_x = 0
        wall_row_y += 20
    for enemy in enemies:
        enemy_rect = (enemy[0]).get_rect()
        enemy_rect[0] += (20*enemy[1])
        enemy_rect[1] += (20*enemy[2])
        enemy_rects.append(enemy_rect)
    return [walls, wall_rects, player, player_rect, wall_stats, enemies, enemy_rects]

def play (screen, player_staff, player_robe, player_rune):
    global assets_dir
    
    level_file = open(assets_dir + 'level.loxd', 'rb')
    max_level = int(encrypt(level_file.read().decode(), value=200, flush=False))
    level_file.close()
    text_colors = [[0, 0, 255]]*20
    for _ in range(max_level+1):
        text_colors[_] = [255, 127, 39]
    text_positions = [[240, 50], [240, 110], [240, 170], [240, 230], [240, 290], [240, 350], [240, 410], [240, 470], [240, 530], [240, 590],
                      [720, 50], [720, 110], [720, 170], [720, 230], [720, 290], [720, 350], [720, 410], [720, 470], [720, 530], [720, 590]]
    text_list = []
    textpos_list = []
    for _ in range(20):
        font = pygame.font.Font(None, 40)
        text_list.append(font.render('Level ' + str(_+1), 1, (text_colors[_][0], text_colors[_][1], text_colors[_][2])))
        textpos_list.append(text_list[-1].get_rect(centerx=text_positions[_][0], centery=text_positions[_][1]))
    
    level_not_chosen = True
    while level_not_chosen:
        mouse_pos = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return [0, 0, 0]
        if pygame.mouse.get_pressed()[0]:
            for text_counter in range(len(text_list)):
                if textpos_list[text_counter].collidepoint(mouse_pos) and text_colors[text_counter] == [255, 127, 39]:
                    levels_won = text_counter
                    level_not_chosen = False
                    #print('levels_won ' + str(levels_won))
        screen.fill((0, 0, 0))
        screen.blit(pygame.image.load(assets_dir+'screens//shop.png'), (0, 0))
#        #Orange - 255, 127, 39
        for _ in range(20):
            screen.blit(text_list[_], textpos_list[_])
        pygame.display.flip()
    
    #48 x 36
    # P - Player
    # @ - Mountain
    # # - Cave wall
    # $ - Desert Wall
    # E - Exit
    # qwer - pentagram
    # c - column 1
    # t - tile 1
    # 1 - Goblin
    # 2 - Orc
    # 3 - Dark Wizard
    # 4 - Skeleton
    # 5 - Skeleton Knight
    # S - Skeleton trap
    # 6 - Necromancer
    # 7 - Skull (boss)
    # 8 - Sand Wraith
    # 9 - Angry Cactus
    # 0 - Sand Snake
    # Q - Sand Snake Nest
    # Y - Sand Pit
    # WRT - Desert Worm
    # U - Cyclops Turret
    # I - Shear Back Beetle
    # O - Living Bomb
    # p - Living Boulder
    levels =[['P  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '     @@@@@@@@@@@@@@@@@                @@@@@@@@@@',
              '     @@@@@@@@@@@@@@@@                  @@@@@@@@@',
              '      @@@@@@@@@@@@@@@          1      @@@@@@@@@@',
              '      @@@@@@@@@@@@@@                 @@@@@@@@@@@',
              '       @@@@@@@@@@@@@        @@      @@@@@@@@@@@@',
              '       @@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@',
              '        @@@@@@@@@@    @@@@@@@@@@@@@@@@@@@@@@@@@@',
              '        @@@@@@@@@@     @@@@@@@@@@@@@@@@@@@@@@@@@',
              '                         @@@@@@@@@@@@@@@@@@@@@@@',
              '                          @@@@@@@@@@@@@@@@@@@@@@',
              '                           @@@@@@@@@@@@@@@@@@@@@',
              '                            @@@@@@@@@@@@@@@@@@@@',
              '                             @@@@@@@@@@@@@@@@@@@',
              '      @@@@@@@@@@@             @@@@@@@@@@@@@@@@@@',
              '     @@@@@@@@@@@@@             @@@@@@@@@@@@@@@@@',
              '    @       @@@@@               @@@@@@@@@@@@@@@@',
              '             @@@@@       1       @@@@@@@@@@@@@@@',
              '                @@@               @@@@@@@@@@@@@@',
              '           1     @@@               @@@@@@@@@@@@@',
              '                 @@@@@@             @@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@         @@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@         @@         @@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@         @@@         @@@@@@@@@',
              '@@@@@@@      @@@@@    @@    @@@         @@@@@@@@',
              '@@@@@          @@@@    @@    @@@         @@@@@@@',
              '@@@@            @@@@    @@    @@@         @@@@@@',
              '@@@@      1      @@    @@@@    @@@         @@@@@',
              '@@@@             @@    @@@@@    @@@         @@@@',
              '@@@@@           @@@    @@@@@@    @@@         @@@',
              '@@@@@@           @@@    @@@@@@    @@@         @@',
              '@@@@@@@@@@               @@@@@@                @',
              '@@@@@@@@@@@@@            @@@@@@@                ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    EEEE'],
             ['P  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '         @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@              @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                    @@@@@@@@@@@@@@@@@@@@@@@@@@@',
              '@                       @@@@@@@@@@@@@@@@@@@@@@@@',
              '@                      1   @@@@@@@@@@@@@@@@@@@@@',
              '@                             @@@@@@@@@@@@@@@@@@',
              '@         1                      @@@@@@@@@@@@@@@',
              '@                                   @@@@@@@@@@@@',
              '@                                      @@@@@@@@@',
              '@                      1                  @@@@@@',
              '@                                            @@@',
              '@         1                          1         @',
              '@                                              @',
              '@                      1                       @',
              '@                                              @',
              '@                                    1         @',
              '@                                              @',
              '@@@       1            1                       @',
              '@@@@@@                                         @',
              '@@@@@@@@@                            1         @',
              '@@@@@@@@@@@@                                   @',
              '@@@@@@@@@@@@@@@        1                       @',
              '@@@@@@@@@@@@@@@@@@                             @',
              '@@@@@@@@@@@@@@@@@@@@@                          @',
              '@@@@@@@@@@@@@@@@@@@@@@@@                       @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@                    @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                 @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@              @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@           @',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@         ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@      ',
              '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  E'],
             ['@@@@@@@@@@@@@@@@@@@@@  P   @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@                  @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@           2         @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@                      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@            @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@          @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@      1      @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@           @@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@            @@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@            @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@    1      @@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@             @@@@      @@@@@@@@@@@  @@@@@@@@',
              '@@@@@           @@@@@      @@@@@@@@@      @@@@@@',
              '@@@@@           @@@@@      @@@@@@@          @@@@',
              '@@@@@@         @@@@@@      @@@@@@     1    @@@@@',
              '@@@@@@          @@@@@      @@@@@@           @@@@',
              '@@@@@    1     @@@@@@      @@@@@@@           @@@',
              '@@@@@@       @@@@@@@@      @@@@@@@          @@@@',
              '@@@@@@@@   @@@@@@@@@@      @@@@@@          @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@            @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@      1     @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@          @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@           @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@ 222  @@@@           @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@            @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@            @@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@     1    @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@            @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@                      @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@                     @@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@         @@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@@@@@@@@@@@@@@@@@EEEEEE@@@@@@@@@@@@@@@@@@@@@'],
             ['@@@@@@@@@@@@@@@@@@@@@  P   @@@@@@@@@@@@@@@@@@@@@',
              '@@@@@                                        @@@',
              '@@                                          @@@@',
              '@                                            @@@',
              '@                                             @@',
              '@                                              @',
              '@                                              @',
              '@           @@@                                @',
              '@           @ @                                @',
              '@            @                   @@            @',
              '@                               @@@@           @',
              '@                                @@@           @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                   1      1                   @',
              '@                                              @',
              '@             2       3qw3                     @',
              '@                     3er3       2             @',
              '@                                              @',
              '@                   1      1                   @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                  @           @',
              '@         @@                      @@           @',
              '@       @@@                        @@          @',
              '@        @                         @           @',
              '@                                              @',
              '@                                              @',
              '@                                            @@@',
              '@   @@                                       @@@',
              '@@@@@@@@@                                  @@@@@',
              '@@@@@@@@@@@@@@@@@@@@@EEEEEE@@@@@@@@@@@@@@@@@@@@@'],
             ['@@@@@@@@@@@@@@@@@@@@@@ P  @@@@@@@@@@@@@@@@@@@@@@',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                                              @',
              '@                   3      3                   @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@              3tttttttttttttttt3              @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@              3tttttttttttttttt3              @',
              '@               tttttttttttttttt               @',
              '@               tttttttttttttttt               @',
              '@               cctttttcctttttcc               @',
              '@               cctttttcctttttcc               @',
              '@                   3      3                   @',
              '@                                              @',
              '@U                                            U@',
              '@                                              @',
              '@                                              @',
              '@@@@@@@@@@@@@@@@@@@@@@@EE@@@@@@@@@@@@@@@@@@@@@@@'],
	        ['###################### P  ######################',
              '#                                              #',
              '#                                     #        #',
              '#           #      ########      4    #        #',
              '#    4     #               ##        #         #',
              '#         #                  ##      #         #',
              '#        #                     #               #',
              '#       #                     #           4    #',
              '#       #           ###            #           #',
              '#      #          ##   ##          #           #',
              '#     #          #       #                     #',
              '#               #    4    #             ###    #',
              '#     4         #         #              ##    #',
              '#     #          #       #              ##     #',
              '#     #           ##   ##       ###            #',
              '#      #                           ##          #',
              '#      #                             #         #',
              '#       #                     #       #        #',
              '#        #          ##        #        #   4   #',
              '##        ##          #      #        #        #',
              '####  4     ###        ######         #        #',
              '##        ##          #      #       #         #',
              '#        #         ###              #     #    #',
              '#       #                         ##       #   #',
              '#      #                       ###         #   #',
              '#      #                                   #   #',
              '#     #                  5                #    #',
              '#     #                          #      ##     #',
              '#              ###              #      #       #',
              '#            ##   ##          ##      #        #',
              '#    4     ##       ###    ###        #        #',
              '#         #            ####          #     4   #',
              '#        #                           #         #',
              '#                      5                       #',
              '#                                              #',
              '#######################EE#######################'],
             ['###################### P  ######################',
              '#          #                   #          #    #',
              '#     #    #                              #    #',
              '#     #          4        ####    ####    #    #',
              '#     #    #                  ####             #',
              '#       #  #                     4     ###   ###',
              '#              ######         ##               #',
              '#                             ##    #      #   #',
              '#     4                             #      #   #',
              '#             4        #######     ##    4 #   #',
              '#                                   #      #   #',
              '#       #                     #     #     #    #',
              '#                             #          #     #',
              '#          # #  #             #         #      #',
              '#               #     4       #     ####       #',
              '#   #           #              #          #    #',
              '#   #4        #######                  ####    #',
              '#    #                                     #####',
              '#     #                           #    4  #    #',
              '#          #                       #      #    #',
              '#                                   #     #    #',
              '#                   tttcctttttc      #         #',
              '#       4       cctttttcctttttcc      #        #',
              '#    #          ttttttttttttt tt          ######',
              '#     #         ttttttttttttttt                #',
              '#      #        tttSttttt5tttttt               #',
              '#       #       ttttttttttttt tt               #',
              '#    #######    tttttttttttttttt        ###    #',
              '#               cctttttcctttttcc          #    #',
              '#               c  ttttc  ttttcc               #',
              '#       #                          4   #       #',
              '#       #   4                          #       #',
              '#       #              4               #       #',
              '#      #                                #      #',
              '#     #                                  #     #',
              '#######################EE#######################'],
             ['################################################',
              '#E     #         4            4         #     E#',
              '# 4     #                              #     4 #',
              '#        #       ##          ##       #        #',
              '#         #        ##      ##        #         #',
              '#                    ##  ##                    #',
              '#           #          ##          #           #',
              '#            #                    #            #',
              '#             #                  #             #',
              '#                       5                      #',
              '#        #  4   #              #   4  #        #',
              '#   4     #      #            #      #     4   #',
              '#          #      #    ##    #      #          #',
              '#        ####      #        #      ####        #',
              '#                   #      #                   #',
              '#                                              #',
              '#                                              #',
              '#     #           #          #     #           #',
              '#       5   #     #    P     #       5   #     #',
              '#                                              #',
              '#                                              #',
              '#                   #      #                   #',
              '#        ####      #        #      ####        #',
              '#          #      #    ##    #      #          #',
              '#   4     #      #            #      #     4   #',
              '#        #  4   #              #   4  #        #',
              '#                      5                       #',
              '#             #                  #             #',
              '#            #                    #            #',
              '#           #          ##          #           #',
              '#                    ##  ##                    #',
              '#         #        ##      ##        #         #',
              '#        #       ##          ##       #        #',
              '# 4     #                              #     4 #',
              '#E     #         4            4         #     E#',
              '################################################'],
             ['###################### P  ######################',
              '#                                              #',
              '#                   ########                   #',
              '#                 ############                 #',
              '#               ################               #',
              '#              ##################              #',
              '#             ####################             #',
              '#            ######################            #',
              '#            ######################            #',
              '#           ########################           #',
              '#           ########################           #',
              '#           ########################           #',
              '#           ## ################## ##           #',
              '#           ## ####   ####   #### ##           #',
              '#           ### ###### ## ###### ###           #',
              '#           ### ################ ###           #',
              '#            ## #    ##  ##    # ##            #',
              '#            # #       ##       # #            #',
              '#             #   4   ####   4   #             #',
              '#             #       ####       #             #',
              '#            ##      ##          ##            #',
              '#            ###   ###    ###   ###            #',
              '#            ## ##     4  #  ### ##            #',
              '#            ###   ###    ###   ###            #',
              '#             #### ### #  ### ####             #',
              '#              ## #####  ##### ##              #',
              '#                  #### #####                  #',
              '#               #  # ##  ## #  #               #',
              '#               #  # ##  ## #  #               #',
              '#               #      4       #               #',
              '#       6       #  # ##  ## #  #       6       #',
              '#                # # ##  ## # #                #',
              '#                 ###### #####                 #',
              '#                 #####  #####                 #',
              '#                   ### ####                   #',
              '#######################EE#######################'],
             ['#######################P #######################',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                        7                     #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#######################EE#######################'],
             ['$$$$$$$$$$$$$$$$$$$$$$ P  $$$$$$$$$$$$$$$$$$$$$$',
              '$                                              $',
              '$                                              $',
              '$$$$$                                          $',
              '$    $$$$                                      $',
              '$        $$$$                                  $',
              '$            $$$$                              $',
              '$                $$$$                          $',
              '$                    $$$$                      $',
              '$                        $$$$                  $',
              '$                            $$$$              $',
              '$           $                    $$$$          $',
              '$                                    $$$$      $',
              '$                                        $$$$  $',
              '$                             $                $',
              '$      $                                       $',
              '$                     9                        $',
              '$                           $                  $',
              '$                                              $',
              '$              $                               $',
              '$  $$$$                            $           $',
              '$      $$$$                                    $',
              '$          $$$$            $                   $',
              '$              $$$$                            $',
              '$                  $$$$                  $     $',
              '$                      $$$$                    $',
              '$                          $$$$                $',
              '$                              $$$$            $',
              '$                                  $$$$        $',
              '$                                      $$$$    $',
              '$               9                          $$$$$',
              '$                                              $',
              '$                                              $',
              '$$$$$$$$$$$$$$$$$$$$$$$EE$$$$$$$$$$$$$$$$$$$$$$$'],
             ['$$$$$$$$$$$$$$$$$$$$$$ P  $$$$$$$$$$$$$$$$$$$$$$',
              '$                                              $',
              '$                                              $',
              '$$$$$                                          $',
              '$    $$$$                                      $',
              '$        $$$$                                  $',
              '$            $$$$                              $',
              '$                $$$$                          $',
              '$                    $$$$                      $',
              '$                        $$$$                  $',
              '$                            $$$$              $',
              '$           $$$$$                $$$$          $',
              '$                $                   $$$$      $',
              '$        $         $                       $$$$$',
              '$       $           $           $$$            $',
              '$      $                        $              $',
              '$       $              8       $               $',
              '$        $          $         $                $',
              '$         $        $                     8     $',
              '$          $$$$$$$$                            $',
              '$  $$$$                            $           $',
              '$      $$$$                                    $',
              '$          $$$$            $                   $',
              '$              $$$$                            $',
              '$           8                            $     $',
              '$              $$$$                            $',
              '$             $            $$$$                $',
              '$              $$$$            $$$$            $',
              '$ $$$$$$$$$$       $$$$            $$$$        $',
              '$           $          $$$$            $$$$    $',
              '$            $             $$$$            $$$$$',
              '$             $                $$$$            $',
              '$                                              $',
              '$$$$$$$$$$$$$$$$$$$$$$$EE$$$$$$$$$$$$$$$$$$$$$$$'],
             ['$$$$$$$$$$$$$$$$$$$$$$$P $$$$$$$$$$$$$$$$$$$$$$$',
              '$                                              $',
              '$                                              $',
              '$                                              $',
              '$                                              $',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$      $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$    $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$',
              '$     $                                        $',
              '$     $                                        $',
              '$      $                                       $',
              '$      $                                       $',
              '$      $                                       $',
              '$     $                                        $',
              '$     $                                        $',
              '$     $                                        $',
              '$      $                     Q                 $',
              '$      $                                       $',
              '$      $                                       $',
              '$     $                                        $',
              '$     $                                        $',
              '$     $                                        $',
              '$     $                                        $',
              '$                                              $',
              '$$$$$$$$$$$$$$$$$$$$$$$EE$$$$$$$$$$$$$$$$$$$$$$$'],
             ['#######################P #######################',
              '#                                      Y       #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#            Y                                 #',
              '#                               Y              #',
              '#                                              #',
              '#                                              #',
              '#8              9               9             8#',
              '#  Y                                           #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                   Y          #',
              '#                                              #',
              '#            Y            Y                    #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#8              9               9             8#',
              '#                            Y                 #',
              '#Y                                             #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#######################EE#######################'],
             ['#######################P #######################',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#                                              #',
              '#   W                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R                                          #',
              '#                                              #',
              '#                                              #',
              '#   R  R  R  R  R  R  R  R  R  R  R  R  T      #',
              '#                                              #',
              '#                                              #',
              '#######################EE#######################'],
             ['%%%%%%%%%%%%%%%%%%%%%%%P %%%%%%%%%%%%%%%%%%%%%%%',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%        %%                                    %',
              '%       %%     I                               %',
              '%      %%                      %               %',
              '%      %                     %%                %',
              '%      %                     %      I          %',
              '%       %                    %                 %',
              '%                             %                %',
              '%                            %%                %',
              '%         I                  %%                %',
              '%                                              %',
              '%                                              %',
              '%                       I                      %',
              '%                                              %',
              '%                                   I          %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%     %%%%%%%%                                 %',
              '%                                              %',
              '%                        I                     %',
              '%                              %%              %',
              '%                             %%               %',
              '%         I                   %%               %',
              '%                            %%                %',
              '%                           %%      I          %',
              '%                          %                   %',
              '%                         %                    %',
              '%                       %%                     %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%%%%%%%%%%%%EE%%%%%%%%%%%%%%%%%%%%%%%'],
             ['%%%%%%%%%%%%%%%%%%%%%%%P %%%%%%%%%%%%%%%%%%%%%%%',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%        O                             O       %',
              '%                                              %',
              '%                                              %',
              '%                        I                     %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%              I                      I        %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                        I                     %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%       I                                      %',
              '%                                              %',
              '%                                              %',
              '%                                  I           %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                    O    O                    %',
              '%                                              %',
              '%                    O    O                    %',
              '%                                              %',
              '%                    O    O                    %',
              '%%%%%%%%%%%%%%%%%%%%%%%EE%%%%%%%%%%%%%%%%%%%%%%%'],
             ['%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%',
              '%A      A     A    A    A     A    A    A    A %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%            P           %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%A                                           A %',
              '%                                              %',
              '%       A    A   A     A     A       A         %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%%%%%%%%%%%%%%%%%%%%%%%EE%%%%%%%%%%%%%%%%%%%%%%%'],
             ['%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%',
              '%O      O     O    O    O     O    O    O    O %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%            P           %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%O                                           O %',
              '%                                              %',
              '%       O    O   O     O     O       O         %',
              '%%%%%%%%%%%%                        %%%%%%%%%%%%',
              '%%%%%%%%%%%%%%%%%%%%%%%EE%%%%%%%%%%%%%%%%%%%%%%%'],
             ['%%%%%%%%%%%%%%%%%%%%%%%P %%%%%%%%%%%%%%%%%%%%%%%',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%     %%                                %%     %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                          %%                  %',
              '%                 D                            %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%           %                                  %',
              '%           %                                  %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                              %',
              '%                                  %%          %',
              '%                                  %           %',
              '%                                              %',
              '%               %                              %',
              '%                                              %',
              '%                                              %',
              '%%%%%%%%%%%%%%%%%%%%%%%EE%%%%%%%%%%%%%%%%%%%%%%%']]
    
    #levels_won = 0
    
    walls = render_level(levels[levels_won], assets_dir)[0]
    wall_rects = render_level(levels[levels_won], assets_dir)[1]
    player = render_level(levels[levels_won], assets_dir)[2][0]
    player.set_alpha(None)
    player.set_colorkey((255, 255, 255))
    player_rect = render_level(levels[levels_won], assets_dir)[3][0]
    wall_stats = render_level(levels[levels_won], assets_dir)[4]
    enemies = render_level(levels[levels_won], assets_dir)[5]
    for enemy_counter in range(len(enemies)):
        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
    enemy_rects = render_level(levels[levels_won], assets_dir)[6] 
    
    exit_blocks = []
    for wall_row_index in range(len(wall_rects)):
        for wall_column_index in range(len(wall_rects[wall_row_index])):
            if wall_stats[wall_row_index][wall_column_index] == 'exit':
                exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
    
    if levels_won <= 4:
        background = pygame.image.load(assets_dir+'walls//background1.png')
    elif levels_won > 4 and levels_won <= 9:
        background = pygame.image.load(assets_dir+'walls//background2.png')
    elif levels_won > 9 and levels_won <= 14:
        background = pygame.image.load(assets_dir+'walls//background3.png')
    elif levels_won > 14:
        background = pygame.image.load(assets_dir+'walls//background4.png')
    
    #staff - dmg, rof, prc, spirite
    #robe - hp, mp
    #rune - element, dmg, mp, prc, image, drn
    player_shot_image = player_staff[3]
    player_shot_image.set_alpha(None)
    player_shot_image.set_colorkey(player_shot_image.get_at((0, 0)))
#    player_shot_image.set_colorkey((255, 255, 255))
    player_speed = 5
    
    max_player_health = player_robe[0] + 30
    player_health = max_player_health
    max_player_mana = player_robe[0] + 100
    player_mana = max_player_mana
    rune_image = player_rune[4]
    rune_image.set_alpha(None)
    rune_image.set_colorkey((0, 0, 0))
    rune_speed = 10
    
    total_money = 0
    total_xp = 0
    
    player_dmg = player_staff[0]
    
#    fire_spell_used = False
#    fire_spell_img = pygame.image.load(shots_dir+'player_fire_spell.png')
#    fire_spell_img.set_alpha(None)
#    fire_spell_img.set_colorkey((0, 0, 0))
    
    player_shots = []
    bullet_delay = 0
    special_delay = 0
    player_rof = player_staff[1]
    player_prc = player_staff[2] - 1
    if player_prc > 1:
        bullet_speed = 10 * (player_prc//2)
    else:
        bullet_speed = 10
    uSpecials = False
    
    enemy_shots = []
    enemy_fire_rate = []
    for enemy in enemies:
        enemy_fire_rate.append(enemy[3].fire_rate)
    enemy_bullet_delay = [0]*len(enemies)
    explosions = []
    
    enemies_alive = [True]*len(enemies)
    
    pause = pygame.image.load(assets_dir+'//animations//game//pause.png')
    pause.set_alpha(None)
    pause.set_colorkey((255, 255, 255))
    pause_rect = pause.get_rect(centerx=480, centery=360)
    oTimer = 0
    pTimer = 0
    iTimer = 0
    kTimer = 0
    nTimer = 0
    godmode = False
    l5_boss_not_summoned = True
    l15_init = False
    desert_worm_ai = 'a'*360+'w'*250
    #desert_worm_ai_counter = [120, 90, 60, 30, 0]
    desert_worm_ai_counter = [600, 570, 540, 510, 480, 450, 420, 390, 360, 330, 300, 270, 240, 210, 180, 150, 120, 90, 60, 30, 0]
    clock = pygame.time.Clock()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYUP and event.key == pygame.K_ESCAPE:
                return [total_money, total_xp, levels_won]
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                screen.blit(pause, pause_rect)
                pygame.display.flip()
                paused = True
                while paused:
                    for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                            paused = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE and player_rune[1] > 0:
                #rune - element, dmg, mp, prc, image, drn
                if player_rune[0] == 'fire' or player_rune[0] == 'ice' or player_rune[0] == 'dark_arts':
                    if player_mana >= player_rune[2]:
                        mouse_pos = pygame.mouse.get_pos()
                        try:
                            dx = mouse_pos[0]-player_rect.centerx
                            dy = mouse_pos[1]-player_rect.centery
                            x_speed = rune_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                            y_speed = rune_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                            if dx < 0:
                                x_speed *= -1
                            if dy < 0:
                                y_speed *= -1
                        except ZeroDivisionError:
                                if dx > 0:
                                    x_speed = rune_speed
                                    y_speed = 0
                                elif dx < 0:
                                    x_speed = -1 * rune_speed
                                    y_speed = 0
                                else:
                                    if dy > 0:
                                        x_speed = 0
                                        y_speed = rune_speed
                                    else:
                                        x_speed = 0
                                        y_speed = -1 * rune_speed
                        #surface, rect, x-speed, y-speed
                        player_shots.append([pygame.transform.rotozoom(rune_image, 180 + math.degrees(math.atan2(dx, dy)), 1), rune_image.get_rect(centerx=player_rect.centerx, centery=player_rect.centery), x_speed, y_speed, [player_rect.centerx, player_rect.centery], player_rune[3], player_rune[1], player_rune[5]])
                        player_shots[len(player_shots)-1][0].set_alpha(None)
                        player_shots[len(player_shots)-1][0].set_colorkey((0, 0, 0))
                        player_mana -= player_rune[2]
                if player_rune[0] == 'lightning':
                    if player_mana >= player_rune[2]:
                        player_bullet_angles = [[100, 0], [100, 100], [0, 100], [-100, 100], [-100, 0], [-100, -100], [0, -100], [100, -100],
                                                [241, 100], [100, 241], [-100, 241], [-241, 100], [-100, -241], [-241, -100], [100, -241], [241, -100]]
                        for player_bullet_entry in player_bullet_angles:
                            try:
                                dx = player_bullet_entry[0]
                                dy = player_bullet_entry[1]
                                x_speed = rune_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                                y_speed = rune_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                                if dx < 0:
                                    x_speed *= -1
                                if dy < 0:
                                    y_speed *= -1
                            except ZeroDivisionError:
                                if dx > 0:
                                    x_speed = rune_speed
                                    y_speed = 0
                                elif dx < 0:
                                    x_speed = -1 * rune_speed
                                    y_speed = 0
                                else:
                                    if dy > 0:
                                        x_speed = 0
                                        y_speed = rune_speed
                                    else:
                                        x_speed = 0
                                        y_speed = -1 * rune_speed
                            player_shots.append([pygame.transform.rotozoom(rune_image, 180 + math.degrees(math.atan2(dx, dy)), 1), rune_image.get_rect(centerx=player_rect.centerx, centery=player_rect.centery), x_speed, y_speed, [player_rect.centerx, player_rect.centery], player_rune[3], player_rune[1], player_rune[5]])
    #                        enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                        for player_shot_counter in range(16):
                            player_shots[len(player_shots)-player_shot_counter-1][0].set_alpha(None)
                            player_shots[len(player_shots)-player_shot_counter-1][0].set_colorkey((0, 0, 0))
    #                        player_shots[len(player_shots)-1][0].set_colorkey((0, 0, 0))
                        player_mana -= player_rune[2]
            elif event.type == pygame.KEYUP and event.key == pygame.K_o:
                oTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_l:
                if oTimer > 0:
                    enemies_alive = [False]*len(enemies)
                    player_rect[0] = exit_blocks[0][0]
                    player_rect[1] = exit_blocks[0][1]
            elif event.type == pygame.KEYUP and event.key == pygame.K_p:
                pTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_u:
                if pTimer > 0:
                    player_health = max_player_health
            elif event.type == pygame.KEYUP and event.key == pygame.K_i:
                iTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_j:
                if iTimer > 0:
                    if godmode == False:
                        godmode = True
                    else:
                        godmode = False
                    iTimer = 0
            elif event.type == pygame.KEYUP and event.key == pygame.K_k:
                kTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_m:
                if kTimer > 0:
                    player_dmg *= 2
            elif event.type == pygame.KEYUP and event.key == pygame.K_n:
                nTimer = 100
            elif event.type == pygame.KEYUP and event.key == pygame.K_b:
                if nTimer > 0:
                    if uSpecials:
                        uSpecials = False
                    else:
                        uSpecials = True
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
                command = input('@: ').split()
                if command[0] == 'tp':
                    assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + command[1] + '//'
                elif command[0] == 'lvl':
                    try:
                        levels_won = int(command[1]) - 2
                        enemies_alive = [False]*len(enemies)
                        player_rect[0] = exit_blocks[0][0]
                        player_rect[1] = exit_blocks[0][1]
                        screen.blit(pause, pause_rect)
                        pygame.display.flip()
                        paused = True
                        while paused:
                            for event in pygame.event.get():
                                if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                                    paused = False
                    except:
                        print('ERROR: Cannot convert level index to int')
                elif command[0] == 'hp' or command[0] == 'health':
                    try:
                        if command[1] == '*':
                            player_health *= int(command[1])
                        elif command[1] == '+':
                            player_health += int(command[1])
                        else:
                            player_health = int(command[1])
                    except:
                        print('ERROR: Cannot covert health value to int')
                elif command[0] == 'mhp' or command[0] == 'max_health':
                    try:
                        if command[1] == '*':
                            max_player_health *= int(command[1])
                        elif command[1] == '+':
                            max_player_health += int(command[1])
                        else:
                            max_player_health = int(command[1])
                    except:
                        print('ERROR: Cannot covert max health value to int')
                elif command[0] == 'dmg' or command[0] == 'damage':
                    try:
                        if command[1] == '*':
                            player_dmg *= int(command[1])
                        elif command[1] == '+':
                            player_dmg += int(command[1])
                        else:
                            player_dmg = int(command[1])
                    except:
                        print('ERROR: Cannot covert damage value to int')
                elif command[0] == 'spd' or command[0] == 'speed':
                    try:
                        if command[1] == '*':
                            player_speed *= int(command[1])
                        elif command[1] == '+':
                            player_speed += int(command[1])
                        else:
                            player_speed = int(command[1])
                    except:
                        print('ERROR: Cannot covert speed value to int')
                else:
                    print('ERROR: Unkown command')
        keys = pygame.key.get_pressed()
        mouse_pos = pygame.mouse.get_pos()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=(player_rect.centerx-player_speed), centery=player_rect.centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.left > 0 and notTouchingWall:
                player_rect[0] -= player_speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=(player_rect.centerx+player_speed), centery=player_rect.centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.right < screenWidth and notTouchingWall:
                player_rect[0] += player_speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=player_rect.centerx, centery=(player_rect.centery-player_speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.top > 0 and notTouchingWall:
                player_rect[1] -= player_speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            notTouchingWall = True
            for wall_row_index in range(len(wall_rects)):
                for wall_column_index in range(len(wall_rects[wall_row_index])):
                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                        try:
                            if (player.get_rect(centerx=player_rect.centerx, centery=(player_rect.centery+player_speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                notTouchingWall = False
                        except:
                            useless = None
            if player_rect.bottom < screenHeight and notTouchingWall:
                player_rect[1] += player_speed
        
        if pygame.mouse.get_pressed()[0] and (bullet_delay == 0):
            try:
                dx = mouse_pos[0]-player_rect.centerx
                dy = mouse_pos[1]-player_rect.centery
                x_speed = bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                y_speed = bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                if dx < 0:
                    x_speed *= -1
                if dy < 0:
                    y_speed *= -1
                #surface, rect, x-speed, y-speed
                player_shots.append([player_shot_image, player_shot_image.get_rect(centerx=player_rect.centerx, centery=player_rect.centery), x_speed, y_speed, [player_rect.centerx, player_rect.centery], player_prc])
                bullet_delay += int(10/player_rof)
            except:
                useless = None
        
        for player_shot_counter in range(len(player_shots)):
            if player_shots[player_shot_counter][1] != None:
                player_shots[player_shot_counter][4][0] += player_shots[player_shot_counter][2]
                player_shots[player_shot_counter][4][1] += player_shots[player_shot_counter][3]
                player_shots[player_shot_counter][1][0] = round(player_shots[player_shot_counter][4][0])
                player_shots[player_shot_counter][1][1] = round(player_shots[player_shot_counter][4][1])
                if (player_shots[player_shot_counter][1][0] < 1) or (player_shots[player_shot_counter][1][0] >= screenWidth) or (player_shots[player_shot_counter][1][1] < 1) or (player_shots[player_shot_counter][1][1] >= screenHeight):
                    player_shots[player_shot_counter][1] = None
                for wall_row_index in range(len(wall_rects)):
                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                            try:
                                if player_shots[player_shot_counter][1].colliderect(wall_rects[wall_row_index][wall_column_index]):
                                    player_shots[player_shot_counter][1] = None
                            except:
                                useless = None
                for enemy_counter in range(len(enemies)):
                    try:
                        if rectsCollide(player_shots[player_shot_counter][1], player_shots[player_shot_counter][0], enemy_rects[enemy_counter], enemies[enemy_counter][0]):
                            if ((enemies[enemy_counter][3].name == 'sand_snake' and math.sqrt(((enemy_rects[enemy_counter].centerx-player_rect.centerx)**2)+((enemy_rects[enemy_counter].centery-player_rect.centery)**2)) < enemies[enemy_counter][3].fire_range) or enemies[enemy_counter][3].name != 'sand_snake') and enemies[enemy_counter][3].name != 'sand_pit':
                                if player_shots[player_shot_counter][5] > 0:
                                    try:
                                        enemies[enemy_counter][3].health -= player_shots[player_shot_counter][6]
                                        player_health += player_shots[player_shot_counter][7]
                                    except:
                                        enemies[enemy_counter][3].health -= player_dmg
                                    player_shots[player_shot_counter][5] -= player_prc
                                else:
                                    try:
                                        enemies[enemy_counter][3].health -= player_shots[player_shot_counter][6]
                                        player_health += player_shots[player_shot_counter][7]
                                    except:
                                        enemies[enemy_counter][3].health -= player_dmg
                                    player_shots[player_shot_counter][1] = None
                                if player_health > max_player_health:
                                    player_health = max_player_health
                                enemies[enemy_counter][4] = True
                    except:
                        useless = None
        
        for enemy_counter in range(len(enemies)):
            if enemy_rects[enemy_counter] != None:
                if enemies[enemy_counter][0].get_colorkey() != (255, 255, 255):
                    enemies[enemy_counter][0].set_alpha(None)
                    enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                if (math.sqrt((abs(player_rect.centerx - enemy_rects[enemy_counter].centerx)**2) + (abs(player_rect.centery - enemy_rects[enemy_counter].centery)**2)) < enemies[enemy_counter][3].fire_range) and (enemy_bullet_delay[enemy_counter] == 0):
                    if enemies[enemy_counter][3].name == 'necromancer':
                        enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), None, None, Skeleton(), True])
                        enemy_rects.append(pygame.image.load(assets_dir+'sprites//skeleton.png').get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=enemy_rects[enemy_counter].centery))
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                        enemy_bullet_delay.append(0)
                        enemies_alive.append(True)
                    elif enemies[enemy_counter][3].name == 'living_bomb':
                        enemies[enemy_counter][3].health = 0
                    elif enemies[enemy_counter][3].name == 'sand_snake_nest':
                        enemies.append([pygame.image.load(assets_dir+'sprites//sand_snake.png'), None, None, SandSnake(), True])
                        enemy_rects.append(pygame.image.load(assets_dir+'sprites//sand_snake.png').get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=enemy_rects[enemy_counter].centery))
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                        enemy_bullet_delay.append(0)
                        enemies_alive.append(True)
                    else:
                        #surface, rect, x-speed, y-speed, life, damage, type
                        try:
                            dx = player_rect.centerx - enemy_rects[enemy_counter].centerx
                            dy = player_rect.centery - enemy_rects[enemy_counter].centery
                            x_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                            y_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                            if dx < 0:
                                x_speed *= -1
                            if dy < 0:
                                y_speed *= -1
                        except ZeroDivisionError:
                            if (player_rect.centerx - enemy_rects[enemy_counter].centerx) > 0:
                                x_speed = enemies[enemy_counter][3].bullet_speed
                                y_speed = 0
                            elif (player_rect.centerx - enemy_rects[enemy_counter].centerx) < 0:
                                x_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                y_speed = 0
                            else:
                                if (player_rect.centery - enemy_rects[enemy_counter].centery) > 0:
                                    x_speed = 0
                                    y_speed = enemies[enemy_counter][3].bullet_speed
                                else:
                                    x_speed = 0
                                    y_speed = -1 * enemies[enemy_counter][3].bullet_speed
                        if enemies[enemy_counter][3].name == 'skull':
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'explosive', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                        #elif enemies[enemy_counter][3].name == 'fire_dragon':
                        #    enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'cactus', [enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, enemies[enemy_counter][3].bullet_speed]])
                        elif enemies[enemy_counter][3].name == 'desert_worm_head':
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'explosive_dw', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx*0.75, dy*1.5)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed*0.75, y_speed*1.5, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'explosive_dw', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx*1.5, dy*0.75)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed*1.5, y_speed*0.75, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'explosive_dw', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                        elif enemies[enemy_counter][3].name == 'cyclops_turret':
                            cyclops_summoned = False
                            for ct_enemy in enemies:
                                if ct_enemy[3].name == 'cyclops':
                                    cyclops_summoned = True
                            if cyclops_summoned:
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                        else:
                            enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                            if enemies[enemy_counter][3].name == 'cyclops' or enemies[enemy_counter][3].name == 'fire_dragon':
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx*0.75, dy*1.5)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed*0.75, y_speed*1.5, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx*1.5, dy*0.75)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed*1.5, y_speed*0.75, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])
                        enemy_bullet_delay[enemy_counter] += enemies[enemy_counter][3].fire_rate
                if (math.sqrt((abs(player_rect.centerx - enemy_rects[enemy_counter].centerx)**2) + (abs(player_rect.centery - enemy_rects[enemy_counter].centery)**2)) < enemies[enemy_counter][3].agro_range) or enemies[enemy_counter][4]:
                    enemies[enemy_counter][4] = True
                    if enemies[enemy_counter][3].name == 'skull':
                        try:
                            skull_x_direction = skull_x_direction
                            skull_y_direction = skull_y_direction
                        except:
                            skull_x_direction = [-1, 1][random.randint(0, 1)]
                            skull_y_direction = [-1, 1][random.randint(0, 1)]
                        if True:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx+enemies[enemy_counter][3].speed*skull_x_direction), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].right < screenWidth and notTouchingWall:
                                enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed * skull_x_direction
                            else:
                                skull_x_direction = [-1, 1][random.randint(0, 1)]
                        
                        if True:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery+enemies[enemy_counter][3].speed*skull_y_direction))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].bottom < screenHeight and notTouchingWall:
                                enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed * skull_y_direction
                            else:
                                skull_y_direction = [-1, 1][random.randint(0, 1)]
                    elif enemies[enemy_counter][3].name == 'cyclops_turret':
                        noneLeft = True
                        for ct_enemy_counter in range(len(enemies)):
                            if enemies[ct_enemy_counter][3].name != 'cyclops_turret' and enemies[ct_enemy_counter][3].health > 0 and enemy_rects[ct_enemy_counter] != None:
                                noneLeft = False
                        if noneLeft and l5_boss_not_summoned == False:
                            enemies[enemy_counter][3].health = 0
                            enemy_rects[enemy_counter] = None
                    elif enemies[enemy_counter][3].name == 'sand_wraith':
                        if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                            enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                        else:
                            enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                        if (player_rect.centery > enemy_rects[enemy_counter].centery):
                            enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                        else:
                            enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
                    elif enemies[enemy_counter][3].name == 'living_boulder':
                        if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                            notTouchingEnemy = True
                            for enemy_index in range(len(enemies)):
                                if enemy_rects[enemy_index] != None  and enemy_index != enemy_counter:
                                    try:
                                        if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx+enemies[enemy_counter][3].speed), centery=enemy_rects[enemy_counter].centery)).colliderect(enemy_rects[enemy_index]):
                                            notTouchingEnemy = False
                                    except:
                                        useless = None
                            if enemy_rects[enemy_counter].right < screenWidth and notTouchingEnemy:
                                enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingEnemy = True
                            for enemy_index in range(len(enemies)):
                                if enemy_rects[enemy_index] != None  and enemy_index != enemy_counter:
                                    try:
                                        if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx)-enemies[enemy_counter][3].speed, centery=enemy_rects[enemy_counter].centery)).colliderect(enemy_rects[enemy_index]):
                                            notTouchingEnemy = False
                                    except:
                                        useless = None
                            if enemy_rects[enemy_counter].left > 0 and notTouchingEnemy:
                                enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                        
                        if (player_rect.centery > enemy_rects[enemy_counter].centery):
                            notTouchingEnemy = True
                            for enemy_index in range(len(enemies)):
                                if enemy_rects[enemy_index] != None  and enemy_index != enemy_counter:
                                    try:
                                        if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx), centery=enemy_rects[enemy_counter].centery+enemies[enemy_counter][3].speed)).colliderect(enemy_rects[enemy_index]):
                                            notTouchingEnemy = False
                                    except:
                                        useless = None
                            if enemy_rects[enemy_counter].bottom < screenHeight and notTouchingEnemy:
                                enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingEnemy = True
                            for enemy_index in range(len(enemies)):
                                if enemy_rects[enemy_index] != None  and enemy_index != enemy_counter:
                                    try:
                                        if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx), centery=enemy_rects[enemy_counter].centery-enemies[enemy_counter][3].speed)).colliderect(enemy_rects[enemy_index]):
                                            notTouchingEnemy = False
                                    except:
                                        useless = None
                            if enemy_rects[enemy_counter].top > 0 and notTouchingEnemy:
                                enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
                    elif enemies[enemy_counter][3].name == 'sand_pit':
                        if player_rect.colliderect(enemy_rects[enemy_counter]):
                            if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                                player_rect[0] -= 1
                            else:
                                player_rect[0] += 1
                            if (player_rect.centery > enemy_rects[enemy_counter].centery):
                                player_rect[1] -= 1
                            else:
                                player_rect[1] += 1
                        noneLeft = True
                        for pit_enemy_counter in range(len(enemies)):
                            if enemies[pit_enemy_counter][3].name != 'sand_pit' and enemies[pit_enemy_counter][3].health > 0 and enemy_rects[pit_enemy_counter] != None:
                                noneLeft = False
                        if noneLeft:
                            sand_pits = []
                            for sp_enemy_counter in range(len(enemies)):
                                if enemies[sp_enemy_counter][3].name == 'sand_pit':
                                    sand_pits.append([enemies[sp_enemy_counter], enemy_rects[sp_enemy_counter]])
                            
                            for sand_pit_counter in range(len(sand_pits)):
                                enemies[sand_pit_counter][3].health = 0
                            for _ in range(15):
                                for sand_pit_counter in range(len(sand_pits)):
                                    sand_pits[sand_pit_counter][0][0] = pygame.transform.rotozoom(sand_pits[sand_pit_counter][0][0], 0, (15-_)/15)
                                    sand_pits[sand_pit_counter][0][0].set_alpha(None)
                                    sand_pits[sand_pit_counter][0][0].set_colorkey((255, 255, 255))
                                screen.fill((0, 0, 0))
                                screen.blit(background, (0, 0))
                                for wall_row_counter in range(len(walls)):
                                    for wall_column_counter in range(len(walls[wall_row_counter])):
                                        try:
                                            screen.blit(walls[wall_row_counter][wall_column_counter], wall_rects[wall_row_counter][wall_column_counter])
                                        except:
                                            useless = None
                                screen.blit(player, player_rect)
                                for sand_pit_counter in range(len(sand_pits)):
                                    try:                                    
                                        screen.blit(sand_pits[sand_pit_counter][0][0], enemies[sand_pit_counter][0].get_rect(centerx=sand_pits[sand_pit_counter][1].centerx, centery=sand_pits[sand_pit_counter][1].centery))
                                    except:
                                        useless = None
                                pygame.display.flip()
                                time.sleep(0.1333)
                            for sand_pit_counter in range(len(sand_pits)):
                                enemy_rects[sand_pit_counter] = None
                            levels_won += 1
                            walls = render_level(levels[levels_won], assets_dir)[0]
                            wall_rects = render_level(levels[levels_won], assets_dir)[1]
                            player = render_level(levels[levels_won], assets_dir)[2][0]
                            player.set_alpha(None)
                            player.set_colorkey((255, 255, 255))
                            player_rect = render_level(levels[levels_won], assets_dir)[3][0]
                            wall_stats = render_level(levels[levels_won], assets_dir)[4]
                            enemies = render_level(levels[levels_won], assets_dir)[5]
                            for enemy_counter in range(len(enemies)):
                                enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                            enemy_rects = render_level(levels[levels_won], assets_dir)[6] 
                            
                            exit_blocks = []
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'exit':
                                        exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
            
                            player_shots = []
                            bullet_delay = 0
                            special_delay = 0
                            player_rof = player_staff[1]
                            player_prc = player_staff[2] - 1
                            if player_prc > 1:
                                bullet_speed = 10 * (player_prc//2)
                            else:
                                bullet_speed = 10
                            
                            enemy_shots = []
                            enemy_fire_rate = []
                            for enemy in enemies:
                                enemy_fire_rate.append(enemy[3].fire_rate)
                            enemy_bullet_delay = [0]*len(enemies)
                            enemies_alive = [True]*len(enemies)
                            explosions = []
                            
                            player_health = max_player_health
                            
                            if levels_won > 4:
                                background = pygame.image.load(assets_dir+'walls//background2.png')
                            if levels_won > 9:
                                background = pygame.image.load(assets_dir+'walls//background3.png')
                            break
                    elif enemies[enemy_counter][3].name == 'desert_worm_head':
                        if desert_worm_ai[desert_worm_ai_counter[0]] == 'w':
                            enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_1.png')
                        elif desert_worm_ai[desert_worm_ai_counter[0]] == 's':
                            enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_3.png')
                        elif desert_worm_ai[desert_worm_ai_counter[0]] == 'a':
                            enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_4.png')
                        elif desert_worm_ai[desert_worm_ai_counter[0]] == 'd':
                            enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                            enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_head_2.png')
                        enemies[enemy_counter][0].set_alpha(None)
                        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                        desert_worm_ai_counter[0] += 1
                        
                        dx = math.fabs(player_rect.centerx - enemy_rects[enemy_counter].centerx)
                        dy = math.fabs(player_rect.centery - enemy_rects[enemy_counter].centery)
                        if dx > dy:
                            if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                                desert_worm_ai += 'd'
                            else:
                                desert_worm_ai += 'a'
                        else:
                            if (player_rect.centery > enemy_rects[enemy_counter].centery):
                                desert_worm_ai += 's'
                            else:
                                desert_worm_ai += 'w'
                    elif enemies[enemy_counter][3].name == 'desert_worm_segment' or enemies[enemy_counter][3].name == 'desert_worm_tail':
                        if desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 'w':
                            enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_1.png')
                        elif desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 's':
                            enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_3.png')
                        elif desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 'a':
                            enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_4.png')
                        elif desert_worm_ai[desert_worm_ai_counter[enemy_counter]] == 'd':
                            enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                            if enemies[enemy_counter][3].name == 'desert_worm_tail':
                                enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//desert_worm_tail_2.png')
                        enemies[enemy_counter][0].set_alpha(None)
                        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                        desert_worm_ai_counter[enemy_counter] += 1
                    elif enemies[enemy_counter][3].name == 'fire_dragon':
                        try:
                            dx = player_rect.centerx - enemy_rects[enemy_counter].centerx
                            dy = player_rect.centery - enemy_rects[enemy_counter].centery
                            x_speed = DragonFireball().init_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                            y_speed = DragonFireball().init_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                            if dx < 0:
                                x_speed *= -1
                            if dy < 0:
                                y_speed *= -1
                        except ZeroDivisionError:
                            if (player_rect.centerx - enemy_rects[enemy_counter].centerx) > 0:
                                x_speed = DragonFireball().init_speed
                                y_speed = 0
                            elif (player_rect.centerx - enemy_rects[enemy_counter].centerx) < 0:
                                x_speed = -1 * DragonFireball().init_speed
                                y_speed = 0
                            else:
                                if (player_rect.centery - enemy_rects[enemy_counter].centery) > 0:
                                    x_speed = 0
                                    y_speed = DragonFireball().init_speed
                                else:
                                    x_speed = 0
                                    y_speed = -1 * DragonFireball().init_speed
                        enemies[enemy_counter][3].special_rate -= 1
                        if enemies[enemy_counter][3].special_rate <= 0:
                            enemies[enemy_counter][3].special_rate += enemies[enemy_counter][3].special_rate_rate
                            enemies.append([pygame.image.load(assets_dir+'sprites//dragon_fireball.png'), None, None, DragonFireball(), True])
                            enemies[-1][3].x_speed = x_speed
                            enemies[-1][3].y_speed = y_speed
                            enemies[-1][0].set_alpha(None)
                            enemies[-1][0].set_colorkey((255, 255, 255))
                            enemy_rects.append(pygame.image.load(assets_dir+'sprites//dragon_fireball.png').get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=enemy_rects[enemy_counter].centery))
                            enemies_alive.append(False)
                    elif enemies[enemy_counter][3].name == 'dragon_fireball':
                        enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].x_speed
                        enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].y_speed
                        enemies[enemy_counter][3].fire_rate -= 1
                        #screen.blit(pygame.image.load(assets_dir+'sprites//goblin.png'), enemy_rects[enemy_counter])
                        if enemies[enemy_counter][3].fire_rate <= 0:
                            enemies[enemy_counter][3].fire_rate += enemies[enemy_counter][3].fire_rate_rate
                            for cactus_bullet_entry in [[100, 0], [100, 100], [0, 100], [-100, 100], [-100, 0], [-100, -100], [0, -100], [100, -100]]:
                                try:
                                    dx = cactus_bullet_entry[0]
                                    dy = cactus_bullet_entry[1]
                                    x_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                                    y_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                                    if dx < 0:
                                        x_speed *= -1
                                    if dy < 0:
                                        y_speed *= -1
                                except ZeroDivisionError:
                                    if dx > 0:
                                        x_speed = enemies[enemy_counter][3].bullet_speed
                                        y_speed = 0
                                    elif dx < 0:
                                        x_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                        y_speed = 0
                                    else:
                                        if dy > 0:
                                            x_speed = 0
                                            y_speed = enemies[enemy_counter][3].bullet_speed
                                        else:
                                            x_speed = 0
                                            y_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                #enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, random.randint(enemies[enemy_counter][3].bullet_life[0], enemies[enemy_counter][3].bullet_life[1]), enemies[enemy_counter][3].ATK, 'cactus', [enemies[enemy_counter][3].bullet_life[0], enemies[enemy_counter][3].bullet_life[1], enemies[enemy_counter][3].ATK, enemies[enemy_counter][3].bullet_speed]])
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, random.randint(enemies[enemy_counter][3].bullet_life[0], enemies[enemy_counter][3].bullet_life[1]), enemies[enemy_counter][3].ATK, 'explosive', [enemy_rects[enemy_counter].centerx, enemy_rects[enemy_counter].centery]])                                
                                enemy_shots[-1][0].set_alpha(None)
                                enemy_shots[-1][0].set_colorkey((255, 255, 255))
                    else:
                        if (player_rect.centerx > enemy_rects[enemy_counter].centerx):
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx+enemies[enemy_counter][3].speed), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].right < screenWidth and notTouchingWall:
                                enemy_rects[enemy_counter][0] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=(enemy_rects[enemy_counter].centerx-enemies[enemy_counter][3].speed), centery=enemy_rects[enemy_counter].centery)).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].left > 0 and notTouchingWall:
                                enemy_rects[enemy_counter][0] -= enemies[enemy_counter][3].speed
                        
                        if player_rect.centery > enemy_rects[enemy_counter].centery:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery+enemies[enemy_counter][3].speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].bottom < screenHeight and notTouchingWall:
                                enemy_rects[enemy_counter][1] += enemies[enemy_counter][3].speed
                        else:
                            notTouchingWall = True
                            for wall_row_index in range(len(wall_rects)):
                                for wall_column_index in range(len(wall_rects[wall_row_index])):
                                    if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                        try:
                                            if (enemies[enemy_counter][0].get_rect(centerx=enemy_rects[enemy_counter].centerx, centery=(enemy_rects[enemy_counter].centery-enemies[enemy_counter][3].speed))).colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                notTouchingWall = False
                                        except:
                                            useless = None
                            if enemy_rects[enemy_counter].top > 0 and notTouchingWall:
                                enemy_rects[enemy_counter][1] -= enemies[enemy_counter][3].speed
        
        for enemy_shots_counter in range(len(enemy_shots)):
            if enemy_shots[enemy_shots_counter][1] != None:
                if enemy_shots[enemy_shots_counter][0].get_colorkey() != (255, 255, 255):
                    enemy_shots[enemy_shots_counter][0].set_alpha(None)
                    enemy_shots[enemy_shots_counter][0].set_colorkey((0, 0, 0, 0))
                enemy_shots[enemy_shots_counter][7][0] += enemy_shots[enemy_shots_counter][2]
                enemy_shots[enemy_shots_counter][7][1] += enemy_shots[enemy_shots_counter][3]
                enemy_shots[enemy_shots_counter][1][0] = round(enemy_shots[enemy_shots_counter][7][0])
                enemy_shots[enemy_shots_counter][1][1] = round(enemy_shots[enemy_shots_counter][7][1])
                if (enemy_shots[enemy_shots_counter][1][0] < 1) or (enemy_shots[enemy_shots_counter][1][0] >= screenWidth) or (enemy_shots[enemy_shots_counter][1][1] < 1) or (enemy_shots[enemy_shots_counter][1][1] >= screenHeight):
                    enemy_shots[enemy_shots_counter][1] = None
                for wall_row_index in range(len(wall_rects)):
                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                            try:
                                if enemy_shots[enemy_shots_counter][1].colliderect(wall_rects[wall_row_index][wall_column_index]):
                                    if enemy_shots[enemy_shots_counter][6] == 'explosive':
                                        explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                                    elif enemy_shots[enemy_shots_counter][6] == 'explosive_dw':
                                        explosions.append([pygame.image.load(assets_dir+'animations//desert_worm//bullet_explosion.png'), pygame.image.load(assets_dir+'animations//desert_worm//bullet_explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                                    enemy_shots[enemy_shots_counter][1] = None
                            except:
                                useless = None
                try:
                    if enemy_shots[enemy_shots_counter][1].colliderect(player_rect):
                        if godmode == False:
                            player_health -= enemy_shots[enemy_shots_counter][5]
                        if enemy_shots[enemy_shots_counter][6] == 'explosive':
                            explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                        elif enemy_shots[enemy_shots_counter][6] == 'explosive_dw':
                            explosions.append([pygame.image.load(assets_dir+'animations//desert_worm//bullet_explosion.png'), pygame.image.load(assets_dir+'animations//desert_worm//bullet_explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                        enemy_shots[enemy_shots_counter][1] = None
                except:
                    useless = None
                
        screen.fill((0, 255, 0))
        screen.blit(background, (0, 0))
        
        for wall_row_counter in range(len(walls)):
            for wall_column_counter in range(len(walls[wall_row_counter])):
                try:
                    screen.blit(walls[wall_row_counter][wall_column_counter], wall_rects[wall_row_counter][wall_column_counter])
                except:
                    useless = None        
        
#        screen.blit(player, player_rect)
        for enemy_counter in range(len(enemies)):
            if enemies[enemy_counter][3].name == 'sand_pit' and enemies[enemy_counter][3].health > 0 and enemy_rects[enemy_counter] != None:
                screen.blit(enemies[enemy_counter][0], enemy_rects[enemy_counter])
        
        for enemy_counter in range(len(enemies)):
            try:
                if enemies[enemy_counter][3].name == 'sand_snake':
                    if enemy_rects[enemy_counter].centerx > player_rect.centerx:
                        enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//sand_snake.png')
                    else:
                        enemies[enemy_counter][0] = pygame.image.load(assets_dir+'sprites//sand_snake_2.png')
                    enemies[enemy_counter][0].set_alpha(None)
                    enemies[enemy_counter][0].set_colorkey((255, 255, 255))
            except:
                useless = None
            try:
#                if levels_won == 14:
#                    for enemy_counter_2 in range(len(enemies)):
#                        if enemies[enemy_counter_2][3].name == 'sand_pit' and enemies[enemy_counter_2][3].health > 0:
#                            screen.blit(enemies[enemy_counter_2][0], enemy_rects[enemy_counter_2])
#                    for enemy_counter_2 in range(len(enemies)):
#                        if enemies[enemy_counter_2][3].name != 'sand_pit' and enemies[enemy_counter_2][3].health > 0:
#                            screen.blit(enemies[enemy_counter_2][0], enemy_rects[enemy_counter_2])
#                    pygame.display.flip()
                if enemies[enemy_counter][3].name != 'sand_pit':
                    if enemies[enemy_counter][3].health > 0 and enemy_rects[enemy_counter] != None:
                        screen.blit(enemies[enemy_counter][0], enemy_rects[enemy_counter])
                    else:
                        if enemies[enemy_counter][3].name == 'skeleton_trap' and enemy_rects[enemy_counter] != None:
                            for summon_counter in range(20):                        
                                summoned_skeleton_rect = pygame.image.load(assets_dir+'sprites//skeleton.png').get_rect(centerx=(enemy_rects[enemy_counter].centerx+random.randint(-100, 100)), centery=(enemy_rects[enemy_counter].centery+random.randint(-100, 100)))
                                summoned_skeleton_rect_not_touching = True
                                for wall_row_index in range(len(wall_rects)):
                                    for wall_column_index in range(len(wall_rects[wall_row_index])):
                                        if wall_stats[wall_row_index][wall_column_index] == 'wall':
                                            try:
                                                if summoned_skeleton_rect.colliderect(wall_rects[wall_row_index][wall_column_index]):
                                                    summoned_skeleton_rect_not_touching = False
                                            except:
                                                useless = None
                                if summoned_skeleton_rect_not_touching:
                                    enemies.append([pygame.image.load(assets_dir+'sprites//skeleton.png'), None, None, Skeleton(), True])                            
                                    enemy_rects.append(summoned_skeleton_rect)
                                    enemies_alive.append(True)
                            enemy_shots = []
                            enemy_fire_rate = []
                            for enemy in enemies:
                                enemy_fire_rate.append(enemy[3].fire_rate)
                            enemy_bullet_delay = [0]*len(enemies)
                            pygame.mixer.init()
                            pygame.mixer.music.load(assets_dir+'sounds//spooky_scary_skeletons.wav')
                            pygame.mixer.music.play()
                        if (enemies[enemy_counter][3].name == 'angry_cactus' or enemies[enemy_counter][3].name == 'living_bomb') and enemy_rects[enemy_counter] != None:
                            for cactus_bullet_entry in [[100, 0], [100, 100], [0, 100], [-100, 100], [-100, 0], [-100, -100], [0, -100], [100, -100]]:
                                try:
                                    dx = cactus_bullet_entry[0]
                                    dy = cactus_bullet_entry[1]
                                    x_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dy**2)/(dx**2))))
                                    y_speed = enemies[enemy_counter][3].bullet_speed/(math.sqrt(1+((dx**2)/(dy**2))))
                                    if dx < 0:
                                        x_speed *= -1
                                    if dy < 0:
                                        y_speed *= -1
                                except ZeroDivisionError:
                                    if dx > 0:
                                        x_speed = enemies[enemy_counter][3].bullet_speed
                                        y_speed = 0
                                    elif dx < 0:
                                        x_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                        y_speed = 0
                                    else:
                                        if dy > 0:
                                            x_speed = 0
                                            y_speed = enemies[enemy_counter][3].bullet_speed
                                        else:
                                            x_speed = 0
                                            y_speed = -1 * enemies[enemy_counter][3].bullet_speed
                                enemy_shots.append([(pygame.transform.rotozoom(enemies[enemy_counter][3].bullet, 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemies[enemy_counter][3].bullet).get_rect(centerx = enemy_rects[enemy_counter].centerx, centery = enemy_rects[enemy_counter].centery), x_speed, y_speed, enemies[enemy_counter][3].bullet_life, enemies[enemy_counter][3].ATK, 'bullet'])
                        if enemy_rects[enemy_counter] != None:
                            total_xp += random.randint(enemies[enemy_counter][3].xp[0], enemies[enemy_counter][3].xp[1])
                            total_money += random.randint(enemies[enemy_counter][3].money[0], enemies[enemy_counter][3].money[1])
                        enemy_rects[enemy_counter] = None
    #                    if enemies[enemy_counter][2] != None:
                        enemies_alive[enemy_counter] = False
            except:
                useless = None
                
        screen.blit(player, player_rect)

        for player_shot in player_shots:
            try:
                screen.blit(player_shot[0], player_shot[1])
            except:
                useless = None
        
        for enemy_shots_counter in range(len(enemy_shots)):
            try:
                enemy_shots[enemy_shots_counter][4] -= 1
            except:
                useless = None
            if enemy_shots[enemy_shots_counter][4] > 0:
                try:
                    screen.blit(enemy_shots[enemy_shots_counter][0], enemy_shots[enemy_shots_counter][1])
                except:
                    useless = None
            if (enemy_shots[enemy_shots_counter][6] == 'explosive') and (enemy_shots[enemy_shots_counter][4] == 0):
                try:
                    explosions.append([pygame.image.load(assets_dir+'animations//skull//explosion.png'), pygame.image.load(assets_dir+'animations//skull//explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                except:
                    useless = None
            if (enemy_shots[enemy_shots_counter][6] == 'explosive_dw') and (enemy_shots[enemy_shots_counter][4] == 0):
                try:
                    explosions.append([pygame.image.load(assets_dir+'animations//desert_worm//bullet_explosion.png'), pygame.image.load(assets_dir+'animations//desert_worm//bullet_explosion.png').get_rect(centerx=enemy_shots[enemy_shots_counter][1].centerx, centery=enemy_shots[enemy_shots_counter][1].centery), 50, enemy_shots[enemy_shots_counter][5]])
                except:
                    useless = None
            if (enemy_shots[enemy_shots_counter][6] == 'cactus') and (enemy_shots[enemy_shots_counter][4] == 0) and (enemy_shots[enemy_shots_counter][1] != None):
                for cactus_bullet_entry in [[100, 0], [100, 100], [0, 100], [-100, 100], [-100, 0], [-100, -100], [0, -100], [100, -100]]:
                    try:
                        dx = cactus_bullet_entry[0]
                        dy = cactus_bullet_entry[1]
                        x_speed = enemy_shots[enemy_shots_counter][7][3]/(math.sqrt(1+((dy**2)/(dx**2))))
                        y_speed = enemy_shots[enemy_shots_counter][7][3]/(math.sqrt(1+((dx**2)/(dy**2))))
                        if dx < 0:
                            x_speed *= -1
                        if dy < 0:
                            y_speed *= -1
                    except ZeroDivisionError:
                        if dx > 0:
                            x_speed = enemy_shots[enemy_shots_counter][7][3]
                            y_speed = 0
                        elif dx < 0:
                            x_speed = -1 * enemy_shots[enemy_shots_counter][7][3]
                            y_speed = 0
                        else:
                            if dy > 0:
                                x_speed = 0
                                y_speed = enemy_shots[enemy_shots_counter][7][3]
                            else:
                                x_speed = 0
                                y_speed = -1 * enemy_shots[enemy_shots_counter][7][3]
                    #min, max, atk, speed
                    enemy_shots.append([(pygame.transform.rotozoom(enemy_shots[enemy_shots_counter][0], 180 + math.degrees(math.atan2(dx, dy)), 1)), (enemy_shots[enemy_shots_counter][0]).get_rect(centerx = enemy_shots[enemy_shots_counter][1].centerx, centery = enemy_shots[enemy_shots_counter][1].centery), x_speed, y_speed, random.randint(enemy_shots[enemy_shots_counter][7][0], enemy_shots[enemy_shots_counter][7][1]), enemy_shots[enemy_shots_counter][7][2], 'bullet'])
                    enemy_shots[-1][0].set_alpha(None)
                    enemy_shots[-1][0].set_colorkey((255, 255, 255))
            if enemy_shots[enemy_shots_counter][4] < 1:
                enemy_shots[enemy_shots_counter][1] = None
        
        for explosion in explosions:
            if explosion[2] > 0:
                explosion[2] -= 1
                explosion[0].set_alpha(None)
                explosion[0].set_colorkey(explosion[0].get_at((0, 0)))
                screen.blit(explosion[0], explosion[1])
                if explosion[1].colliderect(player_rect) and godmode == False:
                    player_health -= 1
        
        if (enemies_alive == [False]*(len(enemies)-2) + [True]*(2)) and levels_won == 4 and l5_boss_not_summoned:           
            cyclops_particles_image = Image.open(assets_dir+'animations//cyclops//particles.png')
            cyclops_particles_pil = Image.fromstring('RGBA', cyclops_particles_image.size, cyclops_particles_image.tostring())
            for counter in range(0, 30):
                cyclops_particles_pil = cyclops_particles_pil.rotate(36, Image.BICUBIC)
                cyclops_particles_pil = cyclops_particles_pil.resize((int(10*1.1**counter), int(10*1.1**counter)), Image.BICUBIC)
                cyclops_particles_frame = pygame.image.fromstring(cyclops_particles_pil.tostring(), cyclops_particles_pil.size, "RGBA")
                cyclops_particles_frame.set_alpha(None)                
                cyclops_particles_frame.set_colorkey((0, 0, 0, 0))
                screen.blit(cyclops_particles_frame, cyclops_particles_frame.get_rect(centerx=480, centery=100))
                pygame.display.flip()                
                time.sleep(0.05)
            enemies_alive.append(True)
            enemies.append([pygame.image.load(assets_dir+'sprites//cyclops.png'), None, None, Cyclops(), True])
            enemy_rects.append(pygame.image.load(assets_dir+'sprites//cyclops.png').get_rect(centerx=480, centery=100))
            enemy_shots = []
            enemy_fire_rate = []
            for enemy in enemies:
                enemy_fire_rate.append(enemy[3].fire_rate)
            enemy_bullet_delay = [0]*len(enemies)
            l5_boss_not_summoned = False
        
        if l15_init == False and levels_won == 14:
            l15_init = True
            sand_pit_coords = [(120, 300), (440, 350), (560, 560), (160, 200), (370, 580), (600, 190), (800, 600), (200, 550), (800, 300), (400, 200)]
            for sand_pit_coord in sand_pit_coords:
                enemies.append([pygame.image.load(assets_dir+'sprites//sand_pit.png'), None, None, SandPit(), True])
                enemy_rects.append(pygame.image.load(assets_dir+'sprites//sand_pit.png').get_rect(centerx=sand_pit_coord[0], centery=sand_pit_coord[1]))
                enemy_bullet_delay.append(0)
                enemies_alive.append(True)
        
        for enemy_counter in range(len(enemies)):
            if enemies[enemy_counter][3].name == 'desert_worm_head' and enemies[enemy_counter][3].health < 1:
                enemies_alive = [False]*len(enemies)
                dw_explosion = pygame.image.load(assets_dir+'animations//desert_worm//explosion.png')
                dw_explosion.set_alpha(None)
                dw_explosion.set_colorkey((0, 0, 0))
                for _ in range(30):
#                    r_enemy_rect = None
#                    while r_enemy_rect == None:
#                        r_enemy_rect = random.choice(enemy_rects)
                    r_enemy_rect = None
                    while r_enemy_rect == None:
                        r_enemy_index = random.randint(0, len(enemies)-1)
                        if enemies[r_enemy_index][3].name != 'sand_pit' and enemy_rects[r_enemy_index] != None:
                            r_enemy_rect = enemy_rects[r_enemy_index]
                    screen.blit(dw_explosion, dw_explosion.get_rect(centerx=r_enemy_rect.centerx+random.randint(-15, 15), centery=r_enemy_rect.centery+random.randint(-15, 15)))
                    pygame.display.flip()
                    time.sleep(0.075)
                for enemy_rect_counter in range(len(enemy_rects)):
                    enemy_rects[enemy_rect_counter] = None
                player_rect[0] = exit_blocks[0][0]
                player_rect[1] = exit_blocks[0][1]
                #print('a')
        
        for exit_block in exit_blocks:
            if player_rect.colliderect(exit_block) and (enemies_alive == [False]*len(enemies)):
                try:
                    levels_won += 1
                    walls = render_level(levels[levels_won], assets_dir)[0]
                    wall_rects = render_level(levels[levels_won], assets_dir)[1]
                    player = render_level(levels[levels_won], assets_dir)[2][0]
                    player.set_alpha(None)
                    player.set_colorkey((255, 255, 255))
                    player_rect = render_level(levels[levels_won], assets_dir)[3][0]
                    wall_stats = render_level(levels[levels_won], assets_dir)[4]
                    enemies = render_level(levels[levels_won], assets_dir)[5]
                    for enemy_counter in range(len(enemies)):
                        enemies[enemy_counter][0].set_colorkey((255, 255, 255))
                    enemy_rects = render_level(levels[levels_won], assets_dir)[6] 
                    
                    exit_blocks = []
                    for wall_row_index in range(len(wall_rects)):
                        for wall_column_index in range(len(wall_rects[wall_row_index])):
                            if wall_stats[wall_row_index][wall_column_index] == 'exit':
                                exit_blocks.append(wall_rects[wall_row_index][wall_column_index])
    
                    player_shots = []
                    bullet_delay = 0
                    special_delay = 0
                    player_rof = player_staff[1]
                    player_prc = player_staff[2] - 1
                    if player_prc > 1:
                        bullet_speed = 10 * (player_prc//2)
                    else:
                        bullet_speed = 10
                    
                    enemy_shots = []
                    enemy_fire_rate = []
                    for enemy in enemies:
                        enemy_fire_rate.append(enemy[3].fire_rate)
                    enemy_bullet_delay = [0]*len(enemies)
                    enemies_alive = [True]*len(enemies)
                    explosions = []
                    
                    player_health = max_player_health
                    
                    if levels_won <= 4:
                        background = pygame.image.load(assets_dir+'walls//background1.png')
                    elif levels_won > 4 and levels_won <= 9:
                        background = pygame.image.load(assets_dir+'walls//background2.png')
                    elif levels_won > 9 and levels_won <= 14:
                        background = pygame.image.load(assets_dir+'walls//background3.png')
                    elif levels_won > 14:
                        background = pygame.image.load(assets_dir+'walls//background4.png')
                except:
                    return [total_money, total_xp, levels_won]
        
        if godmode:
            text('HP: '+str(player_health)+'/'+str(max_player_health), screen, [255, 0, 0], [screenWidth, 0], 30, topRight=True)
        else:
            text('HP: '+str(player_health)+'/'+str(max_player_health), screen, [0, 0, 0], [screenWidth, 0], 30, topRight=True)

        text('MP: '+str(int(player_mana))+'/'+str(max_player_mana), screen, [0, 0, 0], [screenWidth, 35], 30, topRight=True)
        
        if player_dmg > player_staff[0]*10:
            text('DMG: x'+str(player_dmg//player_staff[0]), screen, [255, 0, 0], [screenWidth, 70], 30, topRight=True)
        elif player_dmg > player_staff[0]:
            text('DMG: x'+str(player_dmg//player_staff[0]), screen, [0, 0, 0], [screenWidth, 70], 30, topRight=True)
        
        if player_health <= 0:
            return [total_money, total_xp, levels_won]
        
        pygame.display.flip()
        if bullet_delay > 0:
            bullet_delay -= 1
        if player_mana < max_player_mana:
            player_mana += 0.5
        for enemy_bullet_delay_counter in range(len(enemy_bullet_delay)):
            if enemy_bullet_delay[enemy_bullet_delay_counter] > 0:
                enemy_bullet_delay[enemy_bullet_delay_counter] -= 1
        
        if oTimer > 0:
            oTimer -= 1
        if pTimer > 0:
            pTimer -= 1
        if kTimer > 0:
            kTimer -= 1
        if iTimer > 0:
            iTimer -= 1
        if nTimer > 0:
            nTimer -= 1
        clock.tick(200)

def encrypt (string, value=200, flush=True):
    f_string = ''
    for chtr in string:
        try:
            f_string += chr(value-ord(chtr))
        except:
            print([chtr, value, ord(chtr), value-ord(chtr)])
            sys.exit()
        if flush:
            value -= 1
    return f_string

def shop_staff (screen):
    global assets_dir
    global modStaffChanges
    
    save_file = open(assets_dir + 'shop.loxd', 'rb')
    save_file_contents = (save_file.read()).decode()
    save_file.close()
    save_info = encrypt(save_file_contents, value=200, flush=False)
    money = int(save_info.split('\n')[0])
    xp = int(save_info.split('\n')[1])
    element = save_info.split('\n')[2]
    tier = int(save_info.split('\n')[3])
    r_tier = int(save_info.split('\n')[4])
    rune_tier = int(save_info.split('\n')[5])
#    print(tier)
    
    staff_cost = [0, 0, 500, 2000, 8000, 30000, 100000]
    for modStaffChange in modStaffChanges:
        # staff.2 = 500
        # [2, 500]
        if len(modStaffChange) == 2:
            staff_cost[modStaffChange[0]] = modStaffChange[1]
    
    lvls = [0, 0, 500, 2000, 8000, 30000, 100000]
    lvl = 0
    for lvls_counter in range(len(lvls)):
        if xp >= lvls[lvls_counter]:
            lvl = lvls_counter
    
    while True:    
        background = pygame.image.load(assets_dir+'screens//shop.png')
        screen.blit(background, (0, 0))
        text('Gold: '+str(money), screen, [0, 0, 0], [10, 10], 30, topLeft=True)
        text('Level: '+str(lvl), screen, [0, 0, 0], [10, 35], 30, topLeft=True)
        
        text('Fire', screen, [250, 80, 0], [10, 150], 30, topLeft=True)
        text('Ice', screen, [0, 170, 220], [10, 267], 30, topLeft=True)
        text('Lightning', screen, [230, 230, 0], [10, 383], 30, topLeft=True)
        text('Dark Arts', screen, [130, 0, 255], [10, 500], 30, topLeft=True)
        
        tier_counter = 1
        fire_staff_icons = [pygame.image.load(assets_dir+'shop//f_1.png'), pygame.image.load(assets_dir+'shop//f_2.png'), pygame.image.load(assets_dir+'shop//f_3.png'), pygame.image.load(assets_dir+'shop//f_4.png'), pygame.image.load(assets_dir+'shop//f_5.png')]
        l_fire_staff_icons = [pygame.image.load(assets_dir+'shop//f_1_locked.png'), pygame.image.load(assets_dir+'shop//f_2_locked.png'), pygame.image.load(assets_dir+'shop//f_3_locked.png'), pygame.image.load(assets_dir+'shop//f_4_locked.png'), pygame.image.load(assets_dir+'shop//f_5_locked.png')]
        for fire_staff_coords in [[180, 150], [320, 150], [480, 150], [630, 150], [780, 150]]:
            if tier_counter > tier or (element != 'fire'):
                screen.blit(l_fire_staff_icons[tier_counter-1], fire_staff_icons[tier_counter-1].get_rect(centerx=fire_staff_coords[0], centery=fire_staff_coords[1]))
            else:
                screen.blit(fire_staff_icons[tier_counter-1], fire_staff_icons[tier_counter-1].get_rect(centerx=fire_staff_coords[0], centery=fire_staff_coords[1]))
            tier_counter += 1
        
        tier_counter = 1
        ice_staff_icons = [pygame.image.load(assets_dir+'shop//i_1.png'), pygame.image.load(assets_dir+'shop//i_2.png'), pygame.image.load(assets_dir+'shop//i_3.png'), pygame.image.load(assets_dir+'shop//i_4.png'), pygame.image.load(assets_dir+'shop//i_5.png')]
        l_ice_staff_icons = [pygame.image.load(assets_dir+'shop//i_1_locked.png'), pygame.image.load(assets_dir+'shop//i_2_locked.png'), pygame.image.load(assets_dir+'shop//i_3_locked.png'), pygame.image.load(assets_dir+'shop//i_4_locked.png'), pygame.image.load(assets_dir+'shop//i_5_locked.png')]
        for ice_staff_coords in [[180, 267], [320, 267], [480, 267], [630, 267], [780, 267]]:
            if tier_counter > tier or (element != 'ice'):
                screen.blit(l_ice_staff_icons[tier_counter-1], ice_staff_icons[tier_counter-1].get_rect(centerx=ice_staff_coords[0], centery=ice_staff_coords[1]))
            else:
                screen.blit(ice_staff_icons[tier_counter-1], ice_staff_icons[tier_counter-1].get_rect(centerx=ice_staff_coords[0], centery=ice_staff_coords[1]))
            tier_counter += 1
        
        tier_counter = 1
        lightning_staff_icons = [pygame.image.load(assets_dir+'shop//l_1.png'), pygame.image.load(assets_dir+'shop//l_2.png'), pygame.image.load(assets_dir+'shop//l_3.png'), pygame.image.load(assets_dir+'shop//l_4.png'), pygame.image.load(assets_dir+'shop//l_5.png')]
        l_lightning_staff_icons = [pygame.image.load(assets_dir+'shop//l_1_locked.png'), pygame.image.load(assets_dir+'shop//l_2_locked.png'), pygame.image.load(assets_dir+'shop//l_3_locked.png'), pygame.image.load(assets_dir+'shop//l_4_locked.png'), pygame.image.load(assets_dir+'shop//l_5_locked.png')]
        for lightning_staff_coords in [[180, 383], [320, 383], [480, 383], [630, 383], [780, 383]]:
            if tier_counter > tier or (element != 'lightning'):
                screen.blit(l_lightning_staff_icons[tier_counter-1], lightning_staff_icons[tier_counter-1].get_rect(centerx=lightning_staff_coords[0], centery=lightning_staff_coords[1]))
            else:
                screen.blit(lightning_staff_icons[tier_counter-1], lightning_staff_icons[tier_counter-1].get_rect(centerx=lightning_staff_coords[0], centery=lightning_staff_coords[1]))
            tier_counter += 1
        
        tier_counter = 1
        dark_arts_staff_icons = [pygame.image.load(assets_dir+'shop//d_1.png'), pygame.image.load(assets_dir+'shop//d_2.png'), pygame.image.load(assets_dir+'shop//d_3.png'), pygame.image.load(assets_dir+'shop//d_4.png'), pygame.image.load(assets_dir+'shop//d_5.png')]
        l_dark_arts_staff_icons = [pygame.image.load(assets_dir+'shop//d_1_locked.png'), pygame.image.load(assets_dir+'shop//d_2_locked.png'), pygame.image.load(assets_dir+'shop//d_3_locked.png'), pygame.image.load(assets_dir+'shop//d_4_locked.png'), pygame.image.load(assets_dir+'shop//d_5_locked.png')]
        for dark_arts_staff_coords in [[180, 500], [320, 500], [480, 500], [630, 500], [780, 500]]:
            if tier_counter > tier or (element != 'dark_arts'):
                screen.blit(l_dark_arts_staff_icons[tier_counter-1], dark_arts_staff_icons[tier_counter-1].get_rect(centerx=dark_arts_staff_coords[0], centery=dark_arts_staff_coords[1]))
            else:
                screen.blit(dark_arts_staff_icons[tier_counter-1], dark_arts_staff_icons[tier_counter-1].get_rect(centerx=dark_arts_staff_coords[0], centery=dark_arts_staff_coords[1]))
            tier_counter += 1
        
        if tier < 6:
            screen.blit(pygame.image.load(assets_dir+'shop//6_locked.png'), pygame.image.load(assets_dir+'shop//6_locked.png').get_rect(centerx=930, centery=325))
        else:
            screen.blit(pygame.image.load(assets_dir+'shop//6.png'), pygame.image.load(assets_dir+'shop//6.png').get_rect(centerx=930, centery=325))
        
        pygame.display.flip()
        
        coords = [[160, 200], [300, 340], [460, 500], [610, 650], [760, 800]]
    
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN and (event.key == pygame.K_RETURN):
                try:
#                    if tier > int(save_info.split('\n')[3]):
                        save_file_output = str(money)+'\n'+str(xp)+'\n'+str(element)+'\n'+str(tier)+'\n'+str(r_tier)+'\n'+str(rune_tier)
                        #print(save_file_output)                        
                        e_save_file_output = encrypt(save_file_output, value=200, flush=False)
                        save_file = open(assets_dir+'shop.loxd', 'wb')
                        save_file.write(e_save_file_output.encode())
                        save_file.close()
                        
                        #dmg, rof, prc
                        fire_staffs =      [[1, 1, 1], [2, 1, 1], [3, 2, 1], [4, 2, 2], [5, 3, 3]]
                        ice_staffs =       [[1, 1, 1], [1, 1, 3], [2, 1, 4], [2, 2, 4], [4, 2, 6]]
                        lightning_staffs = [[1, 1, 1], [1, 2, 1], [2, 3, 1], [2, 4, 2], [3, 5, 3]]
                        dark_arts_staffs = [[1, 1, 1], [2, 1, 2], [2, 2, 2], [3, 3, 3], [4, 4 ,3]]
                        t6_staff = [5, 5, 8]
                        
                        staffLayout = {'dmg':0, 'rof':1, 'prc':2}
                        for modStaffChange in modStaffChanges:
                            if len(modStaffChange) == 4:
                                # staff.fire.3.dmg = 2
                                #['fire', '3', 'dmg', 2]
                                if modStaffChange[0].lower() == 'fire':
                                    fire_staffs[int(modStaffChange[1])-1][staffLayout[modStaffChange[2]]] = modStaffChange[3]
                                elif modStaffChange[0].lower() == 'ice':
                                    ice_staffs[int(modStaffChange[1])-1][staffLayout[modStaffChange[2]]] = modStaffChange[3]
                                elif modStaffChange[0].lower() == 'lightning':
                                    lightning_staffs[int(modStaffChange[1])-1][staffLayout[modStaffChange[2]]] = modStaffChange[3]
                                elif modStaffChange[0].lower() == 'dark_arts':
                                    dark_arts_staffs[int(modStaffChange[1])-1][staffLayout[modStaffChange[2]]] = modStaffChange[3]
                                elif modStaffChange[0].lower() == 't6':
                                    t6_staff[staffLayout[modStaffChange[2]]] = modStaffChange[3]
                        
                        if tier == 6:
                            staff_list = t6_staff
                        elif element == 'fire':
                            staff_list = fire_staffs[tier-1]
                        elif element == 'ice':
                            staff_list = ice_staffs[tier-1]
                        elif element == 'lightning':
                            staff_list = lightning_staffs[tier-1]
                        elif element == 'dark_arts':
                            staff_list = dark_arts_staffs[tier-1]
                        else:
                            staff_list = [1, 1, 1]
                        staff = str(staff_list[0])+'\n'+str(staff_list[1])+'\n'+str(staff_list[2])
                        staff_file = open(assets_dir+'staff.loxd', 'wb')   
                        staff_file.write(encrypt(staff, value=200, flush=False).encode())
                        staff_file.close()
                except:
                    useless = None
                
                if event.key == pygame.K_RETURN:
                    return None
        mouse_pos = pygame.mouse.get_pos()
        if pygame.mouse.get_pressed()[0]:
#            print('1')
            if mouse_pos[1] > 130 and mouse_pos[1] < 170 and (element == 'fire' or element == 'none'):
                for staff_counter in range(len(coords)):
                    if lvl >= tier+1 and money >= staff_cost[tier+1] and mouse_pos[0] > coords[staff_counter][0] and mouse_pos[0] < coords[staff_counter][1] and staff_counter == tier:
                        tier += 1
                        money -= staff_cost[tier]
                        element = 'fire'
            if mouse_pos[1] > 247 and mouse_pos[1] < 287 and (element == 'ice' or element == 'none'):
                for staff_counter in range(len(coords)):
                    if lvl >= tier+1 and money >= staff_cost[tier+1] and mouse_pos[0] > coords[staff_counter][0] and mouse_pos[0] < coords[staff_counter][1] and staff_counter == tier:
                        tier += 1
                        money -= staff_cost[tier]
                        element = 'ice'
            if mouse_pos[1] > 363 and mouse_pos[1] < 403 and (element == 'lightning' or element == 'none'):
                for staff_counter in range(len(coords)):
                    if lvl >= tier+1 and money >= staff_cost[tier+1] and mouse_pos[0] > coords[staff_counter][0] and mouse_pos[0] < coords[staff_counter][1] and staff_counter == tier:
                        tier += 1
                        money -= staff_cost[tier]
                        element = 'lightning'
            if mouse_pos[1] > 480 and mouse_pos[1] < 520 and (element == 'dark_arts' or element == 'none'):
                for staff_counter in range(len(coords)):
                    if lvl >= tier+1 and money >= staff_cost[tier+1] and mouse_pos[0] > coords[staff_counter][0] and mouse_pos[0] < coords[staff_counter][1] and staff_counter == tier:
                        tier += 1
                        money -= staff_cost[tier]
                        element = 'dark_arts'
            if mouse_pos[0] > 910 and mouse_pos[0] < 950 and mouse_pos[1] > 305 and mouse_pos[1] < 345 and lvl >= 6 and money >= 100000 and tier == 5:
                tier += 1
                money -= 100000

def shop_robe (screen):
    global assets_dir
    global modRobeChanges
    
    save_file = open(assets_dir + 'shop.loxd', 'rb')
    save_file_contents = (save_file.read()).decode()
    save_file.close()
    save_info = encrypt(save_file_contents, value=200, flush=False)
    money = int(save_info.split('\n')[0])
    xp = int(save_info.split('\n')[1])
    element = save_info.split('\n')[2]
    s_tier = int(save_info.split('\n')[3])
    tier = int(save_info.split('\n')[4])
    rune_tier = int(save_info.split('\n')[5])
    
    robe_cost = [0, 50, 150, 500, 2000, 5000, 12000, 35000, 10000000]
    for modRobeChange in modRobeChanges:
        #[tier, field, value]
        if modRobeChange[1].lower() == 'cost':
            robe_cost[modRobeChange[0]] = modRobeChange[2]
    
    while True:    
        background = pygame.image.load(assets_dir+'screens//shop.png')
        screen.blit(background, (0, 0))
        text('Gold: '+str(money), screen, [0, 0, 0], [10, 10], 30, topLeft=True)
        
        tier_counter = 1
        robe_icons = [pygame.image.load(assets_dir+'shop//r_1.png'), pygame.image.load(assets_dir+'shop//r_2.png'), pygame.image.load(assets_dir+'shop//r_3.png'), pygame.image.load(assets_dir+'shop//r_4.png'), pygame.image.load(assets_dir+'shop//r_5.png'), pygame.image.load(assets_dir+'shop//r_6.png'), pygame.image.load(assets_dir+'shop//r_7.png')]
        l_robe_icons = [pygame.image.load(assets_dir+'shop//r_1_locked.png'), pygame.image.load(assets_dir+'shop//r_2_locked.png'), pygame.image.load(assets_dir+'shop//r_3_locked.png'), pygame.image.load(assets_dir+'shop//r_4_locked.png'), pygame.image.load(assets_dir+'shop//r_5_locked.png'), pygame.image.load(assets_dir+'shop//r_6_locked.png'), pygame.image.load(assets_dir+'shop//r_7_locked.png')]
        for robe_coords in [[150, 250], [250, 250], [350, 250], [450, 250], [550, 250], [650, 250], [750, 250]]:
            if tier_counter > tier:
                #print(tier_counter, tier)
                screen.blit(l_robe_icons[tier_counter-1], robe_icons[tier_counter-1].get_rect(centerx=robe_coords[0], centery=robe_coords[1]))
            else:
                screen.blit(robe_icons[tier_counter-1], robe_icons[tier_counter-1].get_rect(centerx=robe_coords[0], centery=robe_coords[1]))
            tier_counter += 1
        
        pygame.display.flip()
        
        coords = [[130, 170], [230, 270], [330, 370], [430, 470], [530, 570], [630, 670], [730, 770]]
    
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN and (event.key == pygame.K_RETURN):
                try:
                    save_file_output = str(money)+'\n'+str(xp)+'\n'+str(element)+'\n'+str(s_tier)+'\n'+str(tier)+'\n'+str(rune_tier)
                    e_save_file_output = encrypt(save_file_output, value=200, flush=False)
                    save_file = open(assets_dir+'shop.loxd', 'wb')
                    save_file.write(e_save_file_output.encode())
                    save_file.close()
                    #print(save_file_output)
                    
                    robe_stats = [[10, 10], [20, 25], [30, 40], [60, 100], [100, 150], [175, 250], [300, 500]]
                    robe_layout = {'hp':0, 'mp':1}                    
                    for modRobeChange in modRobeChanges:
                        #[tier, field, value]
                        if modRobeChange[1].lower() in ['hp', 'mp']:
                            robe_stats[modRobeChange[0]-1][robe_layout[modRobeChange[1].lower()]] = modRobeChange[2]
                    
                    if tier > 0:
                        robe_list = robe_stats[tier-1]
                        robe = str(robe_list[0])+'\n'+str(robe_list[1])
                        robe_file = open(assets_dir+'robe.loxd', 'wb')   
                        robe_file.write(encrypt(robe, value=200, flush=False).encode())
                        robe_file.close()
                except:
                    useless = None
                if event.key == pygame.K_RETURN:
                    return None
        mouse_pos = pygame.mouse.get_pos()
        if pygame.mouse.get_pressed()[0]:
            if mouse_pos[1] > 230 and mouse_pos[1] < 270:
                for robe_counter in range(len(coords)):
                    if money >= robe_cost[tier+1] and mouse_pos[0] > coords[robe_counter][0] and mouse_pos[0] < coords[robe_counter][1] and robe_counter == tier:
                        tier += 1
                        money -= robe_cost[tier]

def shop_rune (screen):
    global assets_dir
    global modRuneChanges
    
    save_file = open(assets_dir + 'shop.loxd', 'rb')
    save_file_contents = (save_file.read()).decode()
    save_file.close()
    save_info = encrypt(save_file_contents, value=200, flush=False)
    money = int(save_info.split('\n')[0])
    xp = int(save_info.split('\n')[1])
    element = save_info.split('\n')[2]
    s_tier = int(save_info.split('\n')[3])
    r_tier = int(save_info.split('\n')[4])
    tier = int(save_info.split('\n')[5])
#    print(tier)
    
    rune_cost = [0, 100, 2000, 40000, 100000000]
    for modRuneChange in modRuneChanges:
        # staff.2 = 500
        # [2, 500]
        if len(modRuneChange) == 2:
            rune_cost[modRuneChange[0]] = modRuneChange[1]
    
    
    while True:    
        background = pygame.image.load(assets_dir+'screens//shop.png')
        screen.blit(background, (0, 0))
        text('Gold: '+str(money), screen, [0, 0, 0], [10, 10], 30, topLeft=True)
        
        text('Fire', screen, [250, 80, 0], [10, 150], 30, topLeft=True)
        text('Ice', screen, [0, 170, 220], [10, 267], 30, topLeft=True)
        text('Lightning', screen, [230, 230, 0], [10, 383], 30, topLeft=True)
        text('Dark Arts', screen, [130, 0, 255], [10, 500], 30, topLeft=True)
        
        tier_counter = 1
        fire_rune_icons = [pygame.image.load(assets_dir+'shop//rune_f_1.png'), pygame.image.load(assets_dir+'shop//rune_f_2.png'), pygame.image.load(assets_dir+'shop//rune_f_3.png')]
        l_fire_rune_icons = [pygame.image.load(assets_dir+'shop//rune_f_1_locked.png'), pygame.image.load(assets_dir+'shop//rune_f_2_locked.png'), pygame.image.load(assets_dir+'shop//rune_f_3_locked.png')]
        for fire_rune_coords in [[180, 150], [480, 150], [780, 150]]:
            if tier_counter > tier or (element != 'fire'):
                screen.blit(l_fire_rune_icons[tier_counter-1], fire_rune_icons[tier_counter-1].get_rect(centerx=fire_rune_coords[0], centery=fire_rune_coords[1]))
            else:
                screen.blit(fire_rune_icons[tier_counter-1], fire_rune_icons[tier_counter-1].get_rect(centerx=fire_rune_coords[0], centery=fire_rune_coords[1]))
            tier_counter += 1
        
        tier_counter = 1
        ice_rune_icons = [pygame.image.load(assets_dir+'shop//rune_i_1.png'), pygame.image.load(assets_dir+'shop//rune_i_2.png'), pygame.image.load(assets_dir+'shop//rune_i_3.png')]
        l_ice_rune_icons = [pygame.image.load(assets_dir+'shop//rune_i_1_locked.png'), pygame.image.load(assets_dir+'shop//rune_i_2_locked.png'), pygame.image.load(assets_dir+'shop//rune_i_3_locked.png')]
        for ice_rune_coords in [[180, 267], [480, 267], [780, 267]]:
            if tier_counter > tier or (element != 'ice'):
                screen.blit(l_ice_rune_icons[tier_counter-1], ice_rune_icons[tier_counter-1].get_rect(centerx=ice_rune_coords[0], centery=ice_rune_coords[1]))
            else:
                screen.blit(ice_rune_icons[tier_counter-1], ice_rune_icons[tier_counter-1].get_rect(centerx=ice_rune_coords[0], centery=ice_rune_coords[1]))
            tier_counter += 1
        
        tier_counter = 1
        lightning_rune_icons = [pygame.image.load(assets_dir+'shop//rune_l_1.png'), pygame.image.load(assets_dir+'shop//rune_l_2.png'), pygame.image.load(assets_dir+'shop//rune_l_3.png')]
        l_lightning_rune_icons = [pygame.image.load(assets_dir+'shop//rune_l_1_locked.png'), pygame.image.load(assets_dir+'shop//rune_l_2_locked.png'), pygame.image.load(assets_dir+'shop//rune_l_3_locked.png')]
        for lightning_rune_coords in [[180, 383], [480, 383], [780, 383]]:
            if tier_counter > tier or (element != 'lightning'):
                screen.blit(l_lightning_rune_icons[tier_counter-1], lightning_rune_icons[tier_counter-1].get_rect(centerx=lightning_rune_coords[0], centery=lightning_rune_coords[1]))
            else:
                screen.blit(lightning_rune_icons[tier_counter-1], lightning_rune_icons[tier_counter-1].get_rect(centerx=lightning_rune_coords[0], centery=lightning_rune_coords[1]))
            tier_counter += 1
        
        tier_counter = 1
        dark_arts_rune_icons = [pygame.image.load(assets_dir+'shop//rune_d_1.png'), pygame.image.load(assets_dir+'shop//rune_d_2.png'), pygame.image.load(assets_dir+'shop//rune_d_3.png')]
        l_dark_arts_rune_icons = [pygame.image.load(assets_dir+'shop//rune_d_1_locked.png'), pygame.image.load(assets_dir+'shop//rune_d_2_locked.png'), pygame.image.load(assets_dir+'shop//rune_d_3_locked.png')]
        for dark_arts_rune_coords in [[180, 500], [480, 500], [780, 500]]:
            if tier_counter > tier or (element != 'dark_arts'):
                screen.blit(l_dark_arts_rune_icons[tier_counter-1], dark_arts_rune_icons[tier_counter-1].get_rect(centerx=dark_arts_rune_coords[0], centery=dark_arts_rune_coords[1]))
            else:
                screen.blit(dark_arts_rune_icons[tier_counter-1], dark_arts_rune_icons[tier_counter-1].get_rect(centerx=dark_arts_rune_coords[0], centery=dark_arts_rune_coords[1]))
            tier_counter += 1
        
        
        pygame.display.flip()
        
        coords = [[160, 200], [460, 500], [760, 800]]
    
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN and (event.key == pygame.K_RETURN):
                try:
                    if tier > int(save_info.split('\n')[5]):
                        save_file_output = str(money)+'\n'+str(xp)+'\n'+str(element)+'\n'+str(s_tier)+'\n'+str(r_tier)+'\n'+str(tier)
                        e_save_file_output = encrypt(save_file_output, value=200, flush=False)
                        save_file = open(assets_dir+'shop.loxd', 'wb')
                        save_file.write(e_save_file_output.encode())
                        save_file.close()
                        
                        
                        #dmg, prc, drn, mp
                        fire_runes =      [[20, 0, 0, 100], [50, 0, 0, 150], [150, 0, 0, 200]]
                        ice_runes =       [[5, 100, 0, 100], [15, 100, 0, 150], [40, 100, 0, 200]]
                        lightning_runes = [[3, 0, 0, 100], [10, 0, 0, 150], [40, 0, 0, 200]]
                        dark_arts_runes = [[5, 0, 5, 100], [15, 0, 15, 150], [40, 0, 0, 200]]
                        
                        runeLayout = {'dmg':0, 'prc':1, 'drn':2, 'mp':3}
                        for modRuneChange in modRuneChanges:
                            if len(modRuneChange) == 4:
                                # staff.fire.3.dmg = 2
                                #['fire', '3', 'dmg', 2]
                                if modRuneChange[0].lower() == 'fire':
                                    fire_runes[int(modRuneChange[1])-1][runeLayout[modRuneChange[2]]] = modRuneChange[3]
                                elif modRuneChange[0].lower() == 'ice':
                                    ice_runes[int(modRuneChange[1])-1][runeLayout[modRuneChange[2]]] = modRuneChange[3]
                                elif modRuneChange[0].lower() == 'lightning':
                                    lightning_runes[int(modRuneChange[1])-1][runeLayout[modRuneChange[2]]] = modRuneChange[3]
                                elif modRuneChange[0].lower() == 'dark_arts':
                                    dark_arts_runes[int(modRuneChange[1])-1][runeLayout[modRuneChange[2]]] = modRuneChange[3]

                        if element == 'fire':
                            rune_list = fire_runes[tier-1]
                        elif element == 'ice':
                            rune_list = ice_runes[tier-1]
                        elif element == 'lightning':
                            rune_list = lightning_runes[tier-1]
                        elif element == 'dark_arts':
                            rune_list = dark_arts_runes[tier-1]
                        else:
                            rune_list = [0, 0, 0, 0]
                        rune = str(rune_list[0])+'\n'+str(rune_list[1])+'\n'+str(rune_list[2])+'\n'+str(rune_list[3])
                        rune_file = open(assets_dir+'rune.loxd', 'wb')   
                        rune_file.write(encrypt(rune, value=200, flush=False).encode())
                        rune_file.close()
                except:
                    useless = None
                
                if event.key == pygame.K_RETURN:
                    return None
        mouse_pos = pygame.mouse.get_pos()
        if pygame.mouse.get_pressed()[0]:
#            print('1')
            if mouse_pos[1] > 130 and mouse_pos[1] < 170 and (element == 'fire' or element == 'none'):
                for rune_counter in range(len(coords)):
                    if money >= rune_cost[tier+1] and mouse_pos[0] > coords[rune_counter][0] and mouse_pos[0] < coords[rune_counter][1] and rune_counter == tier:
                        tier += 1
                        money -= rune_cost[tier]
                        element = 'fire'
            if mouse_pos[1] > 247 and mouse_pos[1] < 287 and (element == 'ice' or element == 'none'):
                for rune_counter in range(len(coords)):
                    if money >= rune_cost[tier+1] and mouse_pos[0] > coords[rune_counter][0] and mouse_pos[0] < coords[rune_counter][1] and rune_counter == tier:
                        tier += 1
                        money -= rune_cost[tier]
                        element = 'ice'
            if mouse_pos[1] > 363 and mouse_pos[1] < 403 and (element == 'lightning' or element == 'none'):
                for rune_counter in range(len(coords)):
                    if money >= rune_cost[tier+1] and mouse_pos[0] > coords[rune_counter][0] and mouse_pos[0] < coords[rune_counter][1] and rune_counter == tier:
                        tier += 1
                        money -= rune_cost[tier]
                        element = 'lightning'
            if mouse_pos[1] > 480 and mouse_pos[1] < 520 and (element == 'dark_arts' or element == 'none'):
                for rune_counter in range(len(coords)):
                    if money >= rune_cost[tier+1] and mouse_pos[0] > coords[rune_counter][0] and mouse_pos[0] < coords[rune_counter][1] and rune_counter == tier:
                        tier += 1
                        money -= rune_cost[tier]
                        element = 'dark_arts'

assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + 'assets//'
screens_dir = assets_dir + 'screens//'
screenSize = screenWidth, screenHeight = 960, 720
screen = pygame.display.set_mode(screenSize)
pygame.display.set_caption('Legend of Xathoebar')
icon = pygame.image.load(assets_dir+"icon.png")
pygame.display.set_icon(icon)
intro(screen)
menu_screen_list = [pygame.image.load(screens_dir+'menu_screen_play.png'), pygame.image.load(screens_dir+'menu_screen_shop.png'), pygame.image.load(screens_dir+'menu_screen_exit.png')]
menu_screen_index = 0
menu_screen = menu_screen_list[menu_screen_index]
menu_screen_rect = menu_screen.get_rect()

modList = glob.glob(assets_dir+'mods//*.loxmod')
modEnemyChanges = []
modStaffChanges = []
modRobeChanges = []
modRuneChanges = []
for modName in modList:
    modFile = open(modName, 'r')
    pre_init = False
    for modLine in modFile:
        if len(modLine.strip()) > 0:
            if modLine.strip() == '[Pre-Init]':
                pre_init = True
                continue
            elif modLine.strip()[0] == '[':
                pre_init = False
                continue
            if pre_init and modLine.strip()[0] != '#':
                # Goblin.ATK = 3
                if ((modLine.strip()).split('.'))[0] in ['Goblin', 'Orc', 'DarkWizard', 'Cyclops', 'Skeleton', 'SkeletonKnight', 'SkeletonTrap', 'Necromancer', 'Skull', 'SandWraith', 'AngryCactus', 'SandSnake', 'SandSnakeNest', 'DesertWormHead', 'DesertWormSegment', 'DesertWormTail', 'SandPit', 'CyclopsTurret', 'ShearBackBeetle', 'LivingBomb', 'LivingBoulder', 'FireDragon', 'DragonFireball']:
                    modEnemyChanges.append([((modLine.strip()).split('.'))[0], ((((modLine.strip()).split('='))[0].strip()).split('.'))[1], ((modLine.strip()).split('='))[1].strip()])
                if ((modLine.strip()).split('.'))[0] == 'staff':
                    # staff.fire.3.dmg = 2
                    try:
                        modStaffChanges.append([((modLine.strip()).split('.'))[1], ((modLine.strip()).split('.'))[2], (((modLine.strip()).split('.'))[3].split('=')[0]).strip(), int(((modLine.strip()).split('='))[1].strip())])
                    # staff.2 = 500
                    except IndexError:
                        modStaffChanges.append([int(((modLine.strip()).split('.'))[1].split('=')[0].strip()), int(((modLine.strip()).split('='))[1].strip())])
                if ((modLine.strip()).split('.'))[0] == 'robe':
                    # robe.2.cost = 400
                    modRobeChanges.append([int(((modLine.strip()).split('.'))[1]), ((modLine.strip()).split('.'))[2].split('=')[0].strip(), int(((modLine.strip()).split('='))[1].strip())])
                if ((modLine.strip()).split('.'))[0] == 'rune':
                    # rune.fire.3.dmg = 2
                    try:
                        modRuneChanges.append([((modLine.strip()).split('.'))[1], ((modLine.strip()).split('.'))[2], (((modLine.strip()).split('.'))[3].split('=')[0]).strip(), int(((modLine.strip()).split('='))[1].strip())])
                    # rune.2 = 500
                    except IndexError:
                        modRuneChanges.append([int(((modLine.strip()).split('.'))[1].split('=')[0].strip()), int(((modLine.strip()).split('='))[1].strip())])

#print(modRuneChanges)

for modPName in modList:
    modPName = modPName.split('.loxmod')[0]
    try:
        print('Mod present: \"' + os.path.basename(modPName).split('-')[0] + '\" version ' + os.path.basename(modPName).split('-')[1] + ' for LoX version ' + os.path.basename(modPName).split('-')[2])
        if os.path.basename(modPName).split('-')[2] != '1.4':
            print('WARNING: Mod written for different LoX version!')
    except:
        print('Mod present: ' + os.path.basename(modPName))
        print('WARNING: Mod \"' + os.path.basename(modPName) + '\" is deprecated.')

#print(modEnemyChanges)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN:
            if menu_screen_index < (len(menu_screen_list)-1):
                menu_screen_index += 1
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_UP:
            if menu_screen_index > 0:
                menu_screen_index -= 1
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
            if menu_screen_index == 0:
                #rune - element, dmg, mp, prc, image, drn
                #play(screen, [3, 5, 3, pygame.image.load(assets_dir+'shots//player_shot_l_5.png')], [0, 0], ['dark_arts', 5, 100, 0, pygame.image.load(assets_dir+'shots//player_rune_d_1.png'), 5])
                staff_file = open(assets_dir + 'staff.loxd', 'rb')
                staff_file_contents = (staff_file.read()).decode()
                staff_file.close()
                staff_info = encrypt(staff_file_contents, value=200, flush=False)
                staff_dmg = int(staff_info.split('\n')[0])
                staff_rof = int(staff_info.split('\n')[1])
                staff_prc = int(staff_info.split('\n')[2])
                
                shop_file = open(assets_dir + 'shop.loxd', 'rb')
                shop_file_contents = (shop_file.read()).decode()
                shop_file.close()
                shop_file_info = encrypt(shop_file_contents, value=200, flush=False)
                money = int((shop_file_info.split('\n'))[0])
                xp = int((shop_file_info.split('\n'))[1])
                element = (shop_file_info.split('\n'))[2]
                tier = int((shop_file_info.split('\n'))[3])
                r_tier = int((shop_file_info.split('\n'))[4])
                rune_tier = int((shop_file_info.split('\n'))[5])
                
                try:
                    bullet = pygame.image.load(assets_dir+'shots//player_shot_'+element[0]+'_'+str(tier)+'.png')
                except pygame.error:
                    print('Visit the shop first and choose a tier 1 staff!')
                    continue
                
                staff = [staff_dmg, staff_rof, staff_prc, bullet] 
                
                robe_file = open(assets_dir + 'robe.loxd', 'rb')
                robe_file_contents = (robe_file.read()).decode()
                robe_file.close()
                robe_info = encrypt(robe_file_contents, value=200, flush=False)
                
                robe_hp = int(robe_info.split('\n')[0])
                robe_mp = int(robe_info.split('\n')[1]) 
                
                #dmg, prc, drn, mp
                rune_file = open(assets_dir + 'rune.loxd', 'rb')                
                rune_file_contents = (rune_file.read()).decode()
                rune_file.close()
                rune_info = encrypt(rune_file_contents, value=200, flush=False)
                
                level_file = open(assets_dir + 'level.loxd', 'rb')                
                level_file_contents = (level_file.read()).decode()
                level_file.close()
                level_info = int(encrypt(level_file_contents, value=200, flush=False))
                
                rune_dmg = int(rune_info.split('\n')[0])
                rune_prc = int(rune_info.split('\n')[1])
                rune_drn = int(rune_info.split('\n')[2])
                rune_mp = int(rune_info.split('\n')[3])
                
                results = play(screen, staff, [robe_hp, robe_mp], [element, rune_dmg, rune_mp, rune_prc, pygame.image.load(assets_dir+'shots//player_rune_'+element[0]+'_'+str(rune_tier)+'.png'), rune_drn])
                
                money += results[0]
                xp += results[1]
                this_level = results[2]
               
                if this_level > level_info:
                    level_file = open(assets_dir + 'level.loxd', 'wb')
                    level_file.write(encrypt(str(this_level), value=200, flush=False).encode())
                    level_file.close()
                
                save_file_output = str(money)+'\n'+str(xp)+'\n'+str(element)+'\n'+str(tier)+'\n'+str(r_tier)+'\n'+str(rune_tier)
                e_save_file_output = encrypt(save_file_output, value=200, flush=False)
                save_file = open(assets_dir+'shop.loxd', 'wb')
                save_file.write(e_save_file_output.encode())
                save_file.close()
                
                pygame.key.set_repeat()
            elif menu_screen_index == 1:
                shop_staff(screen)
                shop_robe(screen)
                shop_rune(screen)
            elif menu_screen_index == 2:
                sys.exit()
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
            command = input('@: ').split()
            if command[0] == 'tp':
                assets_dir = sys.argv[0][:len(sys.argv[0])-len(os.path.basename(sys.argv[0]))] + command[1] + '//'
            else:
                print('ERROR: Unkown command')
    menu_screen = menu_screen_list[menu_screen_index]
    screen.blit(menu_screen, menu_screen_rect)
    pygame.display.flip()